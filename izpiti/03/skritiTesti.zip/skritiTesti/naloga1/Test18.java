
public class Test18 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(404450));
        System.out.println(Prva.alternirajocaVsota(337208));
        System.out.println(Prva.alternirajocaVsota(873611));
    }
}
