
public class Test21 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(7538826));
        System.out.println(Prva.alternirajocaVsota(7460928));
        System.out.println(Prva.alternirajocaVsota(2797718));
    }
}
