
public class Test22 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(45288416));
        System.out.println(Prva.alternirajocaVsota(55066274));
        System.out.println(Prva.alternirajocaVsota(25971222));
    }
}
