
public class Test04 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(81));
        System.out.println(Prva.alternirajocaVsota(18));
        System.out.println(Prva.alternirajocaVsota(19));
    }
}
