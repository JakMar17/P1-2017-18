
public class Test01 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(4));
        System.out.println(Prva.alternirajocaVsota(6));
        System.out.println(Prva.alternirajocaVsota(5));
    }
}
