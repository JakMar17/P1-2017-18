
public class Test06 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(26));
        System.out.println(Prva.alternirajocaVsota(62));
        System.out.println(Prva.alternirajocaVsota(74));
    }
}
