
public class Test25 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(343395461));
        System.out.println(Prva.alternirajocaVsota(765238433));
        System.out.println(Prva.alternirajocaVsota(897411563));
    }
}
