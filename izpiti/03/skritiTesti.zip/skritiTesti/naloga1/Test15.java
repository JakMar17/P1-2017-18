
public class Test15 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(29168));
        System.out.println(Prva.alternirajocaVsota(51613));
        System.out.println(Prva.alternirajocaVsota(91235));
    }
}
