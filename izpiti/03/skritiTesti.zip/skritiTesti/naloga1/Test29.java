
import java.util.Arrays;

public class Test29 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'f'},
            {')'},
            {'<'},
            {'1'},
            {'{'},
            {'<'},
            {'<'},
            {'q'},
            {'f'},
            {'q'},
            {'{'},
            {')'},
            {'*'},
            {'{'},
            {'f'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
