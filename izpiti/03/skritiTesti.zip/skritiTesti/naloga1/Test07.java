
public class Test07 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(627));
        System.out.println(Prva.alternirajocaVsota(712));
        System.out.println(Prva.alternirajocaVsota(348));
    }
}
