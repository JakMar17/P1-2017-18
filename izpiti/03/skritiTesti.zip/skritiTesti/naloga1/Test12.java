
public class Test12 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(3039));
        System.out.println(Prva.alternirajocaVsota(4357));
        System.out.println(Prva.alternirajocaVsota(5480));
    }
}
