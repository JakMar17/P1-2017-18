
public class Test03 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(1));
        System.out.println(Prva.alternirajocaVsota(5));
        System.out.println(Prva.alternirajocaVsota(4));
    }
}
