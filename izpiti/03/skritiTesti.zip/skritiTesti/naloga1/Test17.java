
public class Test17 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(996202));
        System.out.println(Prva.alternirajocaVsota(474004));
        System.out.println(Prva.alternirajocaVsota(597457));
    }
}
