
public class Test20 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(1061335));
        System.out.println(Prva.alternirajocaVsota(7807820));
        System.out.println(Prva.alternirajocaVsota(4262702));
    }
}
