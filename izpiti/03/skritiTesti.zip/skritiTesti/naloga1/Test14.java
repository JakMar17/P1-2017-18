
public class Test14 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(40952));
        System.out.println(Prva.alternirajocaVsota(75784));
        System.out.println(Prva.alternirajocaVsota(87629));
    }
}
