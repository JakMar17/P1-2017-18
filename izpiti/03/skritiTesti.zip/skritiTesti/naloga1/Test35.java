
import java.util.Arrays;

public class Test35 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'y'},
            {':'},
            {'X'},
            {'A'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
