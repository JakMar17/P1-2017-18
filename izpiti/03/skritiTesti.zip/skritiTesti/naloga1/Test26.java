
import java.util.Arrays;

public class Test26 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'/'},
            {'r'},
            {'*'},
            {'c'},
            {'&'},
            {'t'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
