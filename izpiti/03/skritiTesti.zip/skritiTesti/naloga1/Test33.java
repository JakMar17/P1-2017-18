
import java.util.Arrays;

public class Test33 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'y'},
            {'s'},
            {'h'},
            {'*'},
            {'*'},
            {'z'},
            {'y'},
            {'z'},
            {'y'},
            {'h'},
            {'V'},
            {'y'},
            {'*'},
            {'*'},
            {'*'},
            {'h'},
            {'*'},
            {'s'},
            {'y'},
            {'z'},
            {'V'},
            {'z'},
            {'h'},
            {'s'},
            {'*'},
            {'h'},
            {'y'},
            {'h'},
            {'s'},
            {'y'},
            {'y'},
            {'h'},
            {'V'},
            {'*'},
            {'s'},
            {'z'},
            {'V'},
            {'y'},
            {'y'},
            {'h'},
            {'s'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
