
public class Test13 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(43036));
        System.out.println(Prva.alternirajocaVsota(90382));
        System.out.println(Prva.alternirajocaVsota(13268));
    }
}
