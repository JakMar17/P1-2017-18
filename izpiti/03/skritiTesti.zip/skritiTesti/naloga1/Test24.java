
public class Test24 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(69277359));
        System.out.println(Prva.alternirajocaVsota(22779254));
        System.out.println(Prva.alternirajocaVsota(45474585));
    }
}
