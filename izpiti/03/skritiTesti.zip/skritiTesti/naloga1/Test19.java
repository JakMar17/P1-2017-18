
public class Test19 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(4719651));
        System.out.println(Prva.alternirajocaVsota(8685907));
        System.out.println(Prva.alternirajocaVsota(4114464));
    }
}
