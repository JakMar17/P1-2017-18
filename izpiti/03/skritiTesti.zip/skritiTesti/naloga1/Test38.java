
import java.util.Arrays;

public class Test38 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
