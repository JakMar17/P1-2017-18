
public class Test08 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(239));
        System.out.println(Prva.alternirajocaVsota(611));
        System.out.println(Prva.alternirajocaVsota(673));
    }
}
