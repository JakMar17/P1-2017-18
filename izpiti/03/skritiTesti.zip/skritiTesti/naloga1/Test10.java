
public class Test10 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(9463));
        System.out.println(Prva.alternirajocaVsota(2458));
        System.out.println(Prva.alternirajocaVsota(8653));
    }
}
