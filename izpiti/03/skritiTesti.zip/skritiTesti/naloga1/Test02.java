
public class Test02 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(8));
        System.out.println(Prva.alternirajocaVsota(3));
        System.out.println(Prva.alternirajocaVsota(6));
    }
}
