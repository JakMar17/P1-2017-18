
public class Test09 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(946));
        System.out.println(Prva.alternirajocaVsota(730));
        System.out.println(Prva.alternirajocaVsota(936));
    }
}
