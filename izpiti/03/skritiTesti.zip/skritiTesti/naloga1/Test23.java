
public class Test23 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(75231615));
        System.out.println(Prva.alternirajocaVsota(57043389));
        System.out.println(Prva.alternirajocaVsota(88703261));
    }
}
