
public class Test16 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(982631));
        System.out.println(Prva.alternirajocaVsota(749143));
        System.out.println(Prva.alternirajocaVsota(925961));
    }
}
