
public class Test05 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(74));
        System.out.println(Prva.alternirajocaVsota(60));
        System.out.println(Prva.alternirajocaVsota(62));
    }
}
