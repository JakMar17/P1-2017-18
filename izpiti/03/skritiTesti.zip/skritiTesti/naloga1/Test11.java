
public class Test11 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(6897));
        System.out.println(Prva.alternirajocaVsota(7812));
        System.out.println(Prva.alternirajocaVsota(7566));
    }
}
