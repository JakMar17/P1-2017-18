
import java.util.Arrays;

public class Test32 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'q'},
            {'B'},
            {'m'},
            {'F'},
            {'8'},
            {'Y'},
            {'y'},
            {']'},
            {'-'},
            {' '},
            {'N'},
            {'B'},
            {'4'},
            {')'},
            {'4'},
            {'f'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
