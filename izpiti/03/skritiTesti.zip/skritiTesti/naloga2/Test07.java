
import java.util.Arrays;

public class Test07 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 41),
            new Druga.Izdelek("i1", 17),
            new Druga.Izdelek("i2", 76),
            new Druga.Izdelek("i3", 65),
            new Druga.Izdelek("i4", 68),
            new Druga.Izdelek("i5", 4),
            new Druga.Izdelek("i6", 57),
            new Druga.Izdelek("i7", 79),
            new Druga.Izdelek("i8", 62),
            new Druga.Izdelek("i9", 86),
            new Druga.Izdelek("i10", 34),
            new Druga.Izdelek("i11", 63),
            new Druga.Izdelek("i12", 82),
            new Druga.Izdelek("i13", 26),
            new Druga.Izdelek("i14", 27),
            new Druga.Izdelek("i15", 95),
            new Druga.Izdelek("i16", 63),
            new Druga.Izdelek("i17", 20),
            new Druga.Izdelek("i18", 71),
            new Druga.Izdelek("i19", 52),
        };
        int[] zaloga = {3, 3, 8, 9, 6, 7, 9, 1, 6, 4, 9, 3, 9, 4, 7, 3, 4, 6, 1, 5};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i0"));
        System.out.println(trgovina.poisciIzdelek("i11"));
        System.out.println(trgovina.poisciIzdelek("i1"));
        System.out.println(trgovina.poisciIzdelek("i17"));
        System.out.println(trgovina.poisciIzdelek("i13"));
        System.out.println(trgovina.poisciIzdelek("i18"));
        System.out.println(trgovina.poisciIzdelek("i14"));
        System.out.println(trgovina.poisciIzdelek("i8"));
        System.out.println(trgovina.poisciIzdelek("i2"));
        System.out.println(trgovina.poisciIzdelek("i3"));
    }
}
