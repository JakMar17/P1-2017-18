
import java.util.Arrays;

public class Test18 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 21),
            new Druga.Izdelek("i1", 5),
            new Druga.Izdelek("i2", 1),
            new Druga.Izdelek("i3", 86),
            new Druga.Izdelek("i4", 49),
            new Druga.Izdelek("i5", 64),
            new Druga.Izdelek("i6", 18),
            new Druga.Izdelek("i7", 70),
            new Druga.Izdelek("i8", 10),
            new Druga.Izdelek("i9", 88),
            new Druga.Izdelek("i10", 2),
            new Druga.Izdelek("i11", 29),
            new Druga.Izdelek("i12", 99),
            new Druga.Izdelek("i13", 83),
            new Druga.Izdelek("i14", 20),
            new Druga.Izdelek("i15", 99),
            new Druga.Izdelek("i16", 61),
            new Druga.Izdelek("i17", 46),
            new Druga.Izdelek("i18", 85),
            new Druga.Izdelek("i19", 98),
            new Druga.Izdelek("i20", 48),
            new Druga.Izdelek("i21", 26),
            new Druga.Izdelek("i22", 18),
            new Druga.Izdelek("i23", 38),
            new Druga.Izdelek("i24", 73),
        };
        int[] zaloga = {6, 1, 5, 0, 0, 8, 4, 1, 9, 8, 1, 10, 3, 6, 7, 0, 1, 8, 2, 4, 6, 9, 2, 2, 4};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(7, 1));
        System.out.println(trgovina.prodaj(18, 1));
        System.out.println(trgovina.prodaj(23, 1));
        System.out.println(trgovina.prodaj(22, 2));
        System.out.println(trgovina.prodaj(6, 4));
        System.out.println(trgovina.prodaj(20, 3));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
