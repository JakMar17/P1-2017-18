
import java.util.Arrays;

public class Test02 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 63),
            new Druga.Izdelek("i1", 83),
            new Druga.Izdelek("i2", 0),
            new Druga.Izdelek("i3", 5),
            new Druga.Izdelek("i4", 60),
            new Druga.Izdelek("i5", 44),
            new Druga.Izdelek("i6", 82),
            new Druga.Izdelek("i7", 16),
            new Druga.Izdelek("i8", 65),
            new Druga.Izdelek("i9", 91),
        };
        int[] zaloga = {7, 8, 9, 5, 4, 5, 0, 1, 0, 0};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i7"));
        System.out.println(trgovina.poisciIzdelek("i8"));
        System.out.println(trgovina.poisciIzdelek("i0"));
        System.out.println(trgovina.poisciIzdelek("i5"));
        System.out.println(trgovina.poisciIzdelek("i9"));
        System.out.println(trgovina.poisciIzdelek("i6"));
        System.out.println(trgovina.poisciIzdelek("i3"));
    }
}
