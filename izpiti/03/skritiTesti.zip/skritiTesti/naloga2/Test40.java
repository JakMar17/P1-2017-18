
import java.util.Arrays;

public class Test40 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 37);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 94);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 98);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 3);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 79);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 1);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 42);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 90);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 0);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 13);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 23);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 55);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 54);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 4);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 87);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 55);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 6);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 0);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 97);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 100);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 21);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 23);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 57);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 69);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 45);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 84);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 87);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 62);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 38);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 31);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 97);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 78);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 64);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 94);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 40);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 80);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 39);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 79);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 41);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 69);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 2);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 80);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[10][9];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i38}, new int[]{7, 7});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i17, i22, i39, i35}, new int[]{5, 5, 5, 1, 8});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i18}, new int[]{6});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i31, i24, i4, i17}, new int[]{5, 2, 1, 7, 7});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i39, i17, i37}, new int[]{9, 7, 2, 5});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i28}, new int[]{0});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i26, i16}, new int[]{7, 4, 4});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{i10}, new int[]{8});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i40, i24, i21}, new int[]{2, 8, 2, 5});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i18, i27, i30}, new int[]{2, 3, 1, 2});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i35, i10, i0, i20}, new int[]{6, 1, 0, 7, 4});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i25, i11}, new int[]{5, 0, 1});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i11, i0, i28, i34}, new int[]{0, 0, 6, 3, 1});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i6, i26}, new int[]{7, 1, 0});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i1, i5}, new int[]{3, 1, 0});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i9, i36}, new int[]{6, 2, 9});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i5}, new int[]{7, 3});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i8}, new int[]{0, 2});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i22, i36}, new int[]{3, 8, 4});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i34, i28, i1, i24}, new int[]{4, 8, 7, 1, 9});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i15}, new int[]{2, 7});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i18, i27, i20}, new int[]{4, 1, 8, 9});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i4, i32, i36}, new int[]{4, 3, 1, 2});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i11, i28}, new int[]{0, 1, 3});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i27, i11, i0}, new int[]{8, 8, 6, 4});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i34, i6}, new int[]{7, 4, 0});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i25}, new int[]{7, 2});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i19, i14}, new int[]{3, 8, 6});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41}, new int[]{0});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i19, i9}, new int[]{2, 7, 5});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i3}, new int[]{6});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i0}, new int[]{8, 5});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i30, i6, i25, i20}, new int[]{0, 1, 1, 8, 7});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i7, i38}, new int[]{8, 3, 5});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i20, i37, i34, i33}, new int[]{3, 3, 2, 4, 6});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{i39}, new int[]{6});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i18, i22}, new int[]{2, 0, 2});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i32, i40, i10}, new int[]{8, 5, 0, 2});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i31, i0}, new int[]{9, 1, 0});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i26, i9}, new int[]{6, 7, 8});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i6}, new int[]{6});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i14, i1}, new int[]{4, 8, 3});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i7}, new int[]{1, 2});
        trgovine[5][7] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i39, i35, i22}, new int[]{6, 5, 0, 7});
        trgovine[5][8] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i40}, new int[]{7, 6});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i20}, new int[]{6});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i1, i6}, new int[]{8, 9, 5});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i33, i36, i34}, new int[]{5, 0, 7, 7});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i19, i29}, new int[]{8, 1, 1});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i20, i24, i10, i6}, new int[]{8, 6, 5, 3, 2});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i21, i38, i18}, new int[]{3, 8, 5, 4});
        trgovine[6][7] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i38}, new int[]{8, 5});
        trgovine[6][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i31, i34}, new int[]{5, 2, 0});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i33}, new int[]{7});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i17, i24, i26, i7}, new int[]{6, 5, 7, 1, 6});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i36}, new int[]{6});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{7});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i3}, new int[]{1});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][7] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i7, i33}, new int[]{2, 6, 5});
        trgovine[7][8] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i36}, new int[]{9, 2});

        trgovine[8][0] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i4, i30, i35}, new int[]{3, 7, 6, 9});
        trgovine[8][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{1});
        trgovine[8][2] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i16, i22, i2, i24}, new int[]{2, 2, 0, 7, 8});
        trgovine[8][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[8][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i32, i16}, new int[]{5, 4, 3});
        trgovine[8][5] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i35, i30, i33}, new int[]{8, 4, 2, 7});
        trgovine[8][6] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i6, i14, i39}, new int[]{4, 2, 8, 3});
        trgovine[8][7] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i22, i28, i36, i39}, new int[]{0, 4, 4, 2, 3});
        trgovine[8][8] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i38, i30}, new int[]{0, 2, 3});

        trgovine[9][0] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i40}, new int[]{8, 3});
        trgovine[9][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[9][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[9][3] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i21, i1, i26, i28}, new int[]{1, 2, 9, 4, 5});
        trgovine[9][4] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i2, i20}, new int[]{6, 2, 4});
        trgovine[9][5] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i11, i8, i10}, new int[]{5, 6, 8, 6});
        trgovine[9][6] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i3, i12, i19}, new int[]{3, 7, 3, 2});
        trgovine[9][7] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i9, i35}, new int[]{1, 7, 4});
        trgovine[9][8] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i22}, new int[]{7, 9});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            {-1,  0},
            { 0, -1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            {-1,  0},
            {-1,  0},
            {-1,  0},
        };

        System.out.println(center.pohod(premiki, "i24"));
        System.out.println(center.pohod(premiki, "i35"));
        System.out.println(center.pohod(premiki, "i38"));
        System.out.println(center.pohod(premiki, "i15"));
        System.out.println(center.pohod(premiki, "i18"));
        System.out.println(center.pohod(premiki, "i3"));
        System.out.println(center.pohod(premiki, "i22"));
        System.out.println(center.pohod(premiki, "i10"));
        System.out.println(center.pohod(premiki, "i17"));
        System.out.println(center.pohod(premiki, "i28"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
