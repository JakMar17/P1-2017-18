
import java.util.Arrays;

public class Test39 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 38);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 48);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 29);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 43);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 25);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 40);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 53);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 52);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 34);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 32);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 88);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 23);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 59);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 41);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 71);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 86);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 96);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 54);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 70);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 4);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 38);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 89);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 59);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 1);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 32);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 69);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 59);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 3);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 21);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 1);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 2);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 92);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 59);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 16);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 3);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 88);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 70);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 45);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 46);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 10);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 26);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 78);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[4][4];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i11, i32, i3}, new int[]{1, 7, 7, 0});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i1}, new int[]{3});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i12}, new int[]{1});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i27, i37, i33, i15}, new int[]{1, 0, 7, 0, 0});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i32, i0, i4}, new int[]{8, 8, 1, 2});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i10}, new int[]{3, 8});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i30, i8}, new int[]{4, 8, 1});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i32, i24}, new int[]{4, 5, 6});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i6}, new int[]{6, 5});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i12, i34}, new int[]{7, 2, 0});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i1}, new int[]{8, 4});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 0, -1},
            {-1,  0},
            { 0, -1},
            { 1,  0},
        };

        System.out.println(center.pohod(premiki, "i8"));
        System.out.println(center.pohod(premiki, "i38"));
        System.out.println(center.pohod(premiki, "i23"));
        System.out.println(center.pohod(premiki, "i18"));
        System.out.println(center.pohod(premiki, "i16"));
        System.out.println(center.pohod(premiki, "i15"));
        System.out.println(center.pohod(premiki, "i10"));
        System.out.println(center.pohod(premiki, "i14"));
        System.out.println(center.pohod(premiki, "i26"));
        System.out.println(center.pohod(premiki, "i0"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
