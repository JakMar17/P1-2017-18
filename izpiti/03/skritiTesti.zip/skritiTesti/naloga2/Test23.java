
import java.util.Arrays;

public class Test23 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 63),
            new Druga.Izdelek("i1", 21),
            new Druga.Izdelek("i2", 66),
            new Druga.Izdelek("i3", 66),
            new Druga.Izdelek("i4", 43),
            new Druga.Izdelek("i5", 64),
            new Druga.Izdelek("i6", 25),
        };
        int[] zaloga = {1, 5, 5, 1, 7, 5, 5};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(4, 5));
        System.out.println(trgovina.prodaj(1, 1));
        System.out.println(trgovina.prodaj(0, 4));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
