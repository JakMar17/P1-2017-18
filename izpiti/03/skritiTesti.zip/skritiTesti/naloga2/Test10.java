
import java.util.Arrays;

public class Test10 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 69),
            new Druga.Izdelek("i1", 70),
            new Druga.Izdelek("i2", 67),
            new Druga.Izdelek("i3", 57),
            new Druga.Izdelek("i4", 2),
            new Druga.Izdelek("i5", 58),
            new Druga.Izdelek("i6", 99),
            new Druga.Izdelek("i7", 12),
            new Druga.Izdelek("i8", 18),
            new Druga.Izdelek("i9", 62),
            new Druga.Izdelek("i10", 74),
            new Druga.Izdelek("i11", 99),
            new Druga.Izdelek("i12", 57),
            new Druga.Izdelek("i13", 22),
            new Druga.Izdelek("i14", 58),
            new Druga.Izdelek("i15", 20),
            new Druga.Izdelek("i16", 64),
            new Druga.Izdelek("i17", 72),
            new Druga.Izdelek("i18", 0),
            new Druga.Izdelek("i19", 96),
            new Druga.Izdelek("i20", 53),
            new Druga.Izdelek("i21", 56),
        };
        int[] zaloga = {0, 3, 10, 7, 5, 8, 6, 2, 7, 4, 7, 8, 0, 1, 8, 7, 4, 4, 0, 7, 10, 6};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i20"));
        System.out.println(trgovina.poisciIzdelek("i0"));
        System.out.println(trgovina.poisciIzdelek("i6"));
        System.out.println(trgovina.poisciIzdelek("i10"));
        System.out.println(trgovina.poisciIzdelek("i12"));
        System.out.println(trgovina.poisciIzdelek("i16"));
        System.out.println(trgovina.poisciIzdelek("i15"));
        System.out.println(trgovina.poisciIzdelek("i17"));
        System.out.println(trgovina.poisciIzdelek("i3"));
        System.out.println(trgovina.poisciIzdelek("i2"));
    }
}
