
import java.util.Arrays;

public class Test34 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 90);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 85);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 76);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 23);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 30);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 31);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 12);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 9);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 78);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 16);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 84);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 58);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 87);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 79);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 90);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 59);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 44);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 69);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 88);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 66);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 19);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 80);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 10);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 26);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 25);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 15);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 10);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 36);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 43);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 21);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 27);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 22);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 75);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 45);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 24);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 96);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 26);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 81);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 92);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 76);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 48);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 25);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[4][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i39}, new int[]{5, 8});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{9});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i12, i4, i14}, new int[]{1, 3, 6, 8});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{6});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i17, i9, i1}, new int[]{4, 7, 6, 8});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i19}, new int[]{2, 3});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i12}, new int[]{0, 4});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i35, i12, i41}, new int[]{2, 0, 7, 3});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i39, i9, i11, i21}, new int[]{0, 9, 3, 1, 2});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i15, i0}, new int[]{7, 2, 3});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i37, i27, i36}, new int[]{9, 8, 2, 7});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i2, i11, i25}, new int[]{9, 1, 6, 6});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i4, i14, i25, i17}, new int[]{7, 9, 6, 0, 4});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i30, i8}, new int[]{9, 4, 8});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i9}, new int[]{8, 6});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i5, i2}, new int[]{2, 9, 0});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i15}, new int[]{9, 8});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i21}, new int[]{6, 0});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i27, i10}, new int[]{1, 5, 7});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i20, i24, i18}, new int[]{8, 7, 2, 8});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 1, "i39"));
        System.out.println(center.vSosescini(1, 3, "i4"));
        System.out.println(center.vSosescini(1, 4, "i39"));
        System.out.println(center.vSosescini(1, 5, "i28"));
        System.out.println(center.vSosescini(1, 2, "i26"));
        System.out.println(center.vSosescini(1, 1, "i27"));
        System.out.println(center.vSosescini(2, 4, "i36"));
        System.out.println(center.vSosescini(2, 1, "i29"));
        System.out.println(center.vSosescini(2, 4, "i10"));
        System.out.println(center.vSosescini(2, 2, "i12"));
        System.out.println(center.vSosescini(1, 1, "i33"));
        System.out.println(center.vSosescini(1, 1, "i10"));
        System.out.println(center.vSosescini(2, 5, "i3"));
        System.out.println(center.vSosescini(2, 2, "i14"));
        System.out.println(center.vSosescini(1, 5, "i37"));
        System.out.println(center.vSosescini(2, 4, "i26"));
        System.out.println(center.vSosescini(2, 3, "i28"));
        System.out.println(center.vSosescini(2, 3, "i12"));
        System.out.println(center.vSosescini(1, 5, "i16"));
        System.out.println(center.vSosescini(2, 1, "i38"));
    }
}
