
import java.util.Arrays;

public class Test16 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 97),
            new Druga.Izdelek("i1", 39),
            new Druga.Izdelek("i2", 26),
            new Druga.Izdelek("i3", 77),
            new Druga.Izdelek("i4", 49),
            new Druga.Izdelek("i5", 37),
            new Druga.Izdelek("i6", 3),
            new Druga.Izdelek("i7", 94),
            new Druga.Izdelek("i8", 48),
            new Druga.Izdelek("i9", 34),
            new Druga.Izdelek("i10", 48),
            new Druga.Izdelek("i11", 35),
            new Druga.Izdelek("i12", 57),
            new Druga.Izdelek("i13", 33),
            new Druga.Izdelek("i14", 32),
            new Druga.Izdelek("i15", 71),
            new Druga.Izdelek("i16", 84),
            new Druga.Izdelek("i17", 80),
            new Druga.Izdelek("i18", 63),
            new Druga.Izdelek("i19", 24),
            new Druga.Izdelek("i20", 21),
        };
        int[] zaloga = {2, 6, 1, 9, 6, 8, 10, 7, 1, 2, 5, 9, 3, 5, 2, 3, 6, 1, 8, 2, 4};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(20, 3));
        System.out.println(trgovina.prodaj(9, 1));
        System.out.println(trgovina.prodaj(15, 1));
        System.out.println(trgovina.prodaj(6, 10));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
