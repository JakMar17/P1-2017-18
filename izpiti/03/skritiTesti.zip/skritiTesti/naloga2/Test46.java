
import java.util.Arrays;

public class Test46 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 3);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 0);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 76);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 86);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 6);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 66);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 16);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 43);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 1);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 83);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 83);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 45);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 79);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 27);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 1);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 16);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 95);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 52);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 42);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 81);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 31);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 84);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 12);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 69);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 56);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 100);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 29);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 97);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 28);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 97);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 51);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 77);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 31);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 17);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 2);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 62);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 20);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 5);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 28);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 6);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 8);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 54);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[9][9];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i29}, new int[]{5});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i36, i18, i13}, new int[]{4, 8, 3, 8});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i17, i7}, new int[]{3, 5, 2});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i15, i24, i34}, new int[]{4, 9, 7, 6});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i33, i24, i26}, new int[]{8, 8, 4, 5});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i21, i27}, new int[]{0, 2, 6});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i2, i41, i29}, new int[]{9, 2, 1, 5});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i3, i41}, new int[]{4, 1, 5});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i37, i19, i8, i30}, new int[]{6, 6, 5, 9, 9});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i41, i34, i0}, new int[]{7, 9, 8, 8});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i33}, new int[]{7, 4});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i2, i37, i6}, new int[]{4, 5, 2, 4});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{3});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{6});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i36, i13, i14, i32}, new int[]{5, 1, 9, 3, 4});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i4, i30, i12}, new int[]{8, 0, 0, 5});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i21}, new int[]{3, 5});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i29, i12, i39}, new int[]{0, 7, 8, 9});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i36, i37, i5, i3}, new int[]{8, 1, 6, 6, 4});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i34, i28, i13, i9}, new int[]{1, 2, 5, 9, 1});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i2}, new int[]{0, 7});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i15, i30}, new int[]{8, 1, 5});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i11, i23}, new int[]{9, 1, 2});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{7});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i0, i24}, new int[]{1, 7, 7});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i32, i30, i8}, new int[]{3, 6, 0, 8});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i8}, new int[]{8, 8});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i40, i0, i35, i17}, new int[]{3, 0, 8, 9, 6});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i40, i36, i12}, new int[]{5, 9, 5, 6});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i22}, new int[]{4});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i21}, new int[]{7});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i27, i24, i34}, new int[]{7, 5, 7, 6});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i14, i17}, new int[]{4, 6, 6});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i11, i26, i16, i14}, new int[]{1, 0, 8, 5, 9});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i41}, new int[]{8, 4});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i4}, new int[]{7});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i21, i11}, new int[]{5, 4, 6});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i9, i25}, new int[]{2, 5, 8});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{8});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i17, i31}, new int[]{4, 1, 0});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i14, i16, i33, i36}, new int[]{7, 4, 0, 7, 8});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i12, i0, i1}, new int[]{3, 8, 7, 6});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i5, i10}, new int[]{3, 8, 7});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i36}, new int[]{7, 6});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i24, i3, i17}, new int[]{5, 9, 0, 4});
        trgovine[5][7] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i7}, new int[]{2, 9});
        trgovine[5][8] = new Druga.Trgovina(new Druga.Izdelek[]{i5}, new int[]{2});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i9, i21}, new int[]{9, 8, 4});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i28, i41, i40}, new int[]{3, 2, 7, 6});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i19}, new int[]{8, 7});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i3, i22}, new int[]{9, 0, 4});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i2}, new int[]{7, 6});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i8}, new int[]{8});
        trgovine[6][7] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i2, i33, i27}, new int[]{2, 7, 7, 7});
        trgovine[6][8] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i5, i40, i22, i24}, new int[]{5, 4, 0, 2, 2});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i29, i9}, new int[]{4, 0, 6});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i38}, new int[]{7, 4});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i28}, new int[]{3});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i16, i18, i41}, new int[]{5, 2, 1, 2});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i9, i41}, new int[]{2, 3, 5});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i36, i31, i20}, new int[]{4, 1, 3, 2});
        trgovine[7][7] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i40, i13}, new int[]{7, 0, 5});
        trgovine[7][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[8][0] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i1}, new int[]{7, 6});
        trgovine[8][1] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i38}, new int[]{7, 3});
        trgovine[8][2] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i16, i38, i0, i25}, new int[]{1, 5, 7, 5, 7});
        trgovine[8][3] = new Druga.Trgovina(new Druga.Izdelek[]{i1}, new int[]{3});
        trgovine[8][4] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i19, i38, i10}, new int[]{3, 2, 4, 2});
        trgovine[8][5] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i20, i18}, new int[]{8, 5, 7});
        trgovine[8][6] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i33}, new int[]{4, 3});
        trgovine[8][7] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i10, i17, i6, i1}, new int[]{2, 1, 9, 4, 1});
        trgovine[8][8] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i38, i14}, new int[]{1, 2, 0});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            {-1,  0},
            { 0, -1},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
        };

        System.out.println(center.pohod(premiki, "i21"));
        System.out.println(center.pohod(premiki, "i31"));
        System.out.println(center.pohod(premiki, "i6"));
        System.out.println(center.pohod(premiki, "i29"));
        System.out.println(center.pohod(premiki, "i7"));
        System.out.println(center.pohod(premiki, "i41"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i24"));
        System.out.println(center.pohod(premiki, "i22"));
        System.out.println(center.pohod(premiki, "i11"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
