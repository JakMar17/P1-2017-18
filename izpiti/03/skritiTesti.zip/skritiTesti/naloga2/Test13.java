
import java.util.Arrays;

public class Test13 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 4),
            new Druga.Izdelek("i1", 50),
            new Druga.Izdelek("i2", 58),
            new Druga.Izdelek("i3", 37),
            new Druga.Izdelek("i4", 10),
            new Druga.Izdelek("i5", 85),
            new Druga.Izdelek("i6", 68),
            new Druga.Izdelek("i7", 31),
            new Druga.Izdelek("i8", 1),
            new Druga.Izdelek("i9", 33),
            new Druga.Izdelek("i10", 4),
            new Druga.Izdelek("i11", 85),
            new Druga.Izdelek("i12", 4),
            new Druga.Izdelek("i13", 31),
            new Druga.Izdelek("i14", 40),
            new Druga.Izdelek("i15", 78),
            new Druga.Izdelek("i16", 31),
        };
        int[] zaloga = {4, 5, 8, 6, 4, 6, 8, 9, 3, 9, 2, 10, 5, 1, 9, 7, 1};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(8, 1));
        System.out.println(trgovina.prodaj(6, 7));
        System.out.println(trgovina.prodaj(7, 2));
        System.out.println(trgovina.prodaj(5, 2));
        System.out.println(trgovina.prodaj(11, 1));
        System.out.println(trgovina.prodaj(4, 1));
        System.out.println(trgovina.prodaj(10, 2));
        System.out.println(trgovina.prodaj(16, 1));
        System.out.println(trgovina.prodaj(7, 7));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
