
import java.util.Arrays;

public class Test33 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 8);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 59);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 0);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 59);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 91);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 13);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 42);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 34);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 43);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 37);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 29);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 14);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 80);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 53);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 66);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 21);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 15);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 72);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 82);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 69);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 96);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 73);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 94);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 76);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 70);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 9);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 45);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 21);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 80);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 51);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 3);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 44);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 44);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 55);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 7);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 97);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 80);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 99);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 61);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 99);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 72);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 48);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][3];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i40, i38, i34, i15}, new int[]{7, 9, 7, 6, 4});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i38, i2}, new int[]{1, 3, 0});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i40}, new int[]{7});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i11, i17, i38, i9}, new int[]{3, 6, 1, 3, 2});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i29}, new int[]{4, 2});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i29, i26, i22, i36}, new int[]{4, 7, 3, 7, 9});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i15}, new int[]{2, 4});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i1, i10, i12, i38}, new int[]{7, 3, 6, 4, 5});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i22, i31, i23}, new int[]{3, 6, 9, 9});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i21, i31}, new int[]{5, 4, 9});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i25, i28}, new int[]{5, 0, 1});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i36, i38, i13}, new int[]{9, 6, 2, 3});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i9}, new int[]{7});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i2, i19, i13}, new int[]{5, 2, 1, 8});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i3, i40, i10}, new int[]{8, 9, 8, 2});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i20, i29}, new int[]{5, 0, 1});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i6, i40}, new int[]{8, 2, 6});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i22}, new int[]{0});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i12, i26}, new int[]{8, 9, 1});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i21, i8, i11}, new int[]{1, 9, 8, 3});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i6, i5}, new int[]{2, 1, 4});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i31}, new int[]{1});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 1, "i27"));
        System.out.println(center.vSosescini(6, 1, "i34"));
        System.out.println(center.vSosescini(4, 1, "i34"));
        System.out.println(center.vSosescini(1, 1, "i20"));
        System.out.println(center.vSosescini(3, 1, "i3"));
        System.out.println(center.vSosescini(4, 1, "i12"));
        System.out.println(center.vSosescini(6, 1, "i6"));
        System.out.println(center.vSosescini(4, 1, "i32"));
        System.out.println(center.vSosescini(1, 1, "i31"));
        System.out.println(center.vSosescini(1, 1, "i20"));
        System.out.println(center.vSosescini(1, 1, "i5"));
        System.out.println(center.vSosescini(2, 1, "i31"));
        System.out.println(center.vSosescini(5, 1, "i26"));
        System.out.println(center.vSosescini(1, 1, "i36"));
        System.out.println(center.vSosescini(2, 1, "i24"));
        System.out.println(center.vSosescini(2, 1, "i39"));
        System.out.println(center.vSosescini(4, 1, "i21"));
        System.out.println(center.vSosescini(1, 1, "i0"));
        System.out.println(center.vSosescini(1, 1, "i25"));
        System.out.println(center.vSosescini(4, 1, "i0"));
    }
}
