
import java.util.Arrays;

public class Test35 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 46);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 52);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 78);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 69);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 1);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 89);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 62);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 44);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 52);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 53);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 90);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 32);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 34);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 72);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 71);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 18);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 28);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 76);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 3);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 32);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 32);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 64);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 1);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 46);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 86);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 23);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 19);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 8);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 46);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 41);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 28);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 60);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 56);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 92);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 84);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 76);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 96);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 74);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 7);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 91);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 30);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 97);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[3][3];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i16, i12, i6, i2}, new int[]{4, 4, 4, 3, 1});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i37, i18}, new int[]{2, 1, 0});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i23}, new int[]{0, 7});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i1, i3, i26, i23}, new int[]{8, 9, 5, 0, 0});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i1, i6}, new int[]{6, 4, 8});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i24, i7}, new int[]{8, 3, 3});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i24, i31}, new int[]{6, 3, 1});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 1, "i15"));
        System.out.println(center.vSosescini(1, 1, "i7"));
        System.out.println(center.vSosescini(1, 1, "i18"));
        System.out.println(center.vSosescini(1, 1, "i37"));
        System.out.println(center.vSosescini(1, 1, "i0"));
        System.out.println(center.vSosescini(1, 1, "i17"));
        System.out.println(center.vSosescini(1, 1, "i34"));
        System.out.println(center.vSosescini(1, 1, "i6"));
        System.out.println(center.vSosescini(1, 1, "i5"));
        System.out.println(center.vSosescini(1, 1, "i33"));
        System.out.println(center.vSosescini(1, 1, "i36"));
        System.out.println(center.vSosescini(1, 1, "i20"));
        System.out.println(center.vSosescini(1, 1, "i32"));
        System.out.println(center.vSosescini(1, 1, "i37"));
        System.out.println(center.vSosescini(1, 1, "i2"));
        System.out.println(center.vSosescini(1, 1, "i36"));
        System.out.println(center.vSosescini(1, 1, "i17"));
        System.out.println(center.vSosescini(1, 1, "i9"));
        System.out.println(center.vSosescini(1, 1, "i6"));
        System.out.println(center.vSosescini(1, 1, "i23"));
    }
}
