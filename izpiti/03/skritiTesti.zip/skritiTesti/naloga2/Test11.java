
import java.util.Arrays;

public class Test11 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 33),
            new Druga.Izdelek("i1", 9),
            new Druga.Izdelek("i2", 46),
            new Druga.Izdelek("i3", 90),
            new Druga.Izdelek("i4", 87),
            new Druga.Izdelek("i5", 51),
            new Druga.Izdelek("i6", 66),
            new Druga.Izdelek("i7", 32),
            new Druga.Izdelek("i8", 44),
            new Druga.Izdelek("i9", 77),
            new Druga.Izdelek("i10", 84),
            new Druga.Izdelek("i11", 10),
            new Druga.Izdelek("i12", 52),
            new Druga.Izdelek("i13", 83),
            new Druga.Izdelek("i14", 12),
            new Druga.Izdelek("i15", 9),
            new Druga.Izdelek("i16", 98),
            new Druga.Izdelek("i17", 70),
            new Druga.Izdelek("i18", 41),
            new Druga.Izdelek("i19", 1),
            new Druga.Izdelek("i20", 94),
            new Druga.Izdelek("i21", 21),
            new Druga.Izdelek("i22", 67),
            new Druga.Izdelek("i23", 31),
            new Druga.Izdelek("i24", 75),
            new Druga.Izdelek("i25", 27),
        };
        int[] zaloga = {7, 4, 7, 7, 5, 4, 0, 0, 4, 4, 2, 1, 1, 4, 0, 4, 1, 9, 9, 2, 9, 6, 1, 1, 6, 9};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i28"));
        System.out.println(trgovina.poisciIzdelek("i26"));
        System.out.println(trgovina.poisciIzdelek("i43"));
        System.out.println(trgovina.poisciIzdelek("i35"));
        System.out.println(trgovina.poisciIzdelek("i39"));
        System.out.println(trgovina.poisciIzdelek("i2"));
    }
}
