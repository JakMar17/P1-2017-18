
import java.util.Arrays;

public class Test37 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 70);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 37);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 64);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 18);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 80);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 26);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 79);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 82);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 63);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 45);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 9);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 18);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 54);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 6);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 47);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 72);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 21);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 94);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 94);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 35);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 72);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 68);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 27);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 29);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 95);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 3);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 45);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 63);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 31);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 88);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 71);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 19);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 24);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 43);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 22);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 11);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 20);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 81);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 63);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 55);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 3);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 19);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[7][3];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i26, i17, i37, i36}, new int[]{7, 3, 1, 4, 3});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i5, i32}, new int[]{1, 6, 9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i24}, new int[]{1, 3});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i33, i31, i1}, new int[]{5, 2, 8, 4});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i2, i40, i21, i28}, new int[]{9, 8, 5, 2, 0});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i41, i15, i32, i11}, new int[]{2, 2, 7, 9, 8});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i23, i37, i18}, new int[]{6, 2, 4, 7});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i21}, new int[]{3});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i38}, new int[]{2, 7});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{0});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i29, i30, i4, i8}, new int[]{2, 9, 0, 7, 2});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i5}, new int[]{2});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i25, i15}, new int[]{2, 0, 4});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i6, i16}, new int[]{9, 0, 5});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i30, i39, i25}, new int[]{6, 2, 3, 8});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i28}, new int[]{3, 6});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i4, i39}, new int[]{6, 9, 1});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i0, i23, i41, i30}, new int[]{5, 6, 5, 4, 8});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i21, i5, i19}, new int[]{2, 0, 4, 1});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(2, 1, "i11"));
        System.out.println(center.vSosescini(5, 1, "i18"));
        System.out.println(center.vSosescini(4, 1, "i22"));
        System.out.println(center.vSosescini(5, 1, "i25"));
        System.out.println(center.vSosescini(4, 1, "i26"));
        System.out.println(center.vSosescini(1, 1, "i17"));
        System.out.println(center.vSosescini(4, 1, "i37"));
        System.out.println(center.vSosescini(1, 1, "i4"));
        System.out.println(center.vSosescini(1, 1, "i12"));
        System.out.println(center.vSosescini(2, 1, "i33"));
        System.out.println(center.vSosescini(5, 1, "i29"));
        System.out.println(center.vSosescini(4, 1, "i30"));
        System.out.println(center.vSosescini(3, 1, "i28"));
        System.out.println(center.vSosescini(2, 1, "i20"));
        System.out.println(center.vSosescini(1, 1, "i12"));
        System.out.println(center.vSosescini(3, 1, "i6"));
        System.out.println(center.vSosescini(2, 1, "i34"));
        System.out.println(center.vSosescini(3, 1, "i25"));
        System.out.println(center.vSosescini(2, 1, "i39"));
        System.out.println(center.vSosescini(3, 1, "i13"));
    }
}
