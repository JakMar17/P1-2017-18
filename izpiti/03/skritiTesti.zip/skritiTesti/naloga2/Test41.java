
import java.util.Arrays;

public class Test41 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 75);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 98);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 97);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 65);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 70);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 29);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 82);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 53);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 84);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 45);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 88);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 25);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 7);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 44);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 88);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 78);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 88);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 17);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 60);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 42);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 66);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 20);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 50);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 51);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 30);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 29);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 38);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 5);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 37);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 51);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 60);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 94);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 5);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 81);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 30);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 87);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 47);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 92);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 42);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 70);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 59);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 74);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][10];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i8, i9, i41, i4}, new int[]{6, 0, 6, 9, 1});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i10, i25}, new int[]{3, 5, 4});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i36, i9, i21, i40}, new int[]{3, 8, 8, 7, 4});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i27, i9}, new int[]{4, 7, 9});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i2}, new int[]{1, 9});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i5}, new int[]{9, 7});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i37, i13, i38}, new int[]{9, 9, 0, 1});
        trgovine[0][9] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i1, i24, i6, i28}, new int[]{0, 1, 4, 9, 3});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i31, i15}, new int[]{8, 8, 4});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i35}, new int[]{0});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i32, i26, i4}, new int[]{3, 7, 0, 6});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i30, i13, i24, i16}, new int[]{2, 3, 5, 0, 5});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i17, i26, i28, i15}, new int[]{4, 0, 4, 6, 4});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i13}, new int[]{1});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i1, i30, i40, i24}, new int[]{7, 3, 5, 0, 5});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i13, i6, i15}, new int[]{9, 7, 5, 7});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i30, i12, i26}, new int[]{6, 1, 6, 7});
        trgovine[1][9] = new Druga.Trgovina(new Druga.Izdelek[]{i21}, new int[]{2});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i32}, new int[]{8});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i7}, new int[]{0, 0});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i37, i7, i35, i32}, new int[]{0, 1, 7, 8, 6});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i4, i39, i13}, new int[]{3, 7, 2, 5});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i24}, new int[]{9, 8});
        trgovine[2][9] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i25, i16, i37}, new int[]{4, 7, 1, 5});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i5, i10}, new int[]{4, 0, 1});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i32, i41, i19}, new int[]{2, 1, 1, 2});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i17, i18, i33}, new int[]{0, 6, 6, 7});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i13, i30, i6, i0}, new int[]{6, 4, 7, 4, 0});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i5}, new int[]{6});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i7, i5, i39, i40}, new int[]{1, 4, 2, 9, 6});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i40, i25, i33}, new int[]{2, 9, 2, 7});
        trgovine[3][9] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i3, i33}, new int[]{0, 0, 1});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i12}, new int[]{3, 5});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i9, i34, i29}, new int[]{5, 2, 0, 5});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i7}, new int[]{0, 6});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i13, i11}, new int[]{7, 1, 8});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i38, i17, i36, i13}, new int[]{9, 1, 3, 5, 2});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i25}, new int[]{6});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i35, i4, i2}, new int[]{5, 8, 7, 8});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i2, i26, i20, i33}, new int[]{8, 9, 9, 0, 2});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i27, i17}, new int[]{3, 3, 5});
        trgovine[4][9] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i32, i13, i1, i31}, new int[]{4, 1, 0, 3, 3});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i39}, new int[]{9, 6});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i17, i3, i32, i38}, new int[]{3, 0, 1, 9, 6});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i22}, new int[]{6});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i9, i3, i31}, new int[]{9, 7, 6, 4});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i5, i25, i13, i40}, new int[]{9, 9, 7, 3, 9});
        trgovine[5][7] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i18, i1, i19}, new int[]{9, 7, 6, 8});
        trgovine[5][8] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i19}, new int[]{3, 8});
        trgovine[5][9] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i30}, new int[]{2, 5});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i36}, new int[]{1, 9});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i14, i17, i30, i5}, new int[]{0, 4, 1, 8, 2});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i15, i4, i9}, new int[]{4, 1, 1, 5});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i29}, new int[]{8});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i28, i0, i39}, new int[]{4, 1, 9, 1});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i4}, new int[]{2, 2});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i16, i41}, new int[]{8, 6, 5});
        trgovine[6][7] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i24, i22, i5, i37}, new int[]{6, 1, 1, 0, 5});
        trgovine[6][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][9] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i30}, new int[]{8, 8});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i35, i25, i23, i39}, new int[]{4, 4, 9, 5, 5});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i31}, new int[]{2});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i16}, new int[]{8, 6});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i27, i24}, new int[]{7, 2, 1});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i25}, new int[]{2});
        trgovine[7][7] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i9, i28, i4, i11}, new int[]{7, 0, 3, 3, 6});
        trgovine[7][8] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i12, i17}, new int[]{0, 0, 2});
        trgovine[7][9] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i27}, new int[]{4, 7});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            {-1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            {-1,  0},
            {-1,  0},
            {-1,  0},
            { 0, -1},
            {-1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            {-1,  0},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
        };

        System.out.println(center.pohod(premiki, "i11"));
        System.out.println(center.pohod(premiki, "i37"));
        System.out.println(center.pohod(premiki, "i24"));
        System.out.println(center.pohod(premiki, "i1"));
        System.out.println(center.pohod(premiki, "i29"));
        System.out.println(center.pohod(premiki, "i19"));
        System.out.println(center.pohod(premiki, "i5"));
        System.out.println(center.pohod(premiki, "i32"));
        System.out.println(center.pohod(premiki, "i21"));
        System.out.println(center.pohod(premiki, "i34"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
