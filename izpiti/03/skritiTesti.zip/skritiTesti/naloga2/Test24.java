
import java.util.Arrays;

public class Test24 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 68),
            new Druga.Izdelek("i1", 87),
            new Druga.Izdelek("i2", 59),
            new Druga.Izdelek("i3", 55),
            new Druga.Izdelek("i4", 28),
            new Druga.Izdelek("i5", 62),
            new Druga.Izdelek("i6", 84),
            new Druga.Izdelek("i7", 15),
            new Druga.Izdelek("i8", 81),
            new Druga.Izdelek("i9", 5),
            new Druga.Izdelek("i10", 67),
            new Druga.Izdelek("i11", 17),
            new Druga.Izdelek("i12", 60),
            new Druga.Izdelek("i13", 38),
            new Druga.Izdelek("i14", 16),
            new Druga.Izdelek("i15", 57),
            new Druga.Izdelek("i16", 70),
            new Druga.Izdelek("i17", 89),
            new Druga.Izdelek("i18", 86),
            new Druga.Izdelek("i19", 41),
            new Druga.Izdelek("i20", 89),
            new Druga.Izdelek("i21", 73),
            new Druga.Izdelek("i22", 3),
            new Druga.Izdelek("i23", 3),
            new Druga.Izdelek("i24", 30),
            new Druga.Izdelek("i25", 78),
            new Druga.Izdelek("i26", 71),
            new Druga.Izdelek("i27", 9),
        };
        int[] zaloga = {9, 7, 6, 8, 5, 10, 5, 5, 0, 3, 7, 0, 4, 8, 7, 4, 6, 1, 1, 1, 7, 0, 2, 4, 1, 4, 7, 3};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(12, 4));
        System.out.println(trgovina.prodaj(27, 1));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
