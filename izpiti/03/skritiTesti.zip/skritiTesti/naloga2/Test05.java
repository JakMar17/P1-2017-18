
import java.util.Arrays;

public class Test05 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 50),
            new Druga.Izdelek("i1", 54),
            new Druga.Izdelek("i2", 4),
            new Druga.Izdelek("i3", 55),
            new Druga.Izdelek("i4", 96),
            new Druga.Izdelek("i5", 21),
            new Druga.Izdelek("i6", 45),
            new Druga.Izdelek("i7", 78),
            new Druga.Izdelek("i8", 84),
            new Druga.Izdelek("i9", 27),
            new Druga.Izdelek("i10", 74),
            new Druga.Izdelek("i11", 18),
            new Druga.Izdelek("i12", 56),
            new Druga.Izdelek("i13", 11),
            new Druga.Izdelek("i14", 86),
            new Druga.Izdelek("i15", 12),
            new Druga.Izdelek("i16", 76),
            new Druga.Izdelek("i17", 15),
            new Druga.Izdelek("i18", 28),
            new Druga.Izdelek("i19", 6),
            new Druga.Izdelek("i20", 16),
            new Druga.Izdelek("i21", 45),
            new Druga.Izdelek("i22", 42),
            new Druga.Izdelek("i23", 48),
        };
        int[] zaloga = {9, 0, 0, 4, 0, 3, 6, 6, 10, 7, 0, 3, 5, 6, 10, 9, 0, 4, 10, 0, 6, 1, 2, 6};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i20"));
        System.out.println(trgovina.poisciIzdelek("i5"));
        System.out.println(trgovina.poisciIzdelek("i16"));
        System.out.println(trgovina.poisciIzdelek("i12"));
        System.out.println(trgovina.poisciIzdelek("i19"));
        System.out.println(trgovina.poisciIzdelek("i14"));
        System.out.println(trgovina.poisciIzdelek("i10"));
        System.out.println(trgovina.poisciIzdelek("i21"));
        System.out.println(trgovina.poisciIzdelek("i7"));
    }
}
