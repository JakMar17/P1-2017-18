
import java.util.Arrays;

public class Test15 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 90),
            new Druga.Izdelek("i1", 33),
            new Druga.Izdelek("i2", 78),
            new Druga.Izdelek("i3", 21),
            new Druga.Izdelek("i4", 82),
            new Druga.Izdelek("i5", 48),
            new Druga.Izdelek("i6", 67),
            new Druga.Izdelek("i7", 41),
            new Druga.Izdelek("i8", 46),
            new Druga.Izdelek("i9", 14),
            new Druga.Izdelek("i10", 90),
            new Druga.Izdelek("i11", 99),
            new Druga.Izdelek("i12", 10),
            new Druga.Izdelek("i13", 5),
            new Druga.Izdelek("i14", 99),
            new Druga.Izdelek("i15", 37),
            new Druga.Izdelek("i16", 5),
            new Druga.Izdelek("i17", 59),
            new Druga.Izdelek("i18", 77),
        };
        int[] zaloga = {8, 8, 4, 7, 2, 2, 5, 6, 1, 2, 8, 3, 6, 7, 9, 6, 10, 4, 3};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(9, 1));
        System.out.println(trgovina.prodaj(6, 5));
        System.out.println(trgovina.prodaj(10, 2));
        System.out.println(trgovina.prodaj(15, 1));
        System.out.println(trgovina.prodaj(17, 2));
        System.out.println(trgovina.prodaj(17, 1));
        System.out.println(trgovina.prodaj(0, 2));
        System.out.println(trgovina.prodaj(0, 4));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
