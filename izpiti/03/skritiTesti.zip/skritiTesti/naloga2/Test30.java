
import java.util.Arrays;

public class Test30 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 53);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 57);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 67);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 36);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 21);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 23);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 68);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 91);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 70);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 0);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 65);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 49);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 25);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 18);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 78);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 3);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 96);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 21);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 11);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 5);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 0);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 96);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 70);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 24);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 6);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 72);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 52);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 55);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 73);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 43);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 81);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 46);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 28);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 10);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 62);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 74);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 4);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 45);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 29);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 45);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 67);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 33);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][6];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i12}, new int[]{6, 8});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i11, i9, i1, i39}, new int[]{5, 8, 0, 3, 5});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i30, i1, i31, i39}, new int[]{4, 5, 1, 1, 5});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i10, i22}, new int[]{3, 2, 2});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i23, i6, i3}, new int[]{4, 4, 3, 6});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i22}, new int[]{7, 8});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i23}, new int[]{9});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i0, i41, i11}, new int[]{2, 0, 7, 2});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i23}, new int[]{8, 2});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i19}, new int[]{8});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i8}, new int[]{4, 9});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i28}, new int[]{9, 1});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i26, i8, i33}, new int[]{5, 3, 9, 6});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i4, i13}, new int[]{4, 1, 8});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15}, new int[]{1});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i40, i25}, new int[]{0, 4, 5});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i0}, new int[]{3, 2});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i38}, new int[]{1});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i38, i16}, new int[]{7, 9, 6});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i14}, new int[]{7});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i30, i18, i26, i7}, new int[]{3, 6, 5, 7, 6});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i12, i9}, new int[]{3, 9, 9});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i26}, new int[]{0, 8});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i20, i9, i34, i17}, new int[]{5, 0, 9, 3, 9});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{4});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i4, i31}, new int[]{7, 7, 9});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i12}, new int[]{7, 7});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i0}, new int[]{5, 5});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41}, new int[]{8});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i39, i30}, new int[]{9, 5, 9});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i5, i12}, new int[]{1, 2, 1});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i13}, new int[]{3, 4});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i4, i20, i35}, new int[]{6, 6, 5, 2});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i6}, new int[]{2, 9});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i23, i6, i39, i34}, new int[]{1, 2, 5, 6, 2});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i19, i37, i23}, new int[]{1, 5, 5, 6});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i19}, new int[]{6});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{0});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(5, 4, "i1"));
        System.out.println(center.vSosescini(5, 4, "i36"));
        System.out.println(center.vSosescini(4, 2, "i21"));
        System.out.println(center.vSosescini(4, 1, "i6"));
        System.out.println(center.vSosescini(4, 2, "i30"));
        System.out.println(center.vSosescini(4, 4, "i33"));
        System.out.println(center.vSosescini(2, 2, "i7"));
        System.out.println(center.vSosescini(3, 4, "i39"));
        System.out.println(center.vSosescini(3, 1, "i37"));
        System.out.println(center.vSosescini(6, 2, "i37"));
        System.out.println(center.vSosescini(2, 3, "i14"));
        System.out.println(center.vSosescini(2, 3, "i19"));
        System.out.println(center.vSosescini(2, 1, "i0"));
        System.out.println(center.vSosescini(1, 1, "i8"));
        System.out.println(center.vSosescini(2, 3, "i39"));
        System.out.println(center.vSosescini(2, 4, "i29"));
        System.out.println(center.vSosescini(6, 4, "i34"));
        System.out.println(center.vSosescini(1, 2, "i30"));
        System.out.println(center.vSosescini(5, 2, "i26"));
        System.out.println(center.vSosescini(6, 3, "i35"));
    }
}
