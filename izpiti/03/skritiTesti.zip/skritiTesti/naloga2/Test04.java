
import java.util.Arrays;

public class Test04 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 38),
            new Druga.Izdelek("i1", 17),
            new Druga.Izdelek("i2", 31),
            new Druga.Izdelek("i3", 88),
            new Druga.Izdelek("i4", 91),
            new Druga.Izdelek("i5", 96),
            new Druga.Izdelek("i6", 90),
            new Druga.Izdelek("i7", 37),
            new Druga.Izdelek("i8", 64),
            new Druga.Izdelek("i9", 13),
            new Druga.Izdelek("i10", 48),
            new Druga.Izdelek("i11", 5),
            new Druga.Izdelek("i12", 20),
            new Druga.Izdelek("i13", 53),
        };
        int[] zaloga = {4, 9, 9, 9, 5, 1, 4, 3, 7, 9, 9, 6, 5, 1};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i1"));
        System.out.println(trgovina.poisciIzdelek("i9"));
        System.out.println(trgovina.poisciIzdelek("i4"));
        System.out.println(trgovina.poisciIzdelek("i7"));
        System.out.println(trgovina.poisciIzdelek("i0"));
        System.out.println(trgovina.poisciIzdelek("i6"));
        System.out.println(trgovina.poisciIzdelek("i12"));
        System.out.println(trgovina.poisciIzdelek("i10"));
        System.out.println(trgovina.poisciIzdelek("i5"));
        System.out.println(trgovina.poisciIzdelek("i11"));
    }
}
