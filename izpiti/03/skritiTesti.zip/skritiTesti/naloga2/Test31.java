
import java.util.Arrays;

public class Test31 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 18);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 93);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 98);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 13);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 81);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 22);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 69);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 64);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 79);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 78);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 99);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 92);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 16);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 62);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 78);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 83);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 28);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 15);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 41);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 63);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 64);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 45);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 7);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 83);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 25);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 47);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 44);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 26);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 87);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 20);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 50);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 20);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 71);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 96);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 72);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 91);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 88);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 67);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 73);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 92);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 59);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 75);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[9][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i38}, new int[]{0});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i11, i29}, new int[]{9, 6, 5});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i15, i32, i24, i25}, new int[]{1, 5, 6, 6, 8});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i30}, new int[]{4, 7});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i9}, new int[]{4});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{5});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i8}, new int[]{0, 0});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i6, i18, i14, i12}, new int[]{1, 3, 1, 3, 9});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i36}, new int[]{4});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i17, i18, i37, i9}, new int[]{8, 1, 7, 6, 2});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i16}, new int[]{6, 3});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i10}, new int[]{4, 9});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i31}, new int[]{0, 7});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i5, i29}, new int[]{2, 2, 4});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i0}, new int[]{9, 6});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i31, i39, i24, i15}, new int[]{9, 4, 0, 1, 0});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i2}, new int[]{7, 7});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i38, i35, i29, i32}, new int[]{8, 7, 7, 7, 5});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i13}, new int[]{3});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i5, i21, i31}, new int[]{5, 2, 5, 9});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i28, i16}, new int[]{6, 5, 2});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i38}, new int[]{2, 2});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i0, i41}, new int[]{6, 7, 8});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i10}, new int[]{9});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i23, i11, i35, i0}, new int[]{5, 5, 3, 9, 1});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i20}, new int[]{4, 9});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i30, i5, i23, i36}, new int[]{9, 2, 9, 3, 5});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i16}, new int[]{7, 8});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i19}, new int[]{3});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i30}, new int[]{1});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i25}, new int[]{7});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i27}, new int[]{2, 1});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i18, i39, i21}, new int[]{2, 8, 5, 0});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i28}, new int[]{7});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i10, i1}, new int[]{3, 8, 9});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i20, i31, i32, i35}, new int[]{6, 9, 9, 8, 2});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i18}, new int[]{3});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i16, i22, i1}, new int[]{6, 6, 6, 8});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i12, i36}, new int[]{1, 8, 0});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i16}, new int[]{4, 2});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i23, i34, i30}, new int[]{0, 8, 6, 4});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i15, i39, i14, i36}, new int[]{9, 6, 3, 0, 6});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i4, i38, i17}, new int[]{0, 9, 6, 4});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i24, i22}, new int[]{5, 8, 8});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i24, i26}, new int[]{1, 9, 0});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i35}, new int[]{8, 6});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i15, i40}, new int[]{6, 6, 5});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i11}, new int[]{4, 6});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i17, i33, i4}, new int[]{2, 7, 0, 0});

        trgovine[8][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[8][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i8, i28, i16}, new int[]{3, 4, 1, 3});
        trgovine[8][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[8][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[8][4] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i40, i38, i41}, new int[]{8, 8, 8, 1});
        trgovine[8][5] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i17}, new int[]{6, 6});
        trgovine[8][6] = new Druga.Trgovina(new Druga.Izdelek[]{i19}, new int[]{5});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 4, "i21"));
        System.out.println(center.vSosescini(7, 3, "i29"));
        System.out.println(center.vSosescini(5, 5, "i21"));
        System.out.println(center.vSosescini(2, 2, "i35"));
        System.out.println(center.vSosescini(7, 2, "i39"));
        System.out.println(center.vSosescini(2, 2, "i5"));
        System.out.println(center.vSosescini(5, 4, "i26"));
        System.out.println(center.vSosescini(3, 2, "i1"));
        System.out.println(center.vSosescini(4, 5, "i7"));
        System.out.println(center.vSosescini(3, 2, "i39"));
        System.out.println(center.vSosescini(1, 2, "i33"));
        System.out.println(center.vSosescini(6, 2, "i32"));
        System.out.println(center.vSosescini(4, 5, "i2"));
        System.out.println(center.vSosescini(2, 2, "i33"));
        System.out.println(center.vSosescini(6, 1, "i24"));
        System.out.println(center.vSosescini(2, 5, "i28"));
        System.out.println(center.vSosescini(3, 4, "i13"));
        System.out.println(center.vSosescini(3, 2, "i3"));
        System.out.println(center.vSosescini(1, 4, "i29"));
        System.out.println(center.vSosescini(5, 2, "i4"));
    }
}
