
import java.util.Arrays;

public class Test22 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 58),
            new Druga.Izdelek("i1", 23),
            new Druga.Izdelek("i2", 82),
            new Druga.Izdelek("i3", 34),
            new Druga.Izdelek("i4", 94),
            new Druga.Izdelek("i5", 57),
            new Druga.Izdelek("i6", 10),
            new Druga.Izdelek("i7", 47),
            new Druga.Izdelek("i8", 16),
            new Druga.Izdelek("i9", 39),
            new Druga.Izdelek("i10", 19),
            new Druga.Izdelek("i11", 10),
            new Druga.Izdelek("i12", 11),
        };
        int[] zaloga = {9, 9, 7, 0, 7, 4, 4, 3, 4, 9, 1, 2, 7};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(8, 4));
        System.out.println(trgovina.prodaj(0, 6));
        System.out.println(trgovina.prodaj(6, 8));
        System.out.println(trgovina.prodaj(9, 1));
        System.out.println(trgovina.prodaj(0, 6));
        System.out.println(trgovina.prodaj(3, 2));
        System.out.println(trgovina.prodaj(10, 8));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
