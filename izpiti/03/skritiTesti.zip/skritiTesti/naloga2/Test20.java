
import java.util.Arrays;

public class Test20 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 25),
            new Druga.Izdelek("i1", 11),
            new Druga.Izdelek("i2", 67),
            new Druga.Izdelek("i3", 13),
            new Druga.Izdelek("i4", 85),
            new Druga.Izdelek("i5", 33),
            new Druga.Izdelek("i6", 51),
            new Druga.Izdelek("i7", 58),
            new Druga.Izdelek("i8", 100),
            new Druga.Izdelek("i9", 97),
            new Druga.Izdelek("i10", 49),
            new Druga.Izdelek("i11", 99),
            new Druga.Izdelek("i12", 15),
            new Druga.Izdelek("i13", 100),
            new Druga.Izdelek("i14", 46),
            new Druga.Izdelek("i15", 29),
            new Druga.Izdelek("i16", 10),
            new Druga.Izdelek("i17", 44),
            new Druga.Izdelek("i18", 22),
            new Druga.Izdelek("i19", 71),
            new Druga.Izdelek("i20", 1),
            new Druga.Izdelek("i21", 64),
            new Druga.Izdelek("i22", 33),
            new Druga.Izdelek("i23", 100),
            new Druga.Izdelek("i24", 83),
            new Druga.Izdelek("i25", 1),
            new Druga.Izdelek("i26", 32),
            new Druga.Izdelek("i27", 82),
            new Druga.Izdelek("i28", 10),
            new Druga.Izdelek("i29", 31),
        };
        int[] zaloga = {7, 3, 10, 6, 6, 6, 5, 2, 10, 1, 5, 4, 5, 4, 4, 2, 8, 5, 6, 6, 2, 2, 8, 7, 2, 3, 6, 7, 9, 6};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(14, 5));
        System.out.println(trgovina.prodaj(18, 4));
        System.out.println(trgovina.prodaj(18, 5));
        System.out.println(trgovina.prodaj(22, 6));
        System.out.println(trgovina.prodaj(17, 6));
        System.out.println(trgovina.prodaj(9, 6));
        System.out.println(trgovina.prodaj(0, 2));
        System.out.println(trgovina.prodaj(17, 5));
        System.out.println(trgovina.prodaj(14, 8));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
