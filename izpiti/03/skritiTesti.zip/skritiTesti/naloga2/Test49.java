
import java.util.Arrays;

public class Test49 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 78);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 40);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 42);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 56);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 1);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 40);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 79);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 83);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 34);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 84);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 85);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 5);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 70);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 51);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 58);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 5);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 49);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 97);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 24);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 49);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 28);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 37);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 55);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 90);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 0);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 14);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 28);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 89);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 74);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 99);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 16);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 45);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 30);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 74);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 40);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 63);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 70);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 87);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 79);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 85);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 26);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 32);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[5][9];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i37, i13}, new int[]{4, 0, 1});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i19, i37}, new int[]{5, 4, 9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{7});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i23, i36, i1, i16}, new int[]{6, 2, 7, 7, 4});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i25, i19}, new int[]{6, 8, 4});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i26, i41, i7, i1}, new int[]{3, 7, 6, 6, 5});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i29, i0, i6, i26}, new int[]{9, 4, 4, 2, 7});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i25, i28, i39}, new int[]{2, 1, 0, 8});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i12, i17}, new int[]{9, 5, 0});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i40, i41, i15, i6}, new int[]{4, 2, 7, 4, 1});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i1}, new int[]{8, 2});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i31}, new int[]{0, 7});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i2, i23, i1}, new int[]{9, 6, 4, 1});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i3}, new int[]{4, 8});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i9}, new int[]{2});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i32}, new int[]{9});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i37, i27, i12, i10}, new int[]{7, 5, 4, 6, 1});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i7, i21, i14}, new int[]{2, 9, 7, 9});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i6}, new int[]{6, 5});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i37}, new int[]{1, 0});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15}, new int[]{1});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i13}, new int[]{8});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i10, i27}, new int[]{4, 5, 4});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i32}, new int[]{2, 0});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i5, i11, i16, i23}, new int[]{5, 9, 1, 4, 0});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i26, i30, i25}, new int[]{3, 5, 8, 6});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i13}, new int[]{1});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i12, i30, i8, i14}, new int[]{9, 3, 2, 6, 7});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i33, i10, i3, i5}, new int[]{3, 5, 9, 6, 2});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i17, i32, i18, i14}, new int[]{4, 8, 4, 8, 1});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i24}, new int[]{1, 7});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i28, i11, i40, i9}, new int[]{5, 8, 5, 4, 1});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i34}, new int[]{2, 4});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i29}, new int[]{4, 4});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            {-1,  0},
            {-1,  0},
        };

        System.out.println(center.pohod(premiki, "i34"));
        System.out.println(center.pohod(premiki, "i32"));
        System.out.println(center.pohod(premiki, "i15"));
        System.out.println(center.pohod(premiki, "i0"));
        System.out.println(center.pohod(premiki, "i11"));
        System.out.println(center.pohod(premiki, "i6"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i31"));
        System.out.println(center.pohod(premiki, "i23"));
        System.out.println(center.pohod(premiki, "i39"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
