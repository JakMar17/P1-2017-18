
import java.util.Arrays;

public class Test12 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 42),
            new Druga.Izdelek("i1", 11),
            new Druga.Izdelek("i2", 57),
            new Druga.Izdelek("i3", 23),
            new Druga.Izdelek("i4", 12),
            new Druga.Izdelek("i5", 77),
            new Druga.Izdelek("i6", 69),
            new Druga.Izdelek("i7", 29),
            new Druga.Izdelek("i8", 85),
            new Druga.Izdelek("i9", 23),
            new Druga.Izdelek("i10", 78),
            new Druga.Izdelek("i11", 19),
            new Druga.Izdelek("i12", 16),
            new Druga.Izdelek("i13", 27),
            new Druga.Izdelek("i14", 36),
        };
        int[] zaloga = {10, 6, 5, 3, 6, 7, 3, 7, 9, 2, 8, 3, 10, 0, 10};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i13"));
        System.out.println(trgovina.poisciIzdelek("i9"));
        System.out.println(trgovina.poisciIzdelek("i11"));
        System.out.println(trgovina.poisciIzdelek("i4"));
        System.out.println(trgovina.poisciIzdelek("i5"));
        System.out.println(trgovina.poisciIzdelek("i3"));
    }
}
