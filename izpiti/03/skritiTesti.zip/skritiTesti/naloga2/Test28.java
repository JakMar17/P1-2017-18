
import java.util.Arrays;

public class Test28 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 56);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 62);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 73);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 20);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 83);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 83);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 91);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 69);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 40);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 20);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 73);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 80);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 88);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 41);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 63);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 13);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 42);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 92);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 68);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 76);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 35);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 21);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 0);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 28);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 55);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 86);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 20);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 68);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 85);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 49);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 19);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 65);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 6);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 75);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 25);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 77);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 40);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 47);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 22);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 73);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 31);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 92);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[6][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i11}, new int[]{4});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i33}, new int[]{6, 6});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i37, i36}, new int[]{8, 2, 4});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i3}, new int[]{1});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i30, i9, i25}, new int[]{1, 0, 0, 6});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{8});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i6}, new int[]{6});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i30}, new int[]{0, 7});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i34, i15, i9}, new int[]{3, 3, 8, 4});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i21, i26}, new int[]{7, 8, 5});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i25, i6, i10, i37}, new int[]{5, 4, 8, 2, 7});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i20, i1, i31}, new int[]{9, 2, 3, 4});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i10, i32, i41, i16}, new int[]{2, 8, 0, 8, 1});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i34, i33, i6, i41}, new int[]{6, 4, 1, 7, 2});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i22, i8, i5}, new int[]{6, 0, 6, 2});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i37, i39}, new int[]{3, 3, 9});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{3});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i15, i20, i12}, new int[]{7, 3, 1, 5});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i32}, new int[]{2});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i23}, new int[]{0, 9});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i7, i37, i26, i13}, new int[]{2, 4, 6, 6, 0});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i33}, new int[]{6});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i17, i10, i36, i40}, new int[]{2, 2, 4, 2, 6});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i19, i8, i3}, new int[]{8, 8, 8, 8});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i10, i37}, new int[]{1, 4, 6});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i35}, new int[]{2, 6});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i15}, new int[]{9});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i38}, new int[]{9, 0});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i28, i22}, new int[]{2, 0, 1});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i20}, new int[]{0, 2});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i40, i33, i13}, new int[]{1, 8, 9, 9});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i4, i22}, new int[]{4, 8, 3});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i11, i23}, new int[]{9, 5, 8});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i29}, new int[]{1});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i25, i32, i15, i39}, new int[]{7, 5, 1, 5, 3});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i9}, new int[]{2});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i37, i23}, new int[]{6, 1, 6});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 5, "i8"));
        System.out.println(center.vSosescini(1, 4, "i31"));
        System.out.println(center.vSosescini(3, 1, "i37"));
        System.out.println(center.vSosescini(2, 1, "i41"));
        System.out.println(center.vSosescini(2, 2, "i9"));
        System.out.println(center.vSosescini(1, 3, "i33"));
        System.out.println(center.vSosescini(3, 4, "i11"));
        System.out.println(center.vSosescini(2, 2, "i2"));
        System.out.println(center.vSosescini(2, 2, "i18"));
        System.out.println(center.vSosescini(1, 1, "i38"));
        System.out.println(center.vSosescini(2, 4, "i19"));
        System.out.println(center.vSosescini(3, 4, "i31"));
        System.out.println(center.vSosescini(2, 2, "i11"));
        System.out.println(center.vSosescini(4, 4, "i0"));
        System.out.println(center.vSosescini(4, 2, "i15"));
        System.out.println(center.vSosescini(4, 2, "i22"));
        System.out.println(center.vSosescini(2, 4, "i40"));
        System.out.println(center.vSosescini(4, 1, "i9"));
        System.out.println(center.vSosescini(4, 4, "i11"));
        System.out.println(center.vSosescini(4, 3, "i40"));
    }
}
