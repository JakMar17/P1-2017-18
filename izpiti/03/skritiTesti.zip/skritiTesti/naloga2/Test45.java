
import java.util.Arrays;

public class Test45 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 81);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 22);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 66);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 15);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 71);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 96);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 30);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 100);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 90);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 6);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 90);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 17);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 19);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 23);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 17);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 2);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 86);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 25);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 51);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 16);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 21);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 87);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 2);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 11);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 69);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 96);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 33);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 19);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 2);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 66);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 44);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 78);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 71);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 33);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 36);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 65);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 69);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 98);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 92);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 55);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 48);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 80);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i25, i21, i5, i28}, new int[]{4, 3, 7, 0, 5});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i23}, new int[]{4, 7});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i20}, new int[]{0, 2});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i17}, new int[]{7});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i13, i23}, new int[]{3, 3, 0});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i33, i20, i22}, new int[]{4, 1, 9, 1});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i31, i39}, new int[]{3, 4, 5});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i26}, new int[]{9, 9});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i13, i38, i20}, new int[]{1, 1, 2, 7});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i39, i25}, new int[]{1, 4, 2});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i34, i18}, new int[]{9, 2, 3});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i24}, new int[]{5});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i5}, new int[]{3, 0});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i30}, new int[]{6});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i28, i20}, new int[]{5, 0, 9});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i18}, new int[]{9, 2});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i12, i17, i32, i14}, new int[]{9, 2, 3, 3, 1});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i32, i37}, new int[]{5, 0, 2});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i30}, new int[]{6, 2});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i36}, new int[]{3, 4});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i39, i21, i34}, new int[]{4, 2, 0, 2});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i7, i16, i36}, new int[]{9, 9, 0, 9});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i34, i27, i32}, new int[]{3, 0, 0, 7});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i10, i27, i1, i3}, new int[]{1, 4, 2, 3, 8});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i37, i40, i39}, new int[]{8, 3, 0, 5});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i33}, new int[]{6});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i7, i38, i10}, new int[]{3, 4, 1, 1});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i13, i37, i40}, new int[]{9, 4, 0, 5});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i26}, new int[]{1, 9});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i31}, new int[]{1});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i20}, new int[]{9, 3});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i20}, new int[]{7, 5});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i28, i0}, new int[]{3, 4, 8});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i22}, new int[]{9, 2});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i39}, new int[]{7, 7});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i12, i18, i10}, new int[]{1, 3, 0, 0});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i11, i0}, new int[]{1, 8, 8});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i16, i32, i20, i14}, new int[]{1, 4, 2, 6, 3});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i38}, new int[]{7});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i36}, new int[]{7, 2});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i30}, new int[]{0});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i25, i35, i7}, new int[]{8, 3, 9, 6});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i36, i32}, new int[]{8, 5, 7});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i2}, new int[]{7, 3});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i7, i5, i33}, new int[]{9, 8, 3, 7});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i11}, new int[]{5, 9});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i28, i3, i12}, new int[]{3, 7, 8, 4});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i32, i4}, new int[]{2, 9, 3});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            {-1,  0},
        };

        System.out.println(center.pohod(premiki, "i16"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i34"));
        System.out.println(center.pohod(premiki, "i24"));
        System.out.println(center.pohod(premiki, "i7"));
        System.out.println(center.pohod(premiki, "i40"));
        System.out.println(center.pohod(premiki, "i35"));
        System.out.println(center.pohod(premiki, "i39"));
        System.out.println(center.pohod(premiki, "i29"));
        System.out.println(center.pohod(premiki, "i10"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
