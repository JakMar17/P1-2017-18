
import java.util.Arrays;

public class Test38 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 29);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 16);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 66);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 60);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 28);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 54);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 92);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 51);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 29);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 15);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 39);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 51);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 19);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 44);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 14);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 24);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 60);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 40);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 27);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 65);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 3);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 90);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 5);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 67);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 86);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 31);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 47);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 93);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 14);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 12);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 38);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 43);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 55);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 71);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 28);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 62);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 78);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 70);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 91);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 5);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 26);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 42);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[6][5];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i40}, new int[]{8, 0});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i18, i10, i12}, new int[]{3, 9, 9, 3});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i13, i18, i37}, new int[]{2, 8, 0, 8});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i31, i41, i29, i3}, new int[]{2, 1, 8, 1, 3});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i8, i22, i28, i0}, new int[]{1, 6, 0, 3, 8});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i33, i5}, new int[]{4, 7, 4});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i41, i32}, new int[]{7, 8, 5});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i4}, new int[]{4, 7});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i6}, new int[]{2, 1});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i34, i17, i40}, new int[]{6, 7, 1, 8});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i9, i41}, new int[]{7, 6, 3});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i10, i30, i13, i11}, new int[]{1, 9, 3, 7, 8});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i5}, new int[]{7, 6});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i31, i9}, new int[]{3, 6, 0});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i7}, new int[]{0});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i1, i22, i26, i10}, new int[]{4, 6, 5, 0, 2});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i33, i31}, new int[]{5, 4, 7});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i15, i19}, new int[]{1, 6, 1});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i2}, new int[]{6});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i20}, new int[]{3, 9});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i13}, new int[]{6, 6});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i23}, new int[]{9});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i17, i27}, new int[]{9, 3, 4});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i36, i12, i19, i18}, new int[]{6, 0, 3, 1, 2});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i41, i38}, new int[]{1, 4, 1});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i32}, new int[]{5});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i2, i24, i41}, new int[]{6, 5, 3, 4});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i28, i20, i7, i16}, new int[]{4, 6, 8, 7, 5});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0, -1},
            {-1,  0},
        };

        System.out.println(center.pohod(premiki, "i26"));
        System.out.println(center.pohod(premiki, "i29"));
        System.out.println(center.pohod(premiki, "i5"));
        System.out.println(center.pohod(premiki, "i16"));
        System.out.println(center.pohod(premiki, "i28"));
        System.out.println(center.pohod(premiki, "i17"));
        System.out.println(center.pohod(premiki, "i14"));
        System.out.println(center.pohod(premiki, "i19"));
        System.out.println(center.pohod(premiki, "i20"));
        System.out.println(center.pohod(premiki, "i12"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
