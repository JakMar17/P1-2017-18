
import java.util.Arrays;

public class Test14 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 26),
            new Druga.Izdelek("i1", 19),
            new Druga.Izdelek("i2", 26),
            new Druga.Izdelek("i3", 7),
            new Druga.Izdelek("i4", 6),
            new Druga.Izdelek("i5", 14),
            new Druga.Izdelek("i6", 95),
            new Druga.Izdelek("i7", 27),
            new Druga.Izdelek("i8", 47),
            new Druga.Izdelek("i9", 84),
            new Druga.Izdelek("i10", 76),
            new Druga.Izdelek("i11", 61),
            new Druga.Izdelek("i12", 39),
            new Druga.Izdelek("i13", 38),
            new Druga.Izdelek("i14", 30),
            new Druga.Izdelek("i15", 29),
            new Druga.Izdelek("i16", 85),
            new Druga.Izdelek("i17", 74),
            new Druga.Izdelek("i18", 4),
            new Druga.Izdelek("i19", 83),
            new Druga.Izdelek("i20", 20),
            new Druga.Izdelek("i21", 40),
            new Druga.Izdelek("i22", 8),
            new Druga.Izdelek("i23", 59),
            new Druga.Izdelek("i24", 89),
            new Druga.Izdelek("i25", 47),
            new Druga.Izdelek("i26", 45),
            new Druga.Izdelek("i27", 88),
            new Druga.Izdelek("i28", 14),
        };
        int[] zaloga = {0, 6, 3, 7, 1, 10, 2, 5, 10, 8, 6, 9, 0, 6, 5, 9, 3, 2, 7, 9, 9, 9, 9, 1, 10, 4, 8, 3, 3};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(9, 1));
        System.out.println(trgovina.prodaj(11, 9));
        System.out.println(trgovina.prodaj(26, 4));
        System.out.println(trgovina.prodaj(16, 3));
        System.out.println(trgovina.prodaj(5, 3));
        System.out.println(trgovina.prodaj(22, 3));
        System.out.println(trgovina.prodaj(28, 2));
        System.out.println(trgovina.prodaj(7, 1));
        System.out.println(trgovina.prodaj(28, 1));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
