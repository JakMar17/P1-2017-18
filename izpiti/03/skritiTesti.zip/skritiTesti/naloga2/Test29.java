
import java.util.Arrays;

public class Test29 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 59);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 40);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 70);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 12);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 63);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 86);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 70);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 49);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 74);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 6);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 38);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 63);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 76);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 74);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 90);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 98);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 50);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 31);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 3);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 15);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 89);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 45);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 77);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 54);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 48);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 51);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 74);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 5);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 82);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 87);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 49);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 51);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 2);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 74);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 38);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 98);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 94);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 7);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 3);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 99);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 64);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 17);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[7][9];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i13, i40}, new int[]{3, 6, 2});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i0, i21, i40, i26}, new int[]{5, 5, 3, 8, 6});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i35}, new int[]{9});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i34, i26, i4, i36}, new int[]{0, 9, 1, 2, 9});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i39, i41, i0}, new int[]{6, 3, 4, 7});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i27, i9, i3, i13}, new int[]{4, 8, 0, 6, 1});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{i8}, new int[]{2});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i30}, new int[]{2, 0});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i8, i23}, new int[]{4, 2, 5});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i41, i3, i7}, new int[]{1, 8, 2, 8});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i14}, new int[]{3, 9});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i8, i35, i28}, new int[]{6, 0, 1, 6});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i40, i34}, new int[]{6, 5, 9});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i23, i8, i41}, new int[]{8, 5, 1, 9});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{i7}, new int[]{7});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i33, i15}, new int[]{7, 9, 5});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i28, i11, i30}, new int[]{7, 1, 7, 8});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i39, i8}, new int[]{3, 4, 4});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i12, i14, i38}, new int[]{8, 7, 3, 8});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i38, i33}, new int[]{8, 6, 9});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i33, i12, i15}, new int[]{2, 8, 0, 7});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i6, i28, i3, i16}, new int[]{2, 3, 0, 0, 6});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i24}, new int[]{0});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i5}, new int[]{4});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i0, i20, i21}, new int[]{9, 2, 7, 4});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{7});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i18, i31}, new int[]{4, 3, 9});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i31, i5, i23}, new int[]{2, 9, 3, 7});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i16, i10}, new int[]{3, 6, 0});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i35, i40}, new int[]{1, 3, 3});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i41, i20, i14, i33}, new int[]{8, 7, 9, 2, 7});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i30}, new int[]{0, 3});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{0});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15}, new int[]{6});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i29, i24, i31}, new int[]{0, 5, 5, 7});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i16, i7, i32, i24}, new int[]{0, 1, 9, 9, 4});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i26, i8}, new int[]{6, 1, 0});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i29, i13, i14}, new int[]{4, 6, 4, 2});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i10}, new int[]{2, 0});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i31, i39, i36}, new int[]{7, 0, 4, 2});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i6, i27, i19, i0}, new int[]{5, 7, 3, 2, 6});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i25}, new int[]{2, 0});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i25, i24}, new int[]{2, 1, 1});
        trgovine[5][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][8] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i27}, new int[]{9, 7});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i2, i1}, new int[]{5, 8, 6});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i35, i0}, new int[]{5, 1, 9});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i4}, new int[]{7});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i40, i22}, new int[]{6, 2, 6});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i16}, new int[]{4, 8});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i18, i31, i20, i25}, new int[]{7, 5, 5, 4, 8});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i1}, new int[]{3});
        trgovine[6][7] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i24, i10, i30, i23}, new int[]{5, 4, 2, 7, 2});
        trgovine[6][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 7, "i12"));
        System.out.println(center.vSosescini(4, 5, "i9"));
        System.out.println(center.vSosescini(3, 3, "i5"));
        System.out.println(center.vSosescini(4, 3, "i26"));
        System.out.println(center.vSosescini(4, 3, "i30"));
        System.out.println(center.vSosescini(2, 3, "i36"));
        System.out.println(center.vSosescini(2, 4, "i34"));
        System.out.println(center.vSosescini(1, 3, "i15"));
        System.out.println(center.vSosescini(1, 1, "i36"));
        System.out.println(center.vSosescini(2, 1, "i3"));
        System.out.println(center.vSosescini(4, 3, "i1"));
        System.out.println(center.vSosescini(5, 6, "i25"));
        System.out.println(center.vSosescini(4, 6, "i35"));
        System.out.println(center.vSosescini(5, 3, "i13"));
        System.out.println(center.vSosescini(3, 3, "i24"));
        System.out.println(center.vSosescini(3, 4, "i11"));
        System.out.println(center.vSosescini(3, 5, "i39"));
        System.out.println(center.vSosescini(3, 6, "i37"));
        System.out.println(center.vSosescini(4, 6, "i30"));
        System.out.println(center.vSosescini(4, 7, "i18"));
    }
}
