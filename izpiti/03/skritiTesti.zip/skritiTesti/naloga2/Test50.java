
import java.util.Arrays;

public class Test50 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 47);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 47);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 20);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 49);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 63);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 0);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 35);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 4);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 75);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 41);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 22);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 71);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 38);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 38);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 66);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 48);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 39);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 40);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 2);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 63);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 82);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 96);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 15);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 73);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 58);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 25);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 69);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 62);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 27);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 68);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 55);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 44);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 97);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 4);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 20);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 91);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 86);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 70);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 28);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 88);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 75);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 49);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][3];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i18, i15, i9}, new int[]{3, 3, 3, 3});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i21, i29}, new int[]{0, 3, 7});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i9, i34}, new int[]{9, 4, 2});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i11, i1, i9, i33}, new int[]{5, 3, 0, 5, 7});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i39, i19, i23, i11}, new int[]{4, 1, 4, 4, 8});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i11, i40, i30, i17}, new int[]{7, 0, 0, 8, 9});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i11}, new int[]{3, 2});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i8}, new int[]{8});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i14, i39, i25}, new int[]{7, 3, 6, 6});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i21, i23, i25}, new int[]{1, 1, 5, 5});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i39, i1, i20, i28}, new int[]{9, 8, 1, 2, 1});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i39}, new int[]{7, 6});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i6, i19}, new int[]{9, 3, 0});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i22, i17, i6, i4}, new int[]{7, 7, 2, 7, 5});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i28, i12, i34}, new int[]{9, 3, 6, 8});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i34, i0, i17, i2}, new int[]{6, 2, 5, 9, 2});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i39}, new int[]{1});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i13, i8, i36, i6}, new int[]{5, 0, 5, 9, 5});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i16, i31, i25}, new int[]{5, 5, 4, 2});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i5, i32}, new int[]{5, 1, 5});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i21, i27, i26}, new int[]{2, 6, 0, 1});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i31}, new int[]{4});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0, -1},
        };

        System.out.println(center.pohod(premiki, "i40"));
        System.out.println(center.pohod(premiki, "i29"));
        System.out.println(center.pohod(premiki, "i34"));
        System.out.println(center.pohod(premiki, "i24"));
        System.out.println(center.pohod(premiki, "i16"));
        System.out.println(center.pohod(premiki, "i21"));
        System.out.println(center.pohod(premiki, "i28"));
        System.out.println(center.pohod(premiki, "i5"));
        System.out.println(center.pohod(premiki, "i8"));
        System.out.println(center.pohod(premiki, "i17"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
