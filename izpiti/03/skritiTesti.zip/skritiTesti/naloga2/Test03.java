
import java.util.Arrays;

public class Test03 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 84),
            new Druga.Izdelek("i1", 69),
            new Druga.Izdelek("i2", 42),
            new Druga.Izdelek("i3", 34),
            new Druga.Izdelek("i4", 39),
            new Druga.Izdelek("i5", 9),
            new Druga.Izdelek("i6", 50),
            new Druga.Izdelek("i7", 63),
            new Druga.Izdelek("i8", 3),
            new Druga.Izdelek("i9", 11),
            new Druga.Izdelek("i10", 97),
            new Druga.Izdelek("i11", 54),
            new Druga.Izdelek("i12", 80),
            new Druga.Izdelek("i13", 14),
            new Druga.Izdelek("i14", 85),
            new Druga.Izdelek("i15", 10),
            new Druga.Izdelek("i16", 53),
            new Druga.Izdelek("i17", 56),
            new Druga.Izdelek("i18", 31),
            new Druga.Izdelek("i19", 93),
            new Druga.Izdelek("i20", 89),
            new Druga.Izdelek("i21", 64),
            new Druga.Izdelek("i22", 86),
            new Druga.Izdelek("i23", 77),
            new Druga.Izdelek("i24", 40),
            new Druga.Izdelek("i25", 74),
            new Druga.Izdelek("i26", 96),
            new Druga.Izdelek("i27", 93),
            new Druga.Izdelek("i28", 51),
        };
        int[] zaloga = {7, 3, 6, 1, 4, 8, 6, 6, 8, 8, 2, 8, 10, 10, 7, 0, 10, 6, 1, 10, 7, 2, 4, 0, 1, 10, 6, 4, 1};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i0"));
        System.out.println(trgovina.poisciIzdelek("i10"));
        System.out.println(trgovina.poisciIzdelek("i9"));
        System.out.println(trgovina.poisciIzdelek("i6"));
        System.out.println(trgovina.poisciIzdelek("i22"));
    }
}
