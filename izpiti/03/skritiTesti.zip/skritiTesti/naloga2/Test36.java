
import java.util.Arrays;

public class Test36 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 93);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 18);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 90);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 34);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 35);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 85);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 18);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 46);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 72);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 8);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 21);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 86);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 76);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 46);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 27);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 39);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 100);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 88);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 31);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 17);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 79);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 31);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 1);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 23);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 58);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 33);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 40);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 0);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 71);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 43);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 49);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 80);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 98);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 55);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 27);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 19);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 29);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 42);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 65);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 89);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 63);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 22);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[3][10];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i5}, new int[]{8, 8});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i15, i9, i31, i30}, new int[]{5, 7, 5, 3, 0});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i34, i18, i37, i21}, new int[]{7, 1, 8, 9, 6});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i17, i27, i23}, new int[]{4, 5, 7, 0});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i6, i36, i31, i28}, new int[]{9, 4, 2, 5, 8});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i34, i22}, new int[]{1, 5, 1});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i30, i37, i13, i2}, new int[]{7, 8, 7, 2, 5});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i11, i13}, new int[]{2, 1, 9});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i37, i1, i39}, new int[]{3, 8, 8, 4});
        trgovine[0][9] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i33, i5}, new int[]{6, 9, 0});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{2});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i15, i25}, new int[]{2, 7, 6});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i3, i22, i14, i19}, new int[]{9, 1, 8, 5, 4});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i9, i4, i33}, new int[]{0, 5, 5, 0});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i2}, new int[]{0});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i34, i5, i1}, new int[]{5, 6, 7, 7});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{7});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i27, i32, i31}, new int[]{8, 1, 5, 0});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][9] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i16, i26, i23, i15}, new int[]{4, 6, 3, 6, 9});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i6, i19}, new int[]{6, 9, 7});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i27, i13}, new int[]{9, 5, 6});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i39, i32, i29, i38}, new int[]{3, 0, 6, 9, 5});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i0}, new int[]{1, 7});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i38, i8, i2}, new int[]{5, 5, 6, 3});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i40, i17, i19}, new int[]{2, 0, 2, 6});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i38, i16}, new int[]{7, 8, 3});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i39}, new int[]{6});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i8}, new int[]{7, 1});
        trgovine[2][9] = new Druga.Trgovina(new Druga.Izdelek[]{i1}, new int[]{7});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 1, "i20"));
        System.out.println(center.vSosescini(1, 2, "i27"));
        System.out.println(center.vSosescini(1, 8, "i15"));
        System.out.println(center.vSosescini(1, 6, "i5"));
        System.out.println(center.vSosescini(1, 7, "i30"));
        System.out.println(center.vSosescini(1, 5, "i0"));
        System.out.println(center.vSosescini(1, 2, "i21"));
        System.out.println(center.vSosescini(1, 5, "i13"));
        System.out.println(center.vSosescini(1, 2, "i13"));
        System.out.println(center.vSosescini(1, 2, "i22"));
        System.out.println(center.vSosescini(1, 5, "i20"));
        System.out.println(center.vSosescini(1, 5, "i29"));
        System.out.println(center.vSosescini(1, 5, "i33"));
        System.out.println(center.vSosescini(1, 3, "i5"));
        System.out.println(center.vSosescini(1, 7, "i22"));
        System.out.println(center.vSosescini(1, 6, "i12"));
        System.out.println(center.vSosescini(1, 3, "i0"));
        System.out.println(center.vSosescini(1, 3, "i19"));
        System.out.println(center.vSosescini(1, 7, "i22"));
        System.out.println(center.vSosescini(1, 8, "i37"));
    }
}
