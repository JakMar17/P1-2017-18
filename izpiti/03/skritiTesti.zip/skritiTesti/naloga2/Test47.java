
import java.util.Arrays;

public class Test47 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 70);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 98);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 90);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 20);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 50);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 49);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 66);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 60);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 57);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 85);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 1);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 67);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 15);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 35);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 66);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 44);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 36);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 42);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 95);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 47);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 50);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 60);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 0);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 21);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 4);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 54);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 75);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 92);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 2);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 66);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 97);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 68);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 69);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 91);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 57);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 25);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 94);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 16);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 26);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 52);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 67);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 51);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][6];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i23}, new int[]{8});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i22}, new int[]{4});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i2}, new int[]{1});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i31, i39, i12, i20}, new int[]{6, 0, 4, 5, 2});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i31}, new int[]{8});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i22, i3, i25}, new int[]{5, 5, 5, 2});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i16, i37}, new int[]{1, 6, 4});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i31, i41}, new int[]{4, 0, 1});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{5});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i30, i23, i15}, new int[]{3, 5, 0, 1});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i37}, new int[]{3, 7});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i5, i14, i18, i37}, new int[]{6, 2, 7, 7, 1});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i20, i15}, new int[]{3, 3, 7});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i0, i23, i10}, new int[]{2, 8, 3, 9});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i16, i15, i30, i7}, new int[]{9, 2, 9, 6, 3});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i20}, new int[]{4});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i29, i38, i15, i3}, new int[]{7, 2, 4, 1, 7});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i19}, new int[]{8});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i22, i6, i32}, new int[]{6, 2, 9, 0});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i13}, new int[]{9, 8});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i4, i33, i15}, new int[]{8, 3, 2, 9});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i35, i4, i25}, new int[]{2, 4, 0, 1});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i10}, new int[]{1, 3});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i16, i9}, new int[]{4, 0, 0});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i35}, new int[]{5});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i7, i4, i22, i20}, new int[]{8, 5, 5, 1, 0});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i18}, new int[]{0, 3});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{6});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i26, i40, i21}, new int[]{3, 6, 5, 9});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i13}, new int[]{3});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i7, i34, i13, i1}, new int[]{1, 2, 3, 5, 7});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i9}, new int[]{0, 1});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i33}, new int[]{9, 3});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i1, i27, i15}, new int[]{5, 9, 9, 0});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i23}, new int[]{7, 5});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i15, i19, i28, i41}, new int[]{3, 5, 8, 8, 6});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i7}, new int[]{2, 0});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i7}, new int[]{4, 3});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
        };

        System.out.println(center.pohod(premiki, "i9"));
        System.out.println(center.pohod(premiki, "i3"));
        System.out.println(center.pohod(premiki, "i23"));
        System.out.println(center.pohod(premiki, "i6"));
        System.out.println(center.pohod(premiki, "i12"));
        System.out.println(center.pohod(premiki, "i0"));
        System.out.println(center.pohod(premiki, "i17"));
        System.out.println(center.pohod(premiki, "i36"));
        System.out.println(center.pohod(premiki, "i10"));
        System.out.println(center.pohod(premiki, "i31"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
