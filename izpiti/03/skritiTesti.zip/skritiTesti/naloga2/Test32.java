
import java.util.Arrays;

public class Test32 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 93);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 4);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 59);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 33);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 8);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 9);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 94);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 95);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 36);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 8);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 24);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 79);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 19);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 95);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 17);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 97);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 18);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 12);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 12);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 20);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 54);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 76);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 67);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 13);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 49);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 35);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 80);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 20);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 100);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 87);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 51);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 76);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 47);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 84);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 73);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 15);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 95);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 24);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 27);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 19);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 94);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 29);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[4][8];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i24, i22}, new int[]{0, 0, 3});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i1, i39, i37, i24}, new int[]{7, 6, 8, 4, 0});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i41}, new int[]{4});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i25}, new int[]{6});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i37, i3, i10, i41}, new int[]{2, 4, 4, 2, 7});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i39, i18}, new int[]{6, 3, 9});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i17, i16}, new int[]{1, 5, 0});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i36}, new int[]{1});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i40}, new int[]{8, 1});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i30}, new int[]{3, 1});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i5, i32, i7}, new int[]{4, 4, 6, 9});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i30, i32, i14, i2}, new int[]{3, 8, 0, 0, 6});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i31}, new int[]{4, 9});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i4, i6, i25, i21}, new int[]{3, 6, 4, 1, 0});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i7, i21, i1, i19}, new int[]{0, 2, 0, 2, 1});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i9}, new int[]{4, 7});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i20, i2, i14, i29}, new int[]{8, 7, 3, 7, 1});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i6}, new int[]{6, 8});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i4, i15, i38}, new int[]{1, 8, 6, 3});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i41, i20}, new int[]{7, 3, 3});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i22}, new int[]{0});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i3}, new int[]{7, 0});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i17, i18, i29, i31}, new int[]{8, 1, 3, 8, 2});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i21}, new int[]{8, 9});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i8, i14}, new int[]{7, 2, 8});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i8}, new int[]{2, 8});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i21, i15}, new int[]{7, 8, 3});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(1, 2, "i4"));
        System.out.println(center.vSosescini(2, 2, "i17"));
        System.out.println(center.vSosescini(2, 2, "i24"));
        System.out.println(center.vSosescini(1, 3, "i19"));
        System.out.println(center.vSosescini(1, 5, "i11"));
        System.out.println(center.vSosescini(1, 4, "i39"));
        System.out.println(center.vSosescini(2, 5, "i33"));
        System.out.println(center.vSosescini(1, 5, "i3"));
        System.out.println(center.vSosescini(1, 4, "i5"));
        System.out.println(center.vSosescini(1, 5, "i17"));
        System.out.println(center.vSosescini(2, 6, "i20"));
        System.out.println(center.vSosescini(1, 3, "i6"));
        System.out.println(center.vSosescini(2, 6, "i20"));
        System.out.println(center.vSosescini(1, 4, "i31"));
        System.out.println(center.vSosescini(2, 2, "i18"));
        System.out.println(center.vSosescini(1, 6, "i32"));
        System.out.println(center.vSosescini(1, 2, "i10"));
        System.out.println(center.vSosescini(2, 6, "i41"));
        System.out.println(center.vSosescini(1, 5, "i31"));
        System.out.println(center.vSosescini(1, 3, "i14"));
    }
}
