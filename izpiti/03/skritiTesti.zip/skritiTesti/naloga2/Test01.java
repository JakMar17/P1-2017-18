
import java.util.Arrays;

public class Test01 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 16),
            new Druga.Izdelek("i1", 33),
            new Druga.Izdelek("i2", 12),
            new Druga.Izdelek("i3", 99),
            new Druga.Izdelek("i4", 83),
            new Druga.Izdelek("i5", 21),
            new Druga.Izdelek("i6", 49),
            new Druga.Izdelek("i7", 5),
            new Druga.Izdelek("i8", 38),
            new Druga.Izdelek("i9", 33),
            new Druga.Izdelek("i10", 44),
            new Druga.Izdelek("i11", 23),
            new Druga.Izdelek("i12", 62),
            new Druga.Izdelek("i13", 64),
            new Druga.Izdelek("i14", 26),
            new Druga.Izdelek("i15", 45),
            new Druga.Izdelek("i16", 37),
        };
        int[] zaloga = {8, 10, 10, 3, 1, 3, 8, 10, 4, 0, 0, 7, 6, 7, 3, 8, 1};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i29"));
        System.out.println(trgovina.poisciIzdelek("i31"));
        System.out.println(trgovina.poisciIzdelek("i22"));
        System.out.println(trgovina.poisciIzdelek("i18"));
        System.out.println(trgovina.poisciIzdelek("i6"));
        System.out.println(trgovina.poisciIzdelek("i11"));
        System.out.println(trgovina.poisciIzdelek("i16"));
    }
}
