
import java.util.Arrays;

public class Test17 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 62),
            new Druga.Izdelek("i1", 47),
            new Druga.Izdelek("i2", 9),
            new Druga.Izdelek("i3", 100),
            new Druga.Izdelek("i4", 74),
            new Druga.Izdelek("i5", 42),
            new Druga.Izdelek("i6", 69),
            new Druga.Izdelek("i7", 8),
            new Druga.Izdelek("i8", 3),
            new Druga.Izdelek("i9", 91),
            new Druga.Izdelek("i10", 25),
            new Druga.Izdelek("i11", 15),
            new Druga.Izdelek("i12", 54),
        };
        int[] zaloga = {7, 4, 10, 10, 3, 10, 1, 1, 9, 5, 3, 5, 2};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(4, 2));
        System.out.println(trgovina.prodaj(4, 1));
        System.out.println(trgovina.prodaj(11, 5));
        System.out.println(trgovina.prodaj(10, 2));
        System.out.println(trgovina.prodaj(5, 7));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
