
import java.util.Arrays;

public class Test42 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 3);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 24);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 73);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 63);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 55);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 71);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 33);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 65);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 8);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 23);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 81);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 97);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 41);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 74);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 27);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 97);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 86);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 83);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 46);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 10);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 35);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 3);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 26);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 18);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 48);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 18);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 78);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 2);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 49);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 38);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 90);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 97);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 37);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 44);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 19);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 70);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 9);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 36);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 71);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 40);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 26);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 70);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[5][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i3, i38, i30}, new int[]{1, 3, 5, 9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i24, i15, i38, i7}, new int[]{1, 6, 3, 1, 3});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i27, i22}, new int[]{4, 9, 5});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i29}, new int[]{5});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i31, i14, i36}, new int[]{7, 8, 1, 0});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i0}, new int[]{9, 2});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i20, i7, i40, i41}, new int[]{4, 2, 8, 4, 6});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i18}, new int[]{2});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i18}, new int[]{1});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i20}, new int[]{2});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i7, i18, i1}, new int[]{8, 7, 2, 9});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i36}, new int[]{5, 4});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i18, i37}, new int[]{5, 0, 9});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i15}, new int[]{4, 3});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i28}, new int[]{2});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{5});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i24}, new int[]{6});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i39, i13}, new int[]{9, 1, 8});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i33, i30, i15, i16}, new int[]{7, 9, 5, 9, 2});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i39}, new int[]{5});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i25, i12}, new int[]{6, 4, 1});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i1}, new int[]{9, 4});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i7}, new int[]{3, 2});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i33, i38, i35}, new int[]{9, 0, 6, 0});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i26, i2, i28, i17}, new int[]{6, 4, 0, 3, 8});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i34}, new int[]{5});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i31, i2}, new int[]{7, 1, 8});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{1});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            {-1,  0},
            { 0,  1},
        };

        System.out.println(center.pohod(premiki, "i18"));
        System.out.println(center.pohod(premiki, "i19"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i3"));
        System.out.println(center.pohod(premiki, "i33"));
        System.out.println(center.pohod(premiki, "i37"));
        System.out.println(center.pohod(premiki, "i5"));
        System.out.println(center.pohod(premiki, "i32"));
        System.out.println(center.pohod(premiki, "i7"));
        System.out.println(center.pohod(premiki, "i1"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
