
import java.util.Arrays;

public class Test19 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 55),
            new Druga.Izdelek("i1", 46),
            new Druga.Izdelek("i2", 46),
            new Druga.Izdelek("i3", 64),
            new Druga.Izdelek("i4", 55),
            new Druga.Izdelek("i5", 98),
            new Druga.Izdelek("i6", 79),
            new Druga.Izdelek("i7", 2),
            new Druga.Izdelek("i8", 65),
        };
        int[] zaloga = {6, 7, 6, 9, 4, 1, 10, 4, 6};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(6, 9));
        System.out.println(trgovina.prodaj(1, 2));
        System.out.println(trgovina.prodaj(8, 2));
        System.out.println(trgovina.prodaj(6, 1));
        System.out.println(trgovina.prodaj(4, 2));
        System.out.println(trgovina.prodaj(4, 2));
        System.out.println(trgovina.prodaj(7, 4));
        System.out.println(trgovina.prodaj(0, 5));
        System.out.println(trgovina.prodaj(2, 3));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
