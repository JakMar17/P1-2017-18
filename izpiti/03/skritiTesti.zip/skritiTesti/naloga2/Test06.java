
import java.util.Arrays;

public class Test06 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 16),
            new Druga.Izdelek("i1", 1),
            new Druga.Izdelek("i2", 78),
            new Druga.Izdelek("i3", 26),
            new Druga.Izdelek("i4", 4),
            new Druga.Izdelek("i5", 90),
        };
        int[] zaloga = {7, 7, 0, 5, 3, 2};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i7"));
        System.out.println(trgovina.poisciIzdelek("i5"));
        System.out.println(trgovina.poisciIzdelek("i0"));
        System.out.println(trgovina.poisciIzdelek("i6"));
        System.out.println(trgovina.poisciIzdelek("i2"));
    }
}
