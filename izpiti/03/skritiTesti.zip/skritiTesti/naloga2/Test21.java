
import java.util.Arrays;

public class Test21 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 95),
            new Druga.Izdelek("i1", 86),
            new Druga.Izdelek("i2", 37),
            new Druga.Izdelek("i3", 6),
            new Druga.Izdelek("i4", 35),
            new Druga.Izdelek("i5", 29),
            new Druga.Izdelek("i6", 40),
            new Druga.Izdelek("i7", 26),
            new Druga.Izdelek("i8", 69),
            new Druga.Izdelek("i9", 7),
            new Druga.Izdelek("i10", 60),
            new Druga.Izdelek("i11", 84),
            new Druga.Izdelek("i12", 85),
        };
        int[] zaloga = {3, 5, 5, 0, 3, 10, 2, 5, 5, 0, 8, 0, 10};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(10, 8));
        System.out.println(trgovina.prodaj(3, 5));
        System.out.println(trgovina.prodaj(0, 6));
        System.out.println(trgovina.prodaj(1, 6));
        System.out.println(trgovina.prodaj(10, 2));
        System.out.println(trgovina.prodaj(7, 9));
        System.out.println(trgovina.prodaj(12, 4));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
