
import java.util.Arrays;

public class Test09 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 50),
            new Druga.Izdelek("i1", 18),
            new Druga.Izdelek("i2", 12),
            new Druga.Izdelek("i3", 36),
            new Druga.Izdelek("i4", 61),
            new Druga.Izdelek("i5", 92),
            new Druga.Izdelek("i6", 30),
            new Druga.Izdelek("i7", 27),
            new Druga.Izdelek("i8", 100),
            new Druga.Izdelek("i9", 13),
            new Druga.Izdelek("i10", 29),
            new Druga.Izdelek("i11", 24),
            new Druga.Izdelek("i12", 97),
            new Druga.Izdelek("i13", 6),
            new Druga.Izdelek("i14", 77),
            new Druga.Izdelek("i15", 27),
            new Druga.Izdelek("i16", 54),
            new Druga.Izdelek("i17", 71),
            new Druga.Izdelek("i18", 53),
            new Druga.Izdelek("i19", 28),
            new Druga.Izdelek("i20", 70),
            new Druga.Izdelek("i21", 15),
            new Druga.Izdelek("i22", 19),
            new Druga.Izdelek("i23", 35),
            new Druga.Izdelek("i24", 91),
            new Druga.Izdelek("i25", 57),
        };
        int[] zaloga = {2, 7, 6, 7, 5, 6, 4, 9, 3, 2, 5, 7, 4, 3, 2, 9, 3, 9, 10, 3, 7, 10, 10, 10, 1, 9};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i17"));
        System.out.println(trgovina.poisciIzdelek("i20"));
        System.out.println(trgovina.poisciIzdelek("i19"));
        System.out.println(trgovina.poisciIzdelek("i24"));
    }
}
