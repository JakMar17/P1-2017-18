
import java.util.Arrays;

public class Test44 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 70);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 84);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 3);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 73);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 15);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 23);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 56);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 79);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 80);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 93);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 20);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 99);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 22);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 87);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 99);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 41);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 2);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 42);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 43);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 50);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 0);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 9);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 39);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 17);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 72);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 82);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 82);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 75);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 3);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 85);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 38);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 91);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 37);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 35);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 16);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 60);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 28);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 7);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 87);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 66);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 81);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 18);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[3][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i38, i19, i40}, new int[]{0, 6, 0, 9});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i41}, new int[]{0, 7});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i11, i28, i18, i13}, new int[]{3, 9, 8, 2, 3});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i13}, new int[]{8});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i22, i21, i31, i29}, new int[]{2, 4, 0, 0, 1});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i5}, new int[]{0});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i32, i6, i9, i12}, new int[]{2, 0, 4, 4, 1});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i15, i16, i29}, new int[]{6, 7, 9, 6});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i32, i18, i16}, new int[]{8, 8, 1, 3});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i17}, new int[]{6, 7});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i38}, new int[]{0, 0});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i7}, new int[]{0, 7});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i25, i39, i6, i0}, new int[]{7, 1, 3, 4, 3});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i40, i11}, new int[]{4, 1, 6});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i23, i16, i30, i28}, new int[]{9, 1, 9, 0, 8});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i41, i4, i35}, new int[]{3, 1, 6, 8});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i35, i5, i15}, new int[]{7, 2, 5, 6});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i32, i36, i5, i15}, new int[]{6, 0, 2, 0, 4});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i30}, new int[]{6});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i24, i21, i37, i11}, new int[]{1, 1, 4, 0, 1});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 0,  1},
        };

        System.out.println(center.pohod(premiki, "i18"));
        System.out.println(center.pohod(premiki, "i2"));
        System.out.println(center.pohod(premiki, "i22"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i40"));
        System.out.println(center.pohod(premiki, "i21"));
        System.out.println(center.pohod(premiki, "i15"));
        System.out.println(center.pohod(premiki, "i5"));
        System.out.println(center.pohod(premiki, "i33"));
        System.out.println(center.pohod(premiki, "i30"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
