
import java.util.Arrays;

public class Test26 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 57);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 14);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 25);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 15);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 39);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 97);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 73);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 70);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 38);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 82);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 42);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 45);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 91);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 76);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 6);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 63);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 31);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 53);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 56);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 65);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 38);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 57);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 32);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 4);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 80);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 76);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 34);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 54);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 55);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 69);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 58);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 20);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 31);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 11);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 51);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 47);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 16);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 85);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 81);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 15);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 91);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 28);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[7][5];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i17, i1, i28, i37}, new int[]{8, 4, 6, 2, 5});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i29, i10, i16, i37}, new int[]{9, 7, 4, 7, 9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i19}, new int[]{2, 1});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i15, i4, i21, i5}, new int[]{8, 4, 4, 5, 7});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i20, i18, i39, i37}, new int[]{3, 6, 9, 6, 6});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i27, i30, i11, i24}, new int[]{2, 7, 3, 6, 9});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i28}, new int[]{8, 2});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i3, i6}, new int[]{0, 3, 2});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i30, i1, i34, i20}, new int[]{3, 7, 5, 8, 8});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i5, i14, i34, i18}, new int[]{1, 9, 8, 0, 0});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i11, i21, i27, i6}, new int[]{4, 3, 9, 0, 1});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i3}, new int[]{9});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i12}, new int[]{4, 4});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i19}, new int[]{4, 6});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i7}, new int[]{4, 9});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i36}, new int[]{6, 3});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i12}, new int[]{8});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i20}, new int[]{6});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i4, i1, i27, i15}, new int[]{8, 5, 0, 0, 3});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i1, i26, i3}, new int[]{7, 3, 9, 4});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i29, i6}, new int[]{4, 0, 3});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i9}, new int[]{4});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i22}, new int[]{7, 2});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i24, i21}, new int[]{0, 7, 1});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i13, i39, i25, i2}, new int[]{7, 3, 4, 3, 2});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i21, i27}, new int[]{6, 9, 9});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i21, i17, i10}, new int[]{5, 2, 1, 4});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i13, i29, i8}, new int[]{1, 3, 6, 9});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i18, i14}, new int[]{1, 7, 1});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i28}, new int[]{0, 5});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(3, 3, "i11"));
        System.out.println(center.vSosescini(2, 3, "i38"));
        System.out.println(center.vSosescini(3, 3, "i35"));
        System.out.println(center.vSosescini(5, 1, "i30"));
        System.out.println(center.vSosescini(3, 3, "i25"));
        System.out.println(center.vSosescini(1, 3, "i22"));
        System.out.println(center.vSosescini(1, 3, "i17"));
        System.out.println(center.vSosescini(2, 2, "i2"));
        System.out.println(center.vSosescini(5, 3, "i19"));
        System.out.println(center.vSosescini(2, 3, "i22"));
        System.out.println(center.vSosescini(3, 3, "i8"));
        System.out.println(center.vSosescini(5, 1, "i2"));
        System.out.println(center.vSosescini(1, 2, "i32"));
        System.out.println(center.vSosescini(2, 1, "i8"));
        System.out.println(center.vSosescini(2, 3, "i13"));
        System.out.println(center.vSosescini(2, 2, "i26"));
        System.out.println(center.vSosescini(2, 3, "i22"));
        System.out.println(center.vSosescini(1, 1, "i31"));
        System.out.println(center.vSosescini(5, 1, "i38"));
        System.out.println(center.vSosescini(5, 2, "i11"));
    }
}
