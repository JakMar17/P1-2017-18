
import java.util.Arrays;

public class Test08 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 48),
            new Druga.Izdelek("i1", 77),
            new Druga.Izdelek("i2", 76),
            new Druga.Izdelek("i3", 74),
            new Druga.Izdelek("i4", 6),
            new Druga.Izdelek("i5", 96),
            new Druga.Izdelek("i6", 39),
            new Druga.Izdelek("i7", 55),
            new Druga.Izdelek("i8", 70),
            new Druga.Izdelek("i9", 52),
            new Druga.Izdelek("i10", 25),
            new Druga.Izdelek("i11", 44),
        };
        int[] zaloga = {8, 5, 9, 6, 0, 10, 7, 7, 8, 3, 7, 3};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i22"));
        System.out.println(trgovina.poisciIzdelek("i6"));
    }
}
