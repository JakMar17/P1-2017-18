
import java.util.Arrays;

public class Test43 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 14);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 36);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 27);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 52);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 46);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 76);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 56);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 49);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 99);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 9);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 3);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 23);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 66);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 81);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 32);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 54);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 26);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 24);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 11);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 16);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 26);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 52);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 97);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 42);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 32);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 23);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 4);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 96);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 7);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 51);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 4);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 97);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 61);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 13);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 79);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 72);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 37);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 10);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 35);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 9);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 50);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 9);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[6][5];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i40, i16, i36, i28}, new int[]{8, 8, 7, 0, 8});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i24, i29, i8, i36}, new int[]{4, 3, 1, 0, 0});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i19, i17}, new int[]{5, 4, 7});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i9}, new int[]{0, 3});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i39}, new int[]{9, 8});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i12, i25, i19}, new int[]{3, 9, 7, 1});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i5}, new int[]{3, 8});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i19, i11, i22, i32}, new int[]{4, 0, 1, 1, 5});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i15, i21, i25, i27, i37}, new int[]{5, 4, 1, 3, 5});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i16}, new int[]{2, 3});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i0, i38, i9, i8}, new int[]{0, 4, 5, 5, 0});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i15}, new int[]{5, 3});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i40, i26, i7, i5}, new int[]{9, 6, 4, 1, 1});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i8, i3, i5}, new int[]{1, 4, 3, 3});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i10}, new int[]{4, 0});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i40}, new int[]{7, 6});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i18, i25}, new int[]{0, 1, 4});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i1, i26, i6, i23}, new int[]{7, 7, 0, 5, 9});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i30}, new int[]{7});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i6, i36, i38, i20}, new int[]{2, 1, 8, 7, 6});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i41, i3, i25}, new int[]{7, 1, 2, 7});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i5, i31}, new int[]{2, 5, 6});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i34, i6, i28, i33}, new int[]{5, 8, 7, 8, 0});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i21, i20, i5, i38}, new int[]{9, 8, 5, 7, 1});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i20, i17, i19}, new int[]{5, 4, 9, 0});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i6}, new int[]{8});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            {-1,  0},
            {-1,  0},
        };

        System.out.println(center.pohod(premiki, "i26"));
        System.out.println(center.pohod(premiki, "i11"));
        System.out.println(center.pohod(premiki, "i14"));
        System.out.println(center.pohod(premiki, "i15"));
        System.out.println(center.pohod(premiki, "i12"));
        System.out.println(center.pohod(premiki, "i22"));
        System.out.println(center.pohod(premiki, "i0"));
        System.out.println(center.pohod(premiki, "i38"));
        System.out.println(center.pohod(premiki, "i4"));
        System.out.println(center.pohod(premiki, "i32"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
