
import java.util.Arrays;

public class Test48 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 59);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 95);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 65);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 9);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 60);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 1);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 44);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 59);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 54);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 37);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 40);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 49);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 20);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 83);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 74);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 16);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 7);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 73);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 58);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 43);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 96);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 85);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 91);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 26);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 37);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 97);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 91);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 32);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 51);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 99);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 51);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 45);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 25);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 35);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 80);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 38);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 57);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 78);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 27);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 29);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 89);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 94);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[4][8];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i33}, new int[]{5});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i31, i22, i13, i4}, new int[]{8, 2, 6, 8, 9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i30, i28, i2}, new int[]{4, 9, 0, 2});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i7, i6, i38}, new int[]{3, 1, 3, 5});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i37}, new int[]{1, 1});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i37, i25, i35, i22}, new int[]{4, 0, 3, 9, 1});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i35, i15, i34}, new int[]{0, 5, 7, 2});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i24, i39, i9}, new int[]{7, 2, 8, 8});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i28, i35, i11, i8}, new int[]{1, 2, 8, 9, 6});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i16}, new int[]{1, 2});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i11}, new int[]{5, 8});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i22, i33}, new int[]{8, 9, 9});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i27, i18, i15}, new int[]{8, 3, 4, 4});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i35}, new int[]{2});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i27, i15, i2}, new int[]{6, 8, 0, 1});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i27, i12}, new int[]{3, 2, 6});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i35, i27, i11}, new int[]{4, 7, 3, 7});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i19, i23}, new int[]{6, 2, 6});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i20, i10, i35, i37}, new int[]{6, 2, 8, 2, 5});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i23, i37, i38}, new int[]{7, 9, 6, 8});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i19}, new int[]{4, 6});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i15}, new int[]{8});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i16, i1, i9}, new int[]{8, 2, 9, 4});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i24, i41, i15, i9}, new int[]{8, 5, 6, 0, 4});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i28, i25}, new int[]{3, 2, 1});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i31, i37, i33, i29, i38}, new int[]{4, 6, 4, 3, 7});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i23}, new int[]{0});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i41, i17}, new int[]{3, 7, 6});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i37, i8}, new int[]{6, 5, 0});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i38}, new int[]{2});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            { 0, -1},
        };

        System.out.println(center.pohod(premiki, "i13"));
        System.out.println(center.pohod(premiki, "i8"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i38"));
        System.out.println(center.pohod(premiki, "i22"));
        System.out.println(center.pohod(premiki, "i15"));
        System.out.println(center.pohod(premiki, "i6"));
        System.out.println(center.pohod(premiki, "i4"));
        System.out.println(center.pohod(premiki, "i21"));
        System.out.println(center.pohod(premiki, "i32"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
