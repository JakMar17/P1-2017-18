
import java.util.Arrays;

public class Test25 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 44),
            new Druga.Izdelek("i1", 99),
            new Druga.Izdelek("i2", 46),
            new Druga.Izdelek("i3", 18),
            new Druga.Izdelek("i4", 13),
            new Druga.Izdelek("i5", 47),
            new Druga.Izdelek("i6", 74),
            new Druga.Izdelek("i7", 88),
            new Druga.Izdelek("i8", 39),
            new Druga.Izdelek("i9", 93),
            new Druga.Izdelek("i10", 67),
            new Druga.Izdelek("i11", 75),
            new Druga.Izdelek("i12", 2),
            new Druga.Izdelek("i13", 73),
            new Druga.Izdelek("i14", 43),
            new Druga.Izdelek("i15", 45),
            new Druga.Izdelek("i16", 60),
            new Druga.Izdelek("i17", 60),
            new Druga.Izdelek("i18", 100),
            new Druga.Izdelek("i19", 89),
            new Druga.Izdelek("i20", 32),
            new Druga.Izdelek("i21", 56),
            new Druga.Izdelek("i22", 68),
            new Druga.Izdelek("i23", 93),
        };
        int[] zaloga = {7, 3, 5, 1, 2, 7, 7, 2, 5, 9, 2, 7, 10, 8, 2, 1, 3, 9, 10, 2, 6, 7, 3, 1};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(0, 7));
        System.out.println(trgovina.prodaj(9, 7));
        System.out.println(trgovina.prodaj(6, 4));
        System.out.println(trgovina.prodaj(3, 3));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
