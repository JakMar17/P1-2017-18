// _NE_ODSTRANI_

import java.awt.Color;

public class Test32 {

    public static void main(String[] args) {

        int dolzina = 8;
        Tretja.Polje[] polja = {
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Polje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat32.png", "528x528"});
    }
}
