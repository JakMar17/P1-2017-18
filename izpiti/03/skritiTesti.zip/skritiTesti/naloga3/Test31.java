// _NE_ODSTRANI_

import java.awt.Color;

public class Test31 {

    public static void main(String[] args) {

        int dolzina = 8;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat31.png", "432x432"});
    }
}
