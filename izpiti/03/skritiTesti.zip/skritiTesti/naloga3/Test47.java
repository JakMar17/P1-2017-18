// _NE_ODSTRANI_

import java.awt.Color;

public class Test47 {

    public static void main(String[] args) {

        int dolzina = 4;
        Tretja.Polje[] polja = {
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Posest(Color.MAGENTA),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat47.png", "648x608"});
    }
}
