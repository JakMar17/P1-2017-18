
import java.awt.Color;

public class Test07 {

    public static void main(String[] args) {

        int dolzina = 5;
        Tretja.Polje[] polja = {
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);

        System.out.println(Platno.ri(tretja.stranicaPolja(610, 660)));
        System.out.println(Platno.ri(tretja.xLevo(610, 660)));
        System.out.println(Platno.ri(tretja.yZgoraj(610, 660)));
    }
}
