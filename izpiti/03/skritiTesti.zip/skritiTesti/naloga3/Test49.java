// _NE_ODSTRANI_

import java.awt.Color;

public class Test49 {

    public static void main(String[] args) {

        int dolzina = 4;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.BLUE),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat49.png", "776x872"});
    }
}
