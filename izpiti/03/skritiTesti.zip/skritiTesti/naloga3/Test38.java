// _NE_ODSTRANI_

import java.awt.Color;

public class Test38 {

    public static void main(String[] args) {

        int dolzina = 9;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.RED),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Posest(Color.RED),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Presenecenje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat38.png", "522x414"});
    }
}
