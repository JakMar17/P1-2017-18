
import java.awt.Color;

public class Test06 {

    public static void main(String[] args) {

        int dolzina = 9;
        Tretja.Polje[] polja = {
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);

        System.out.println(Platno.ri(tretja.stranicaPolja(648, 630)));
        System.out.println(Platno.ri(tretja.xLevo(648, 630)));
        System.out.println(Platno.ri(tretja.yZgoraj(648, 630)));
    }
}
