// _NE_ODSTRANI_

import java.awt.Color;

public class Test24 {

    public static void main(String[] args) {

        int dolzina = 6;
        Tretja.Polje[] polja = {
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat24.png", "600x600"});
    }
}
