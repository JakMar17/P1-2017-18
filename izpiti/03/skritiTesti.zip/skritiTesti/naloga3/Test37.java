// _NE_ODSTRANI_

import java.awt.Color;

public class Test37 {

    public static void main(String[] args) {

        int dolzina = 3;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat37.png", "534x486"});
    }
}
