// _NE_ODSTRANI_

import java.awt.Color;

public class Test36 {

    public static void main(String[] args) {

        int dolzina = 10;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Polje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.BLUE),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat36.png", "540x660"});
    }
}
