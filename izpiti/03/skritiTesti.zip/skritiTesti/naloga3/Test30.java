// _NE_ODSTRANI_

import java.awt.Color;

public class Test30 {

    public static void main(String[] args) {

        int dolzina = 7;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat30.png", "770x826"});
    }
}
