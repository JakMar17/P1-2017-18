// _NE_ODSTRANI_

import java.awt.Color;

public class Test33 {

    public static void main(String[] args) {

        int dolzina = 10;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Posest(Color.RED),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.MAGENTA),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat33.png", "680x680"});
    }
}
