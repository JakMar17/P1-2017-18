// _NE_ODSTRANI_

import java.awt.Color;

public class Test42 {

    public static void main(String[] args) {

        int dolzina = 4;
        Tretja.Polje[] polja = {
            new Tretja.Polje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.GREEN),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat42.png", "816x720"});
    }
}
