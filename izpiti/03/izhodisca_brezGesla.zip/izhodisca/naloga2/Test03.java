
import java.util.Arrays;

public class Test03 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("mleko",    0),
            new Druga.Izdelek("kruh",    10),
            new Druga.Izdelek("moka",    20),
            new Druga.Izdelek("riz",     30),
            new Druga.Izdelek("breskve", 40),
            new Druga.Izdelek("jogurt",  50),
            new Druga.Izdelek("pivo",    60),
            new Druga.Izdelek("maslo",   70),
            new Druga.Izdelek("sladkor", 80),
            new Druga.Izdelek("salama",  90)
        };
        int[] zaloga = {5, 1, 0, 3, 4, 2, 0, 6, 3, 1};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        prodaj(trgovina, 7, 2);
        prodaj(trgovina, 0, 3);
        prodaj(trgovina, 1, 2);
        prodaj(trgovina, 2, 5);
        prodaj(trgovina, 7, 10);
    }

    private static void prodaj(Druga.Trgovina trgovina, int indeks, int n) {
        String naziv = trgovina.vrniIzdelke()[indeks].vrniNaziv();
        System.out.printf("prodaja: %s (maks. %d enot)%n", naziv, n);

        int prihodek = trgovina.prodaj(indeks, n);
        System.out.println("prihodek: " + prihodek);
        System.out.println("saldo: " + trgovina.vrniSaldo());
        System.out.println("zaloga: " + Arrays.toString(trgovina.vrniZalogo()));
        System.out.println("----------");
    }
}
