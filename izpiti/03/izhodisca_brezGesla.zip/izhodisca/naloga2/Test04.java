
import java.util.Arrays;

public class Test04 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 50),
            new Druga.Izdelek("i1", 87),
            new Druga.Izdelek("i2", 57),
            new Druga.Izdelek("i3", 20),
            new Druga.Izdelek("i4", 39),
            new Druga.Izdelek("i5", 94),
            new Druga.Izdelek("i6", 44),
            new Druga.Izdelek("i7", 27),
            new Druga.Izdelek("i8", 15),
            new Druga.Izdelek("i9", 79),
            new Druga.Izdelek("i10", 38),
        };
        int[] zaloga = {8, 5, 9, 4, 3, 6, 6, 5, 6, 6, 7};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(9, 5));
        System.out.println(trgovina.prodaj(2, 9));
        System.out.println(trgovina.prodaj(8, 6));
        System.out.println(trgovina.prodaj(0, 5));
        System.out.println(trgovina.prodaj(1, 3));
        System.out.println(trgovina.prodaj(6, 2));
        System.out.println(trgovina.prodaj(6, 2));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
