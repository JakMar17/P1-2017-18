
import java.util.Arrays;

public class Test02 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 44),
            new Druga.Izdelek("i1", 52),
            new Druga.Izdelek("i2", 69),
            new Druga.Izdelek("i3", 38),
            new Druga.Izdelek("i4", 66),
            new Druga.Izdelek("i5", 39),
            new Druga.Izdelek("i6", 39),
            new Druga.Izdelek("i7", 65),
            new Druga.Izdelek("i8", 51),
            new Druga.Izdelek("i9", 79),
            new Druga.Izdelek("i10", 40),
            new Druga.Izdelek("i11", 21),
            new Druga.Izdelek("i12", 75),
            new Druga.Izdelek("i13", 54),
            new Druga.Izdelek("i14", 72),
            new Druga.Izdelek("i15", 51),
            new Druga.Izdelek("i16", 16),
            new Druga.Izdelek("i17", 10),
            new Druga.Izdelek("i18", 41),
            new Druga.Izdelek("i19", 55),
            new Druga.Izdelek("i20", 71),
            new Druga.Izdelek("i21", 11),
            new Druga.Izdelek("i22", 44),
            new Druga.Izdelek("i23", 33),
            new Druga.Izdelek("i24", 27),
            new Druga.Izdelek("i25", 93),
            new Druga.Izdelek("i26", 15),
            new Druga.Izdelek("i27", 20),
            new Druga.Izdelek("i28", 35),
        };
        int[] zaloga = {8, 3, 4, 7, 6, 5, 0, 3, 8, 9, 10, 6, 2, 10, 3, 9, 9, 4, 0, 10, 8, 1, 5, 10, 7, 9, 10, 3, 7};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.poisciIzdelek("i50"));
        System.out.println(trgovina.poisciIzdelek("i37"));
        System.out.println(trgovina.poisciIzdelek("i5"));
        System.out.println(trgovina.poisciIzdelek("i20"));
        System.out.println(trgovina.poisciIzdelek("i39"));
        System.out.println(trgovina.poisciIzdelek("i51"));
        System.out.println(trgovina.poisciIzdelek("i26"));
        System.out.println(trgovina.poisciIzdelek("i52"));
        System.out.println(trgovina.poisciIzdelek("i11"));
    }
}
