
import java.util.Arrays;

public class Test09 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 72);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 71);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 73);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 34);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 64);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 46);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 96);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 65);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 72);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 52);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 10);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 54);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 6);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 24);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 57);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 45);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 88);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 22);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 42);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 26);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 97);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 59);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 91);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 36);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 55);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 18);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 4);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 31);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 6);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 83);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 38);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 52);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 66);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 58);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 41);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 47);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 85);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 38);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 21);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 34);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 45);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 18);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][9];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i9, i2, i39, i28}, new int[]{4, 9, 0, 6, 3});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i26, i4, i6}, new int[]{1, 1, 3, 9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i36, i23, i7, i22}, new int[]{5, 3, 1, 4, 0});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i27, i5}, new int[]{4, 7, 5});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i3, i27, i33}, new int[]{8, 9, 3, 5});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i36}, new int[]{4});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i5}, new int[]{4, 3});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i0, i30}, new int[]{8, 4, 6});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i24, i11}, new int[]{6, 2, 2});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i23, i1, i2}, new int[]{6, 3, 7, 1});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i15, i11}, new int[]{8, 3, 4});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i15, i35, i0, i28}, new int[]{7, 3, 7, 3, 8});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i34, i39, i28, i2}, new int[]{4, 4, 3, 5, 7});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{7});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i9}, new int[]{3, 0});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i22, i31, i27, i40}, new int[]{1, 2, 3, 5, 3});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i10, i38, i23}, new int[]{9, 2, 0, 3});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i35}, new int[]{2, 5});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{i29, i35}, new int[]{9, 0});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i14}, new int[]{4});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i23, i15, i27}, new int[]{7, 5, 3, 5});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i37}, new int[]{4});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{i14, i16}, new int[]{0, 7});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i13}, new int[]{8, 3});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i4, i6, i30}, new int[]{1, 8, 9});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i2}, new int[]{3});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i19}, new int[]{3});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i34, i11, i12, i8}, new int[]{3, 0, 4, 5, 6});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i32}, new int[]{0, 6});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i7, i4, i30}, new int[]{4, 0, 4, 9});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i16}, new int[]{1});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i11, i17}, new int[]{8, 8, 9});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i40, i21, i3, i7}, new int[]{7, 3, 4, 2, 4});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i9}, new int[]{6, 5});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i11, i37, i8}, new int[]{5, 5, 5, 8});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i39, i32, i17}, new int[]{8, 4, 4, 5});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i41}, new int[]{0});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i20, i32}, new int[]{2, 7, 9});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i31, i33}, new int[]{0, 6, 2});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i41, i27, i32}, new int[]{3, 0, 8, 3});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i34, i30, i13}, new int[]{2, 3, 3, 6});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i13}, new int[]{9, 6});
        trgovine[5][7] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i17, i7, i32, i15}, new int[]{4, 0, 4, 4, 6});
        trgovine[5][8] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i22}, new int[]{7, 9});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i8}, new int[]{6, 6});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i3, i30, i20}, new int[]{1, 4, 7});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i2, i31}, new int[]{4, 2});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i8}, new int[]{0, 8});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i5, i36}, new int[]{8, 9, 4});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i15, i36}, new int[]{3, 6, 5});
        trgovine[6][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][8] = new Druga.Trgovina(new Druga.Izdelek[]{i7}, new int[]{6});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i17, i33}, new int[]{2, 5, 8});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i10}, new int[]{7});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i8, i39}, new int[]{8, 6, 5});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i29}, new int[]{8, 6});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i10}, new int[]{4});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i4}, new int[]{4});
        trgovine[7][7] = new Druga.Trgovina(new Druga.Izdelek[]{i33, i14, i21}, new int[]{7, 9, 1});
        trgovine[7][8] = new Druga.Trgovina(new Druga.Izdelek[]{i1}, new int[]{6});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
        };

        System.out.println(center.pohod(premiki, "i22"));
        System.out.println(center.pohod(premiki, "i33"));
        System.out.println(center.pohod(premiki, "i27"));
        System.out.println(center.pohod(premiki, "i10"));
        System.out.println(center.pohod(premiki, "i14"));
        System.out.println(center.pohod(premiki, "i19"));
        System.out.println(center.pohod(premiki, "i35"));
        System.out.println(center.pohod(premiki, "i39"));
        System.out.println(center.pohod(premiki, "i2"));
        System.out.println(center.pohod(premiki, "i25"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
