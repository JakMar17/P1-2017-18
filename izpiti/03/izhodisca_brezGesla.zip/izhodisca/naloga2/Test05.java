
import java.util.Arrays;

public class Test05 {

    public static void main(String[] args) {
        Druga.Izdelek[] izdelki = {
            new Druga.Izdelek("i0", 64),
            new Druga.Izdelek("i1", 47),
            new Druga.Izdelek("i2", 59),
            new Druga.Izdelek("i3", 26),
            new Druga.Izdelek("i4", 36),
            new Druga.Izdelek("i5", 58),
            new Druga.Izdelek("i6", 94),
            new Druga.Izdelek("i7", 4),
            new Druga.Izdelek("i8", 24),
            new Druga.Izdelek("i9", 25),
            new Druga.Izdelek("i10", 20),
            new Druga.Izdelek("i11", 56),
            new Druga.Izdelek("i12", 61),
            new Druga.Izdelek("i13", 13),
            new Druga.Izdelek("i14", 18),
            new Druga.Izdelek("i15", 78),
            new Druga.Izdelek("i16", 35),
            new Druga.Izdelek("i17", 74),
            new Druga.Izdelek("i18", 35),
            new Druga.Izdelek("i19", 16),
            new Druga.Izdelek("i20", 16),
        };
        int[] zaloga = {6, 8, 6, 4, 4, 10, 6, 5, 6, 5, 7, 9, 8, 10, 3, 0, 1, 2, 7, 8, 10};
        Druga.Trgovina trgovina = new Druga.Trgovina(izdelki, zaloga);

        System.out.println(trgovina.prodaj(14, 8));
        System.out.println(trgovina.prodaj(4, 5));
        System.out.println(trgovina.prodaj(12, 8));
        System.out.println(trgovina.prodaj(0, 4));
        System.out.println(trgovina.prodaj(6, 3));
        System.out.println(trgovina.prodaj(2, 4));
        System.out.println(trgovina.prodaj(10, 2));
        System.out.println(trgovina.prodaj(0, 3));
        System.out.println(trgovina.prodaj(4, 9));
        System.out.println(trgovina.vrniSaldo());
        System.out.println(Arrays.toString(trgovina.vrniZalogo()));
    }
}
