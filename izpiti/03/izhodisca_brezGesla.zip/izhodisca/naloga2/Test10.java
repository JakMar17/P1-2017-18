
import java.util.Arrays;

public class Test10 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 10);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 45);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 48);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 32);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 74);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 28);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 46);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 11);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 63);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 21);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 80);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 19);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 68);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 96);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 58);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 20);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 59);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 66);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 19);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 57);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 47);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 64);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 41);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 61);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 3);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 27);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 51);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 36);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 81);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 73);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 52);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 87);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 73);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 31);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 54);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 38);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 96);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 40);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 11);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 42);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 98);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 91);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[9][7];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i29}, new int[]{3, 8});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i27, i10, i7, i5}, new int[]{3, 6, 1, 3, 2});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{i26}, new int[]{7});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i40, i29, i41}, new int[]{3, 8, 5, 9});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i29}, new int[]{5});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i21, i4, i27}, new int[]{1, 5, 1, 8});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i10}, new int[]{9});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i23, i8, i36, i1}, new int[]{0, 0, 1, 5, 0});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i39, i22}, new int[]{2, 9, 3});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i13, i19, i9}, new int[]{8, 0, 1, 2});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i35, i27, i2}, new int[]{9, 9, 6});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i34}, new int[]{4, 3});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i22, i30, i18, i32}, new int[]{9, 3, 9, 1, 4});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i5, i8}, new int[]{5, 7, 5});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i30, i11, i39, i33}, new int[]{0, 3, 0, 1, 4});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i9, i26, i5}, new int[]{3, 9, 9, 0});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i30}, new int[]{5, 4});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i10, i21}, new int[]{5, 4, 3});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i19, i21}, new int[]{2, 2, 1});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i6, i23, i29, i28, i10}, new int[]{0, 5, 8, 9, 3});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i22, i30}, new int[]{0, 2, 6});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i17, i7, i39, i30}, new int[]{5, 6, 1, 4, 2});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i25, i37, i32, i12}, new int[]{9, 0, 7, 3, 5});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i7}, new int[]{9, 0});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i4}, new int[]{9, 7});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{i1, i2, i13, i16}, new int[]{4, 1, 9, 7});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i10, i4}, new int[]{0, 3, 5});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i41, i2, i36}, new int[]{2, 1, 7});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i23, i27, i31}, new int[]{8, 5, 0, 5});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i5, i21, i16}, new int[]{0, 5, 2, 9});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i0}, new int[]{2, 2});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{i22}, new int[]{7});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i41}, new int[]{9});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i13, i36, i1, i15}, new int[]{4, 5, 9, 0});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i14, i35, i8, i3}, new int[]{7, 8, 3, 5, 8});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i40, i32}, new int[]{2, 1, 2});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i16, i9, i26, i33}, new int[]{6, 1, 3, 6});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i24}, new int[]{7});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i8}, new int[]{2, 9});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i34, i33}, new int[]{5, 1, 3});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i19, i5, i3, i10}, new int[]{2, 8, 5, 9, 4});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i1}, new int[]{0, 9});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i25, i29, i24, i2}, new int[]{1, 5, 9, 4});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i41, i21, i40, i10}, new int[]{0, 1, 3, 1, 2});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{i36}, new int[]{7});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{i8, i27}, new int[]{0, 8});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i30}, new int[]{0});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i32}, new int[]{7});

        trgovine[8][0] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i20, i4, i26}, new int[]{7, 7, 1, 4});
        trgovine[8][1] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i31}, new int[]{8, 2});
        trgovine[8][2] = new Druga.Trgovina(new Druga.Izdelek[]{i41}, new int[]{5});
        trgovine[8][3] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i18, i22, i20}, new int[]{1, 9, 6, 7});
        trgovine[8][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[8][5] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[8][6] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i30}, new int[]{8, 8});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        int[][] premiki = {
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0, -1},
            {-1,  0},
            { 0, -1},
            { 1,  0},
            { 1,  0},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 0,  1},
            { 0,  1},
            { 1,  0},
            { 0, -1},
            { 0, -1},
            { 1,  0},
            { 0,  1},
            { 1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            {-1,  0},
            { 0,  1},
            { 1,  0},
            { 1,  0},
            { 0, -1},
        };

        System.out.println(center.pohod(premiki, "i37"));
        System.out.println(center.pohod(premiki, "i25"));
        System.out.println(center.pohod(premiki, "i18"));
        System.out.println(center.pohod(premiki, "i7"));
        System.out.println(center.pohod(premiki, "i32"));
        System.out.println(center.pohod(premiki, "i41"));
        System.out.println(center.pohod(premiki, "i5"));
        System.out.println(center.pohod(premiki, "i19"));
        System.out.println(center.pohod(premiki, "i16"));
        System.out.println(center.pohod(premiki, "i22"));

        for (int i = 0;  i < trgovine.length;  i++) {
            for (int j = 0;  j < trgovine[i].length;  j++) {
                System.out.println(trgovine[i][j].vrniSaldo());
                System.out.println(Arrays.toString(trgovine[i][j].vrniZalogo()));
            }
        }
    }
}
