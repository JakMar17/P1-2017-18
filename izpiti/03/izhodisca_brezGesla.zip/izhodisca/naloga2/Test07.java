
import java.util.Arrays;

public class Test07 {

    public static void main(String[] args) {
        Druga.Izdelek i0 = new Druga.Izdelek("i0", 78);
        Druga.Izdelek i1 = new Druga.Izdelek("i1", 11);
        Druga.Izdelek i2 = new Druga.Izdelek("i2", 79);
        Druga.Izdelek i3 = new Druga.Izdelek("i3", 89);
        Druga.Izdelek i4 = new Druga.Izdelek("i4", 11);
        Druga.Izdelek i5 = new Druga.Izdelek("i5", 3);
        Druga.Izdelek i6 = new Druga.Izdelek("i6", 57);
        Druga.Izdelek i7 = new Druga.Izdelek("i7", 81);
        Druga.Izdelek i8 = new Druga.Izdelek("i8", 82);
        Druga.Izdelek i9 = new Druga.Izdelek("i9", 84);
        Druga.Izdelek i10 = new Druga.Izdelek("i10", 66);
        Druga.Izdelek i11 = new Druga.Izdelek("i11", 82);
        Druga.Izdelek i12 = new Druga.Izdelek("i12", 73);
        Druga.Izdelek i13 = new Druga.Izdelek("i13", 72);
        Druga.Izdelek i14 = new Druga.Izdelek("i14", 11);
        Druga.Izdelek i15 = new Druga.Izdelek("i15", 78);
        Druga.Izdelek i16 = new Druga.Izdelek("i16", 91);
        Druga.Izdelek i17 = new Druga.Izdelek("i17", 63);
        Druga.Izdelek i18 = new Druga.Izdelek("i18", 15);
        Druga.Izdelek i19 = new Druga.Izdelek("i19", 21);
        Druga.Izdelek i20 = new Druga.Izdelek("i20", 47);
        Druga.Izdelek i21 = new Druga.Izdelek("i21", 38);
        Druga.Izdelek i22 = new Druga.Izdelek("i22", 68);
        Druga.Izdelek i23 = new Druga.Izdelek("i23", 80);
        Druga.Izdelek i24 = new Druga.Izdelek("i24", 73);
        Druga.Izdelek i25 = new Druga.Izdelek("i25", 100);
        Druga.Izdelek i26 = new Druga.Izdelek("i26", 48);
        Druga.Izdelek i27 = new Druga.Izdelek("i27", 65);
        Druga.Izdelek i28 = new Druga.Izdelek("i28", 99);
        Druga.Izdelek i29 = new Druga.Izdelek("i29", 95);
        Druga.Izdelek i30 = new Druga.Izdelek("i30", 76);
        Druga.Izdelek i31 = new Druga.Izdelek("i31", 18);
        Druga.Izdelek i32 = new Druga.Izdelek("i32", 41);
        Druga.Izdelek i33 = new Druga.Izdelek("i33", 75);
        Druga.Izdelek i34 = new Druga.Izdelek("i34", 14);
        Druga.Izdelek i35 = new Druga.Izdelek("i35", 27);
        Druga.Izdelek i36 = new Druga.Izdelek("i36", 95);
        Druga.Izdelek i37 = new Druga.Izdelek("i37", 50);
        Druga.Izdelek i38 = new Druga.Izdelek("i38", 8);
        Druga.Izdelek i39 = new Druga.Izdelek("i39", 58);
        Druga.Izdelek i40 = new Druga.Izdelek("i40", 54);
        Druga.Izdelek i41 = new Druga.Izdelek("i41", 65);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[8][9];

        trgovine[0][0] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i17, i26, i18}, new int[]{1, 5, 0, 3});
        trgovine[0][1] = new Druga.Trgovina(new Druga.Izdelek[]{i28}, new int[]{9});
        trgovine[0][2] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[0][4] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i36, i23, i40}, new int[]{0, 6, 7, 6});
        trgovine[0][5] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i5, i19}, new int[]{2, 7, 1});
        trgovine[0][6] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i28}, new int[]{3, 0});
        trgovine[0][7] = new Druga.Trgovina(new Druga.Izdelek[]{i33}, new int[]{9});
        trgovine[0][8] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});

        trgovine[1][0] = new Druga.Trgovina(new Druga.Izdelek[]{i20}, new int[]{8});
        trgovine[1][1] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i40, i19}, new int[]{1, 5, 9});
        trgovine[1][2] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i6}, new int[]{5, 1});
        trgovine[1][3] = new Druga.Trgovina(new Druga.Izdelek[]{i37}, new int[]{8});
        trgovine[1][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[1][5] = new Druga.Trgovina(new Druga.Izdelek[]{i36, i22, i25, i14, i27}, new int[]{5, 5, 8, 8, 5});
        trgovine[1][6] = new Druga.Trgovina(new Druga.Izdelek[]{i27}, new int[]{7});
        trgovine[1][7] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i31, i41, i11}, new int[]{0, 3, 4, 1});
        trgovine[1][8] = new Druga.Trgovina(new Druga.Izdelek[]{i11, i4, i6, i32}, new int[]{9, 3, 1, 4});

        trgovine[2][0] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i10}, new int[]{0, 2});
        trgovine[2][1] = new Druga.Trgovina(new Druga.Izdelek[]{i26, i30, i31, i21, i19}, new int[]{8, 9, 9, 9, 2});
        trgovine[2][2] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i24, i30}, new int[]{5, 3, 2});
        trgovine[2][3] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i9, i31}, new int[]{0, 6, 1});
        trgovine[2][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][5] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i30}, new int[]{7, 3});
        trgovine[2][6] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i20}, new int[]{1, 1});
        trgovine[2][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[2][8] = new Druga.Trgovina(new Druga.Izdelek[]{i32, i23, i12, i15}, new int[]{5, 5, 3, 4});

        trgovine[3][0] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[3][1] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i14, i37, i5}, new int[]{3, 0, 0, 1});
        trgovine[3][2] = new Druga.Trgovina(new Druga.Izdelek[]{i19, i23, i29, i14, i30}, new int[]{3, 9, 4, 4, 2});
        trgovine[3][3] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i40}, new int[]{1, 1});
        trgovine[3][4] = new Druga.Trgovina(new Druga.Izdelek[]{i12, i10}, new int[]{2, 4});
        trgovine[3][5] = new Druga.Trgovina(new Druga.Izdelek[]{i34}, new int[]{2});
        trgovine[3][6] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i34}, new int[]{1, 1});
        trgovine[3][7] = new Druga.Trgovina(new Druga.Izdelek[]{i18, i41, i15, i21, i14}, new int[]{6, 9, 9, 9, 2});
        trgovine[3][8] = new Druga.Trgovina(new Druga.Izdelek[]{i5, i38, i0, i8, i1}, new int[]{4, 3, 9, 7, 6});

        trgovine[4][0] = new Druga.Trgovina(new Druga.Izdelek[]{i21, i34, i2}, new int[]{3, 4, 7});
        trgovine[4][1] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][2] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i28, i25, i38}, new int[]{6, 2, 4, 0});
        trgovine[4][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][4] = new Druga.Trgovina(new Druga.Izdelek[]{i30, i3, i8}, new int[]{8, 1, 1});
        trgovine[4][5] = new Druga.Trgovina(new Druga.Izdelek[]{i40, i21}, new int[]{0, 6});
        trgovine[4][6] = new Druga.Trgovina(new Druga.Izdelek[]{i7, i16, i5, i27}, new int[]{6, 1, 9, 7});
        trgovine[4][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[4][8] = new Druga.Trgovina(new Druga.Izdelek[]{i9, i30, i6, i40}, new int[]{2, 0, 0, 6});

        trgovine[5][0] = new Druga.Trgovina(new Druga.Izdelek[]{i23, i37, i9, i32, i25}, new int[]{4, 9, 7, 3, 7});
        trgovine[5][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i35, i11}, new int[]{2, 5, 6});
        trgovine[5][2] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i16, i32, i15, i23}, new int[]{9, 8, 5, 9, 2});
        trgovine[5][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[5][4] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i25, i33, i17, i34}, new int[]{2, 4, 4, 1, 7});
        trgovine[5][5] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i29, i18}, new int[]{5, 1, 4});
        trgovine[5][6] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i0, i40, i34}, new int[]{6, 4, 6, 2});
        trgovine[5][7] = new Druga.Trgovina(new Druga.Izdelek[]{i28, i10, i18}, new int[]{4, 2, 0});
        trgovine[5][8] = new Druga.Trgovina(new Druga.Izdelek[]{i24, i37, i20, i6}, new int[]{9, 9, 4, 2});

        trgovine[6][0] = new Druga.Trgovina(new Druga.Izdelek[]{i3}, new int[]{5});
        trgovine[6][1] = new Druga.Trgovina(new Druga.Izdelek[]{i17, i3, i1}, new int[]{0, 0, 8});
        trgovine[6][2] = new Druga.Trgovina(new Druga.Izdelek[]{i34, i30, i21}, new int[]{5, 7, 1});
        trgovine[6][3] = new Druga.Trgovina(new Druga.Izdelek[]{i10, i14, i35, i31, i8}, new int[]{6, 8, 9, 6, 8});
        trgovine[6][4] = new Druga.Trgovina(new Druga.Izdelek[]{i27, i35, i13}, new int[]{7, 2, 9});
        trgovine[6][5] = new Druga.Trgovina(new Druga.Izdelek[]{i20}, new int[]{4});
        trgovine[6][6] = new Druga.Trgovina(new Druga.Izdelek[]{i15}, new int[]{3});
        trgovine[6][7] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i18}, new int[]{8, 7});
        trgovine[6][8] = new Druga.Trgovina(new Druga.Izdelek[]{i38, i19, i41, i35}, new int[]{2, 4, 3, 5});

        trgovine[7][0] = new Druga.Trgovina(new Druga.Izdelek[]{i22, i34}, new int[]{4, 6});
        trgovine[7][1] = new Druga.Trgovina(new Druga.Izdelek[]{i20, i26, i6}, new int[]{9, 9, 0});
        trgovine[7][2] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i6, i1, i15, i5}, new int[]{7, 1, 7, 6, 4});
        trgovine[7][3] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][4] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][5] = new Druga.Trgovina(new Druga.Izdelek[]{i0, i38, i40}, new int[]{3, 9, 1});
        trgovine[7][6] = new Druga.Trgovina(new Druga.Izdelek[]{i39, i6, i0, i37}, new int[]{6, 4, 0, 1});
        trgovine[7][7] = new Druga.Trgovina(new Druga.Izdelek[]{}, new int[]{});
        trgovine[7][8] = new Druga.Trgovina(new Druga.Izdelek[]{i37, i24, i41, i26}, new int[]{9, 9, 8, 2});

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        System.out.println(center.vSosescini(5, 5, "i12"));
        System.out.println(center.vSosescini(4, 4, "i39"));
        System.out.println(center.vSosescini(5, 2, "i5"));
        System.out.println(center.vSosescini(1, 2, "i38"));
        System.out.println(center.vSosescini(3, 7, "i38"));
        System.out.println(center.vSosescini(4, 2, "i13"));
        System.out.println(center.vSosescini(3, 4, "i6"));
        System.out.println(center.vSosescini(3, 2, "i4"));
        System.out.println(center.vSosescini(6, 2, "i20"));
        System.out.println(center.vSosescini(3, 1, "i37"));
        System.out.println(center.vSosescini(3, 5, "i13"));
        System.out.println(center.vSosescini(1, 1, "i19"));
        System.out.println(center.vSosescini(5, 4, "i26"));
        System.out.println(center.vSosescini(1, 4, "i37"));
        System.out.println(center.vSosescini(6, 1, "i41"));
        System.out.println(center.vSosescini(1, 3, "i9"));
        System.out.println(center.vSosescini(6, 4, "i0"));
        System.out.println(center.vSosescini(6, 1, "i3"));
        System.out.println(center.vSosescini(3, 4, "i15"));
        System.out.println(center.vSosescini(1, 1, "i26"));
    }
}
