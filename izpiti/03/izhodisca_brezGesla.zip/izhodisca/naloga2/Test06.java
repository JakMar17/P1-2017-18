
public class Test06 {

    public static void main(String[] args) {
        Druga.Izdelek mleko   = new Druga.Izdelek("mleko",    0);
        Druga.Izdelek kruh    = new Druga.Izdelek("kruh",    10);
        Druga.Izdelek moka    = new Druga.Izdelek("moka",    20);
        Druga.Izdelek riz     = new Druga.Izdelek("riz",     30);
        Druga.Izdelek breskve = new Druga.Izdelek("breskve", 40);
        Druga.Izdelek jogurt  = new Druga.Izdelek("jogurt",  50);
        Druga.Izdelek pivo    = new Druga.Izdelek("pivo",    60);
        Druga.Izdelek maslo   = new Druga.Izdelek("maslo",   70);
        Druga.Izdelek sladkor = new Druga.Izdelek("sladkor", 80);
        Druga.Izdelek salama  = new Druga.Izdelek("salama",  90);

        Druga.Trgovina[][] trgovine = new Druga.Trgovina[3][4];

        trgovine[0][0] = new Druga.Trgovina(
                new Druga.Izdelek[]{mleko, riz, pivo},
                new int[]{2, 0, 3}
        );
        trgovine[0][1] = new Druga.Trgovina(
                new Druga.Izdelek[]{jogurt, kruh},
                new int[]{4, 5}
        );
        trgovine[0][2] = new Druga.Trgovina(
                new Druga.Izdelek[]{kruh, riz, breskve, pivo},
                new int[]{1, 1, 2, 0}
        );
        trgovine[0][3] = new Druga.Trgovina(
                new Druga.Izdelek[]{},
                new int[]{}
        );

        trgovine[1][0] = new Druga.Trgovina(
                new Druga.Izdelek[]{riz},
                new int[]{7}
        );
        trgovine[1][1] = new Druga.Trgovina(
                new Druga.Izdelek[]{breskve, mleko},
                new int[]{2, 4}
        );
        trgovine[1][2] = new Druga.Trgovina(
                new Druga.Izdelek[]{mleko, moka, jogurt},
                new int[]{6, 5, 8}
        );
        trgovine[1][3] = new Druga.Trgovina(
                new Druga.Izdelek[]{jogurt, pivo, sladkor},
                new int[]{3, 5, 0}
        );

        trgovine[2][0] = new Druga.Trgovina(
                new Druga.Izdelek[]{kruh, salama},
                new int[]{10, 7}
        );
        trgovine[2][1] = new Druga.Trgovina(
                new Druga.Izdelek[]{breskve, kruh},
                new int[]{9, 3}
        );
        trgovine[2][2] = new Druga.Trgovina(
                new Druga.Izdelek[]{mleko, kruh, riz, breskve, jogurt, pivo},
                new int[]{0, 1, 1, 0, 1, 1}
        );
        trgovine[2][3] = new Druga.Trgovina(
                new Druga.Izdelek[]{jogurt},
                new int[]{6}
        );

        Druga.TrgovskiCenter center = new Druga.TrgovskiCenter(trgovine);

        // Masla ne prodajajo nikjer.
        // Salamo prodajajo samo v trgovini [2][0].
        // Sladkor prodajajo samo v trgovini [1][3].
        // Moko prodajajo samo v trgovini [1][2].

        System.out.println(center.vSosescini(1, 1, "kruh"));
        System.out.println(center.vSosescini(1, 1, "maslo"));
        System.out.println(center.vSosescini(1, 1, "salama"));
        System.out.println(center.vSosescini(1, 1, "sladkor"));
        System.out.println(center.vSosescini(1, 1, "moka"));
        System.out.println("----------");

        System.out.println(center.vSosescini(1, 2, "kruh"));
        System.out.println(center.vSosescini(1, 2, "maslo"));
        System.out.println(center.vSosescini(1, 2, "salama"));
        System.out.println(center.vSosescini(1, 2, "sladkor"));
        System.out.println(center.vSosescini(1, 2, "moka"));

    }
}
