
public class Test03 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(37723));
        System.out.println(Prva.alternirajocaVsota(70915));
        System.out.println(Prva.alternirajocaVsota(27184));

        System.out.println(Prva.alternirajocaVsota(638465));
        System.out.println(Prva.alternirajocaVsota(600200));
        System.out.println(Prva.alternirajocaVsota(908172));
    }
}
