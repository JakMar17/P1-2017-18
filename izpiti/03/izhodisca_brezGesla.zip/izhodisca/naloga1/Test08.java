
import java.util.Arrays;

public class Test08 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'O', '*', 'V', 'r', 'b', 'a'},
            {'s', 'r', 'e', 'c', 'n', 'a'},
            {'d', 'r', 'a', 'g', 'a', '*'},
            {'v', 'a', 's', '*', 'd', 'o'},
            {'m', 'a', 'c', 'a', '*', '_'},
            {'*', '_', '_', '_', '_', '_'},
            {'_', '_', '*', '_', '_', '_'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
