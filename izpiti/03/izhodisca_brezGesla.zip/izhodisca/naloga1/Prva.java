
// 
// (v prej"snji vrstici dopi"site va"so vpisno "stevilko)

public class Prva {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }

    //=========================================================================
    // V vseh testnih primerih velja n > 0.
    //=========================================================================

    public static int alternirajocaVsota(int n) {
        // popravite / dopolnite ...
        return 99999;
    }

    //=========================================================================
    // V vseh testnih primerih velja:
    // -- "stevilo vrstic tabele t je med 1 in 500
    // -- "stevilo stolpcev tabele t je med 1 in 500
    //
    // V testnih primerih J6--J7 in S26--S35 ima tabela en sam stolpec.
    //
    // V testnih primerih J6, J8, S26--S30 in S36--S40 je v vsakem stolpcu
    // _natanko_ ena zvezdica.
    //=========================================================================

    public static int[] polozajiZvezdic(char[][] t) {
        // popravite / dopolnite ...
        return null;
    }
}
