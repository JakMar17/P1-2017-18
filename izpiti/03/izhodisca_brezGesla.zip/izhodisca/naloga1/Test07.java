
import java.util.Arrays;

public class Test07 {

    public static void main(String[] args) {
        char[][] tabela = {
            {'a'},
            {'*'},
            {'*'},
            {'b'},
            {'*'},
            {'*'},
            {'c'},
            {'d'},
            {'*'},
            {'*'},
            {'*'},
            {'e'},
            {'*'},
            {'*'},
            {'f'},
            {'g'},
            {'h'},
            {'i'}
        };
        System.out.println(Arrays.toString(Prva.polozajiZvezdic(tabela)));
    }
}
