
public class Test04 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(7654321));
        System.out.println(Prva.alternirajocaVsota(2323232));
        System.out.println(Prva.alternirajocaVsota(1905264));

        System.out.println(Prva.alternirajocaVsota(11111111));
        System.out.println(Prva.alternirajocaVsota(81907192));
        System.out.println(Prva.alternirajocaVsota(66100328));
    }
}
