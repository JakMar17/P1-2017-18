
public class Test05 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(562974310));
        System.out.println(Prva.alternirajocaVsota(645811037));
        System.out.println(Prva.alternirajocaVsota(158932633));

        System.out.println(Prva.alternirajocaVsota(1079264385));
        System.out.println(Prva.alternirajocaVsota(2003004005));
        System.out.println(Prva.alternirajocaVsota(1665987947));
    }
}
