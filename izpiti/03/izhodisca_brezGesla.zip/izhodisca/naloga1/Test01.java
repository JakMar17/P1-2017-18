
public class Test01 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(3));
        System.out.println(Prva.alternirajocaVsota(7));
        System.out.println(Prva.alternirajocaVsota(4));

        System.out.println(Prva.alternirajocaVsota(15));
        System.out.println(Prva.alternirajocaVsota(71));
        System.out.println(Prva.alternirajocaVsota(90));
    }
}
