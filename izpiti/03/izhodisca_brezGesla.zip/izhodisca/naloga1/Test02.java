
public class Test02 {

    public static void main(String[] args) {
        System.out.println(Prva.alternirajocaVsota(444));
        System.out.println(Prva.alternirajocaVsota(123));
        System.out.println(Prva.alternirajocaVsota(290));

        System.out.println(Prva.alternirajocaVsota(5000));
        System.out.println(Prva.alternirajocaVsota(3921));
        System.out.println(Prva.alternirajocaVsota(9080));
    }
}
