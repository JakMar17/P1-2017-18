// _NE_ODSTRANI_

import java.awt.Color;

public class Test10 {

    public static void main(String[] args) {

        int dolzina = 10;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.CYAN),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Polje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Posest(Color.GREEN),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Polje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.RED),
            new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
            new Tretja.Presenecenje(),
            new Tretja.Posest(Color.ORANGE),
            new Tretja.Posest(Color.MAGENTA),
            new Tretja.Presenecenje(),
            new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat10.png", "500x800"});
    }
}
