// _NE_ODSTRANI_

public class Test06 {

    public static void main(String[] args) {

        int dolzina = 6;
        Tretja.Polje[] polja = {
            new Tretja.Presenecenje(), new Tretja.Polje(), new Tretja.Presenecenje(), new Tretja.Presenecenje(),
            new Tretja.Polje(), new Tretja.Presenecenje(), new Tretja.Presenecenje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Presenecenje(), new Tretja.Polje(),
            new Tretja.Presenecenje(), new Tretja.Presenecenje(), new Tretja.Polje(), new Tretja.Presenecenje(),
            new Tretja.Presenecenje(), new Tretja.Polje(), new Tretja.Presenecenje(), new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat06.png", "516x828"});
    }
}
