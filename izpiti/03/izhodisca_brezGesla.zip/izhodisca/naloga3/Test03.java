// _NE_ODSTRANI_

public class Test03 {

    public static void main(String[] args) {

        int dolzina = 7;
        Tretja.Polje[] polja = {
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat03.png", "420x420"});
    }
}
