
public class Test02 {

    public static void main(String[] args) {

        int dolzina = 6;
        Tretja.Polje[] polja = {
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);

        System.out.println(Platno.ri(tretja.stranicaPolja(600, 360)));
        System.out.println(Platno.ri(tretja.xLevo(600, 360)));
        System.out.println(Platno.ri(tretja.yZgoraj(600, 360)));

        System.out.println(Platno.ri(tretja.stranicaPolja(432, 684)));
        System.out.println(Platno.ri(tretja.xLevo(432, 684)));
        System.out.println(Platno.ri(tretja.yZgoraj(432, 684)));
    }
}
