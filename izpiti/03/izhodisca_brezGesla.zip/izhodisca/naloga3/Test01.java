
import java.awt.Color;

public class Test01 {

    public static void main(String[] args) {

        int dolzina = 5;
        Tretja.Polje[] polja = {
            new Tretja.Polje(), new Tretja.Posest(Color.RED), new Tretja.Presenecenje(), new Tretja.Posest(Color.RED),
            new Tretja.Polje(), new Tretja.Presenecenje(), new Tretja.Posest(Color.GREEN), new Tretja.Posest(Color.BLUE),
            new Tretja.Presenecenje(), new Tretja.Posest(Color.GREEN), new Tretja.Presenecenje(), new Tretja.Polje(),
            new Tretja.Presenecenje(), new Tretja.Posest(Color.ORANGE), new Tretja.Polje(), new Tretja.Posest(Color.BLUE),
        };

        Tretja tretja = new Tretja(dolzina, polja);

        System.out.println(Platno.ri(tretja.stranicaPolja(500, 500)));
        System.out.println(Platno.ri(tretja.xLevo(500, 500)));
        System.out.println(Platno.ri(tretja.yZgoraj(500, 500)));

        System.out.println(Platno.ri(tretja.stranicaPolja(720, 720)));
        System.out.println(Platno.ri(tretja.xLevo(720, 720)));
        System.out.println(Platno.ri(tretja.yZgoraj(720, 720)));
    }
}
