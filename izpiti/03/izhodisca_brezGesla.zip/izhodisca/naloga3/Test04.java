// _NE_ODSTRANI_

public class Test04 {

    public static void main(String[] args) {

        int dolzina = 12;
        Tretja.Polje[] polja = {
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), 
            new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(), new Tretja.Polje(),
        };

        Tretja tretja = new Tretja(dolzina, polja);
        tretja.sproziRisanje(new String[]{"rezultat04.png", "840x576"});
    }
}
