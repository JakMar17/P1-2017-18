// _NE_ODSTRANI_

import java.awt.Color;

public class Test06 {

    public static void main(String[] args) {
        double wHise = 33.0;
        double hHise = 23.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino( true,  0.0,  0.0, 33.0, 2.0, Color.RED,   15.0),
            new Tretja.StenaZOdprtino( true,  0.0,  7.5, 33.0, 1.0, Color.GREEN,  5.0),
            new Tretja.StenaZOdprtino( true,  0.0, 14.5, 33.0, 1.0, Color.GREEN,  5.0),
            new Tretja.StenaZOdprtino( true,  0.0, 21.0, 33.0, 2.0, Color.RED,   15.0),

            new Tretja.StenaZOdprtino(false,  0.0,  0.0, 23.0, 3.0, Color.BLUE,    8.0),
            new Tretja.StenaZOdprtino(false, 10.5,  0.0, 23.0, 2.0, Color.MAGENTA, 4.0),
            new Tretja.StenaZOdprtino(false, 20.5,  0.0, 23.0, 2.0, Color.MAGENTA, 4.0),
            new Tretja.StenaZOdprtino(false, 30.0,  0.0, 23.0, 3.0, Color.BLUE,    8.0),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat06.png", "660x460"});
    }
}
