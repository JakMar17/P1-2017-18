// _NE_ODSTRANI_

import java.awt.Color;

public class Test05 {

    public static void main(String[] args) {
        double wHise = 1.0;
        double hHise = 1.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(true,  0.1, 0.0, 0.8, 0.1, Color.RED,    0.2),
            new Tretja.StenaZOdprtino(false, 0.9, 0.1, 0.8, 0.1, Color.GREEN,  0.3),
            new Tretja.StenaZOdprtino(true,  0.1, 0.9, 0.8, 0.1, Color.BLUE,   0.4),
            new Tretja.StenaZOdprtino(false, 0.0, 0.1, 0.8, 0.1, Color.YELLOW, 0.5),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat05.png", "600x600"});
    }
}
