
public class Test01 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(9, 6, new Tretja.Stena[0]);

        System.out.println(Platno.ri(tretja.xTlorisa(900, 600)));
        System.out.println(Platno.ri(tretja.xTlorisa(360, 240)));
        System.out.println(Platno.ri(tretja.xTlorisa(450, 300)));

        System.out.println(Platno.ri(tretja.yTlorisa(900, 600)));
        System.out.println(Platno.ri(tretja.yTlorisa(360, 240)));
        System.out.println(Platno.ri(tretja.yTlorisa(450, 300)));
    }
}
