// _NE_ODSTRANI_

import java.awt.Color;

public class Test07 {

    public static void main(String[] args) {
        double wHise = 3.0;
        double hHise = 4.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(true,  0.0, 1.7, 3.0, 0.6, Color.CYAN,   1.0),
            new Tretja.StenaZOknom(false, 1.4, 0.0, 4.0, 0.2, Color.ORANGE, 2.0),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat07.png", "480x640"});
    }
}
