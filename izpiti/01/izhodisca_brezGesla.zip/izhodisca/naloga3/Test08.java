// _NE_ODSTRANI_

import java.awt.Color;

public class Test08 {

    public static void main(String[] args) {
        double wHise = 20.0;
        double hHise = 20.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(          true,  2.0,  0.0, 16.0, 2.0),
            new Tretja.StenaZOknom(   false, 18.0,  2.0, 16.0, 2.0, Color.CYAN,    6.0),
            new Tretja.StenaZOdprtino( true,  2.0, 18.0, 16.0, 2.0, Color.MAGENTA, 2.0),
            new Tretja.StenaZOknom(   false,  0.0,  2.0, 16.0, 2.0, Color.YELLOW,  4.0),

            new Tretja.StenaZOknom(    true,  7.0,  6.0,  6.0, 1.0, Color.RED,   3.0),
            new Tretja.Stena(         false, 13.0,  7.0,  6.0, 1.0),
            new Tretja.StenaZOknom(    true,  7.0, 13.0,  6.0, 1.0, Color.GREEN, 1.0),
            new Tretja.StenaZOdprtino(false,  6.0,  7.0,  6.0, 1.0, Color.BLUE,  2.0),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat08.png", "800x800"});
    }
}
