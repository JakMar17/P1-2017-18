// _NE_ODSTRANI_

import java.awt.Color;

public class Test10 {

    public static void main(String[] args) {
        double wHise = 9.0;
        double hHise = 6.0;

        Tretja.Stena[] stene = {
            // zunanja, vodoravna, zgoraj levo
            new Tretja.StenaZOknom(true, 0.5, 0.0, 4.7, 0.5, Color.CYAN, 1.6),

            // zunanja, vodoravna, zgoraj desno
            new Tretja.Stena(true, 5.2, 0.0, 3.3, 0.5),

            // zunanja, navpi"cna, levo
            new Tretja.StenaZOdprtino(false, 0.0, 0.0, 6.0, 0.5, Color.RED, 2.0),

            // zunanja, navpi"cna, desno
            new Tretja.StenaZOknom(false, 8.5, 0.0, 6.0, 0.5, Color.GREEN, 0.8),

            // zunanja, vodoravna, spodaj levo
            new Tretja.StenaZVrati(true, 0.5, 5.5, 4.5, 0.5, Color.MAGENTA, 1.2, true),

            // zunanja, vodoravna, spodaj desno
            new Tretja.Stena(true, 5.0, 5.5, 3.5, 0.5),

            // notranja, navpi"cna, zgoraj
            new Tretja.Stena(false, 5.0, 0.5, 1.7, 0.2),

            // notranja, navpi"cna, spodaj
            new Tretja.StenaZVrati(false, 5.0, 2.2, 3.3, 0.2, Color.BLUE, 0.6, true),

            // notranja, vodoravna
            new Tretja.StenaZVrati(true, 5.2, 2.0, 3.3, 0.2, Color.YELLOW, 0.4, false),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat10.png", "900x600"});
    }
}
