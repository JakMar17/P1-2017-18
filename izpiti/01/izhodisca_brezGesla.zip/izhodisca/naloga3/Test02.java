
public class Test02 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(5, 7, new Tretja.Stena[0]);

        System.out.println(Platno.ri(tretja.pikNaMeter(500, 700)));
        System.out.println(Platno.ri(tretja.pikNaMeter(300, 420)));
        System.out.println(Platno.ri(tretja.pikNaMeter(800, 1120)));
    }
}
