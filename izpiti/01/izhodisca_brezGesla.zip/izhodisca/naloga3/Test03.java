// _NE_ODSTRANI_

public class Test03 {

    public static void main(String[] args) {
        double wHise = 9.0;
        double hHise = 6.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true,  0.0, 0.0, 9.0, 0.4),
            new Tretja.Stena(false, 0.0, 0.0, 6.0, 0.4),
            new Tretja.Stena(true,  0.0, 5.6, 9.0, 0.4),
            new Tretja.Stena(false, 8.6, 0.0, 6.0, 0.4),
            new Tretja.Stena(true,  0.0, 2.0, 9.0, 0.2),
            new Tretja.Stena(false, 3.0, 0.0, 6.0, 0.2),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat03.png", "900x600"});
    }
}
