// _NE_ODSTRANI_

import java.awt.Color;

public class Test09 {

    public static void main(String[] args) {
        double wHise = 5.0;
        double hHise = 8.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZVrati(true,  0.0, 0.0, 5.0, 0.2, Color.MAGENTA, 2.0, false),
            new Tretja.StenaZVrati(false, 4.8, 0.0, 8.0, 0.2, Color.ORANGE,  1.5, true),
            new Tretja.StenaZVrati(true,  0.0, 7.8, 5.0, 0.2, Color.PINK,    3.0, true),
            new Tretja.StenaZVrati(false, 0.0, 0.0, 8.0, 0.2, Color.CYAN,    1.0, false),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat09.png", "450x720"});
    }
}
