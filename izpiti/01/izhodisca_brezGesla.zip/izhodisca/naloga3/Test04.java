// _NE_ODSTRANI_

public class Test04 {

    public static void main(String[] args) {
        double wHise = 5.0;
        double hHise = 7.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true,  0.0, 0.0, 5.0, 0.4),
            new Tretja.Stena(false, 0.0, 0.0, 7.0, 0.4),
            new Tretja.Stena(true,  0.0, 6.6, 5.0, 0.4),
            new Tretja.Stena(false, 4.6, 0.0, 7.0, 0.4),
            new Tretja.Stena(false, 2.0, 3.0, 2.5, 1.0),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat04.png", "550x770"});
    }
}
