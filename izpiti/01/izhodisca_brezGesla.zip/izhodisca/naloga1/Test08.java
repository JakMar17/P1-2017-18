
public class Test08 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(450172030086L));
    }
}
