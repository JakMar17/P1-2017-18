
public class Test04 {

    public static void main(String[] args) {
        int[] a = {7, 14, 21, 28, 35, 42, 49, 56, 63, 70};
        System.out.println(Prva.zadnjiDeljiviPar(a, 7));

        int[] b = {8, 16, 24, 32, 40, 48, 56, 64, 72, 80};
        System.out.println(Prva.zadnjiDeljiviPar(b, 7));
    }
}
