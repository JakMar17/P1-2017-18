
public class Test07 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(44054395829396L));
        System.out.println(Prva.odstraniNicle(95234783086798L));
        System.out.println(Prva.odstraniNicle(35022531245842L));
        System.out.println(Prva.odstraniNicle(64015638826297L));
        System.out.println(Prva.odstraniNicle(49137624210955L));
        System.out.println(Prva.odstraniNicle(99442768790414L));
        System.out.println(Prva.odstraniNicle(20254477382515L));
        System.out.println(Prva.odstraniNicle(29622309961289L));
        System.out.println(Prva.odstraniNicle(72370238617523L));
        System.out.println(Prva.odstraniNicle(94019886858117L));
    }
}
