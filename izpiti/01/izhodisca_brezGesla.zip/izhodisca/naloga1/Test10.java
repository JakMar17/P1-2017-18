
public class Test10 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(300005009L));
        System.out.println(Prva.odstraniNicle(900908000L));
        System.out.println(Prva.odstraniNicle(900500003L));
        System.out.println(Prva.odstraniNicle(700006001L));
        System.out.println(Prva.odstraniNicle(850040000L));
        System.out.println(Prva.odstraniNicle(550000800L));
        System.out.println(Prva.odstraniNicle(200250000L));
        System.out.println(Prva.odstraniNicle(380200000L));
        System.out.println(Prva.odstraniNicle(500200090L));
        System.out.println(Prva.odstraniNicle(460000500L));
    }
}
