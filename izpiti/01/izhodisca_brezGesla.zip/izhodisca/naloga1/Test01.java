
public class Test01 {

    public static void main(String[] args) {
        int[] a = {1, 3, 4, 6, 5, 4, 3, 2, 1};
        System.out.println(Prva.zadnjiDeljiviPar(a, 2));

        int[] b = {20, 30, 15, 10, 5, 40, 6, 50};
        System.out.println(Prva.zadnjiDeljiviPar(b, 10));

        int[] c = {30, 15, 10, 5, 40, 6, 50, 20};
        System.out.println(Prva.zadnjiDeljiviPar(c, 10));
    }
}
