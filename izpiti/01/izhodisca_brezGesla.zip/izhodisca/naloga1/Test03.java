
public class Test03 {

    public static void main(String[] args) {
        int[] tabela = {15, 3, 4, 12, 24, 9, 21, 5, 18};
        System.out.println(Prva.zadnjiDeljiviPar(tabela, 3));
    }
}
