
public class Test09 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(2000000L));
        System.out.println(Prva.odstraniNicle(30000007L));
        System.out.println(Prva.odstraniNicle(90008000700600L));
        System.out.println(Prva.odstraniNicle(102030405060708090L));
    }
}
