
public class Test06 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(60L));
        System.out.println(Prva.odstraniNicle(407L));
        System.out.println(Prva.odstraniNicle(5403L));
        System.out.println(Prva.odstraniNicle(20964L));
        System.out.println(Prva.odstraniNicle(123405L));
    }
}
