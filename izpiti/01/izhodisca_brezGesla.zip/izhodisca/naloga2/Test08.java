
import java.util.Arrays;

public class Test08 {

    public static void main(String[] args) {

        // strokovni
        Druga.Predmet analiza = new Druga.Predmet("Analiza", 6, true, 2);
        Druga.Predmet programiranje = new Druga.Predmet("Programiranje", 7, true, 2);
        Druga.Predmet algoritmi = new Druga.Predmet("Algoritmi", 9, true, 2);
        Druga.Predmet la = new Druga.Predmet("Linearna algebra", 5, true, 4);
        Druga.Predmet ars = new Druga.Predmet("Arhitektura racunalniskih sistemov", 8, true, 4);

        // prosto izbirni
        Druga.Predmet ui = new Druga.Predmet("Umetna inteligenca", 5, false, 3);
        Druga.Predmet anglescina = new Druga.Predmet("Angleski jezik", 3, false, 5);
        Druga.Predmet baze = new Druga.Predmet("Podatkovne baze", 6, false, 4);
        Druga.Predmet grafika = new Druga.Predmet("Racunalniska grafika", 4, false, 3);
        Druga.Predmet os = new Druga.Predmet("Operacijski sistemi", 7, false, 3);

        Druga.Student[] studentje = {
            new Druga.Student(
                "Strokovna Ana", 
                new Druga.Predmet[]{analiza, programiranje, algoritmi},
                new int[]{9, 8, 10}
            ),
            new Druga.Student(
                "Izbirni Bojan",
                new Druga.Predmet[]{ui, grafika, baze, os},
                new int[]{6, 7, 3, 0}
            ),
            new Druga.Student(
                "Univerzalna Cvetka", 
                new Druga.Predmet[]{programiranje, la, ars, baze, grafika, os},
                new int[]{7, 0, 4, 6, 5, 9}
            ),
            new Druga.Student(
                "Nesrecni Denis", 
                new Druga.Predmet[]{anglescina, baze, grafika, algoritmi, la},
                new int[]{5, 6, 5, 6, 5}
            ),
            new Druga.Student(
                "Lezerna Eva", 
                new Druga.Predmet[]{anglescina},
                new int[]{0}
            ),
            new Druga.Student(
                "Brezupni Franci",
                new Druga.Predmet[]{algoritmi, ars, la, analiza},
                new int[]{1, 1, 1, 1}
            )
        };

        Druga.Letnik letnik = new Druga.Letnik(studentje);

        Druga.Predmet[] predmeti = {
            analiza, programiranje, algoritmi, la, ars,
            ui, anglescina, baze, grafika, os
        };

        for (int d = 1;  d <= 5;  d++) {
            System.out.printf("dan %d: %d%n", d, letnik.morebitnaPrekrivanja(d));
        }
    }
}
