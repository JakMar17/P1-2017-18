
import java.util.Arrays;

public class Test04 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[28];
        p[0] = new Druga.Predmet("p0", 14, true, 5);
        p[1] = new Druga.Predmet("p1", 6, false, 4);
        p[2] = new Druga.Predmet("p2", 17, true, 4);
        p[3] = new Druga.Predmet("p3", 12, true, 3);
        p[4] = new Druga.Predmet("p4", 6, true, 2);
        p[5] = new Druga.Predmet("p5", 13, true, 1);
        p[6] = new Druga.Predmet("p6", 5, true, 5);
        p[7] = new Druga.Predmet("p7", 9, true, 4);
        p[8] = new Druga.Predmet("p8", 1, true, 1);
        p[9] = new Druga.Predmet("p9", 19, true, 1);
        p[10] = new Druga.Predmet("p10", 10, false, 1);
        p[11] = new Druga.Predmet("p11", 4, false, 4);
        p[12] = new Druga.Predmet("p12", 18, false, 3);
        p[13] = new Druga.Predmet("p13", 5, false, 3);
        p[14] = new Druga.Predmet("p14", 4, false, 4);
        p[15] = new Druga.Predmet("p15", 14, true, 4);
        p[16] = new Druga.Predmet("p16", 15, false, 5);
        p[17] = new Druga.Predmet("p17", 10, true, 1);
        p[18] = new Druga.Predmet("p18", 16, true, 4);
        p[19] = new Druga.Predmet("p19", 16, true, 2);
        p[20] = new Druga.Predmet("p20", 18, false, 3);
        p[21] = new Druga.Predmet("p21", 2, true, 2);
        p[22] = new Druga.Predmet("p22", 17, true, 1);
        p[23] = new Druga.Predmet("p23", 11, true, 5);
        p[24] = new Druga.Predmet("p24", 8, false, 3);
        p[25] = new Druga.Predmet("p25", 1, true, 2);
        p[26] = new Druga.Predmet("p26", 10, true, 3);
        p[27] = new Druga.Predmet("p27", 2, true, 5);

        Druga.Student[] s = new Druga.Student[20];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[8], p[9], p[10], p[12], p[13], p[14], p[15], p[17], p[18], p[20], p[22], p[23], p[24], p[25], p[26], p[27]}, new int[]{9, 8, 1, 9, 1, 2, 10, 10, 5, 8, 9, 1, 8, 9, 6, 6, 9, 8, 6, 6, 8});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[25], p[26]}, new int[]{0, 0});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[2], p[4], p[5], p[7], p[11], p[15], p[18], p[22], p[25]}, new int[]{6, 3, 5, 0, 3, 8, 2, 7, 7});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[6], p[7], p[8], p[10], p[11], p[12], p[14], p[16], p[17], p[19], p[21], p[24], p[26], p[27]}, new int[]{1, 4, 9, 8, 3, 5, 8, 10, 0, 6, 5, 1, 7, 8, 6, 0, 9, 0, 0});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[15], p[17], p[18], p[19], p[21], p[22], p[23], p[25], p[26], p[27]}, new int[]{6, 10, 4, 9, 6, 3, 0, 1, 1, 7, 3, 0, 7, 10, 7, 9, 7, 9, 0});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[0], p[2], p[4], p[6], p[7], p[8], p[9], p[11], p[12], p[13], p[14], p[16], p[18], p[19], p[20], p[21], p[22], p[24], p[25], p[27]}, new int[]{0, 3, 4, 2, 4, 5, 5, 4, 0, 1, 0, 4, 5, 1, 3, 1, 0, 4, 3, 5});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[0], p[2], p[5], p[6], p[7], p[17], p[18], p[19], p[22], p[27]}, new int[]{1, 4, 4, 4, 5, 2, 3, 2, 4, 1});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[2], p[6], p[12], p[13], p[14], p[20], p[22]}, new int[]{4, 2, 0, 5, 4, 3, 0});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[15], p[17], p[18], p[19], p[21], p[22], p[23], p[25], p[26], p[27]}, new int[]{3, 1, 3, 0, 4, 5, 4, 1, 5, 4, 0, 4, 3, 4, 4, 5, 4, 5, 2});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[2], p[3]}, new int[]{7, 7});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[0], p[2], p[4], p[5], p[8], p[9], p[26], p[27]}, new int[]{0, 2, 5, 6, 8, 3, 0, 9});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[7], p[8], p[9], p[13], p[14], p[17], p[18], p[19], p[24], p[25], p[27]}, new int[]{4, 0, 5, 0, 1, 0, 4, 3, 2, 5, 4, 2, 1, 3, 5, 3, 5});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[0], p[2], p[5], p[6], p[7], p[8], p[9], p[15], p[17], p[19], p[22], p[23], p[25], p[26]}, new int[]{3, 1, 1, 0, 0, 5, 0, 4, 1, 3, 0, 3, 5, 3});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[4]}, new int[]{4});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27]}, new int[]{1, 0, 2, 5, 4, 4, 5, 5, 5, 5, 4, 5, 3, 4, 4, 5, 5, 0, 2, 3, 5, 1, 4, 3, 0, 3, 5, 5});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[2], p[4], p[5], p[8], p[17], p[21], p[25]}, new int[]{2, 9, 10, 7, 0, 10, 0});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[4], p[9], p[13], p[14], p[18], p[22], p[24], p[26], p[27]}, new int[]{3, 0, 2, 2, 1, 5, 4, 4, 0});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[5], p[7]}, new int[]{8, 0});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[7], p[8], p[9], p[11], p[13], p[14], p[15], p[17], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27]}, new int[]{2, 2, 1, 0, 6, 3, 8, 3, 0, 5, 8, 1, 5, 7, 2, 0, 4, 9, 9, 2, 6, 1, 5});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[2]}, new int[]{5});

        for (int i = 0;  i < s.length;  i++) {
            System.out.println(Arrays.toString(s[i].steviloKT()));
        }
    }
}
