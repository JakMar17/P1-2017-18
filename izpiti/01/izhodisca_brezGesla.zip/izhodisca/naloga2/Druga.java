
// 
// (na konec prej"snje vrstice zapi"site va"so vpisno "stevilko)

public class Druga {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }

    //=========================================================================
    public static class Predmet {
        private String naziv;
        private int kreditneTocke;
        private boolean strokovni;
        private int dan;

        public Predmet(String naziv, int kreditneTocke, boolean strokovni, int dan) {
            this.naziv = naziv;
            this.kreditneTocke = kreditneTocke;
            this.strokovni = strokovni;
            this.dan = dan;
        }

        // po potrebi dodajte svoje metode ...

        public String vrniNaziv() {
            return this.naziv;
        }

        public boolean jeStrokovni() {
            return this.strokovni;
        }

        public int vrniKreditneTocke() {
            return this.kreditneTocke;
        }
    }

    //=========================================================================
    public static class Student {
        private String ime;
        private Predmet[] predmeti;
        private int[] ocene;

        public Student(String ime, Predmet[] predmeti, int[] ocene) {
            this.ime = ime;
            this.predmeti = predmeti;
            this.ocene = ocene;
        }

        // po potrebi dodajte svoje metode ...

        public String vrniIme() {
            return this.ime;
        }

        public boolean imaProstoIzbirni() {
            // popravite / dopolnite ...
            return false;
        }

        public int[] steviloKT() {
            // popravite / dopolnite ...
            return null;
        }
    }

    //=========================================================================
    public static class Letnik {
        private Student[] studenti;

        public Letnik(Student[] studenti) {
            this.studenti = studenti;
        }

        // po potrebi dodajte svoje metode ...

        public int steviloNeuspesnih() {
            // popravite / dopolnite ...
            return -1;
        }

        public int morebitnaPrekrivanja(int dan) {
            // popravite / dopolnite ...
            return -1;
        }
    }
}
