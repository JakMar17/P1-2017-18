
import java.util.Arrays;

public class Test45 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[22];
        p[0] = new Druga.Predmet("p0", 1, true, 3);
        p[1] = new Druga.Predmet("p1", 11, false, 4);
        p[2] = new Druga.Predmet("p2", 11, true, 4);
        p[3] = new Druga.Predmet("p3", 16, false, 2);
        p[4] = new Druga.Predmet("p4", 14, true, 5);
        p[5] = new Druga.Predmet("p5", 3, true, 5);
        p[6] = new Druga.Predmet("p6", 2, false, 3);
        p[7] = new Druga.Predmet("p7", 7, true, 2);
        p[8] = new Druga.Predmet("p8", 11, false, 5);
        p[9] = new Druga.Predmet("p9", 8, true, 5);
        p[10] = new Druga.Predmet("p10", 13, true, 2);
        p[11] = new Druga.Predmet("p11", 17, true, 2);
        p[12] = new Druga.Predmet("p12", 16, true, 4);
        p[13] = new Druga.Predmet("p13", 15, false, 5);
        p[14] = new Druga.Predmet("p14", 7, false, 1);
        p[15] = new Druga.Predmet("p15", 2, false, 4);
        p[16] = new Druga.Predmet("p16", 7, true, 5);
        p[17] = new Druga.Predmet("p17", 2, false, 3);
        p[18] = new Druga.Predmet("p18", 17, true, 3);
        p[19] = new Druga.Predmet("p19", 10, true, 4);
        p[20] = new Druga.Predmet("p20", 11, true, 2);
        p[21] = new Druga.Predmet("p21", 2, true, 4);

        Druga.Student[] s = new Druga.Student[26];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[6], p[7], p[8], p[10], p[11], p[12], p[13], p[15], p[16], p[17], p[18], p[19], p[20], p[21]}, new int[]{1, 1, 8, 7, 10, 0, 5, 2, 1, 5, 3, 6, 5, 8, 1, 2, 5, 1, 1});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[0], p[5], p[10], p[11], p[12], p[16], p[19], p[21]}, new int[]{3, 4, 3, 7, 4, 3, 5, 10});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[0], p[1], p[4], p[5], p[7], p[8], p[9], p[11], p[13], p[16], p[17], p[19], p[20]}, new int[]{5, 2, 1, 0, 0, 2, 1, 1, 2, 2, 2, 1, 2});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[8], p[9], p[12]}, new int[]{5, 2, 0});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[1], p[14]}, new int[]{3, 2});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[13]}, new int[]{7});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[1], p[2], p[3], p[9], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[19]}, new int[]{8, 7, 0, 2, 8, 6, 10, 2, 9, 2, 4, 1});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[1], p[2], p[4], p[5], p[7], p[8], p[10], p[11], p[12], p[14], p[15], p[17], p[18], p[19], p[20], p[21]}, new int[]{9, 4, 2, 5, 1, 6, 1, 1, 6, 4, 9, 0, 10, 5, 6, 1});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[7], p[11], p[12], p[20]}, new int[]{0, 0, 9, 1});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[0], p[2], p[3], p[5], p[6], p[7], p[8], p[10], p[11], p[12], p[13], p[14], p[15], p[17], p[19], p[20], p[21]}, new int[]{2, 3, 2, 1, 3, 10, 9, 6, 1, 3, 1, 4, 3, 2, 9, 0, 5});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[6], p[8], p[10], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21]}, new int[]{6, 3, 3, 8, 5, 9, 0, 9, 8, 10, 0, 5, 5, 5, 7, 8, 10, 8});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[0], p[2], p[5], p[8], p[10], p[11], p[13], p[14], p[17], p[18], p[20], p[21]}, new int[]{2, 5, 1, 5, 4, 0, 0, 1, 1, 3, 3, 4});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[0], p[5], p[7], p[9], p[10], p[16], p[18], p[19], p[20], p[21]}, new int[]{3, 0, 5, 5, 2, 2, 2, 5, 1, 4});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[10], p[11], p[12], p[13], p[15], p[16], p[17], p[18], p[19], p[20], p[21]}, new int[]{9, 3, 6, 9, 9, 1, 2, 7, 7, 8, 0, 4, 0, 8, 2, 3, 0, 4, 5, 7});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[0], p[2], p[4], p[5], p[7], p[9], p[10], p[11], p[12], p[16], p[18], p[19], p[20], p[21]}, new int[]{5, 4, 4, 2, 3, 1, 2, 5, 3, 2, 1, 2, 2, 3});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[0], p[3], p[5], p[7], p[9], p[10], p[12], p[19]}, new int[]{0, 2, 9, 1, 5, 0, 0, 1});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[0], p[10], p[18]}, new int[]{5, 3, 4});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[2], p[4], p[5], p[7], p[9], p[10], p[11], p[18], p[19], p[20], p[21]}, new int[]{9, 3, 9, 10, 3, 1, 7, 2, 9, 8, 6});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[8], p[9], p[10], p[11], p[14], p[16], p[17], p[18], p[19], p[20]}, new int[]{0, 1, 0, 0, 10, 10, 3, 10, 10, 5, 5, 1, 3, 1, 3, 0, 5});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[11], p[12], p[13], p[15], p[16], p[17], p[18], p[19], p[20], p[21]}, new int[]{0, 1, 3, 2, 4, 1, 4, 0, 5, 4, 4, 4, 2, 0, 0, 4, 3, 5});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[1], p[14], p[16]}, new int[]{10, 10, 6});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21]}, new int[]{4, 3, 9, 8, 4, 1, 9, 10, 10, 8, 2, 6, 6, 4, 4, 3, 6, 8, 9, 0, 10, 9});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[18]}, new int[]{1});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[15], p[16], p[18], p[19], p[20], p[21]}, new int[]{2, 1, 0, 8, 3, 5, 7, 2, 10, 8, 6, 0, 6, 3, 3, 7, 9, 5, 0});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[0], p[2], p[4], p[5], p[7], p[9], p[10], p[11], p[12], p[16], p[18], p[20]}, new int[]{2, 10, 2, 1, 3, 3, 2, 1, 9, 8, 2, 7});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[4], p[5], p[7], p[9], p[18], p[19], p[20]}, new int[]{4, 5, 1, 3, 9, 9, 6});

        Druga.Letnik letnik = new Druga.Letnik(s);
        for (int d = 1;  d <= 5;  d++) {
            System.out.println(letnik.morebitnaPrekrivanja(d));
        }
    }
}
