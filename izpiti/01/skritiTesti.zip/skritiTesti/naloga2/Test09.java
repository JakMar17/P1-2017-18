
import java.util.Arrays;

public class Test09 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[32];
        p[0] = new Druga.Predmet("p0", 17, false, 2);
        p[1] = new Druga.Predmet("p1", 18, true, 2);
        p[2] = new Druga.Predmet("p2", 19, true, 3);
        p[3] = new Druga.Predmet("p3", 14, true, 2);
        p[4] = new Druga.Predmet("p4", 10, true, 2);
        p[5] = new Druga.Predmet("p5", 16, true, 2);
        p[6] = new Druga.Predmet("p6", 12, false, 5);
        p[7] = new Druga.Predmet("p7", 10, true, 4);
        p[8] = new Druga.Predmet("p8", 20, false, 3);
        p[9] = new Druga.Predmet("p9", 15, false, 4);
        p[10] = new Druga.Predmet("p10", 9, true, 3);
        p[11] = new Druga.Predmet("p11", 18, false, 1);
        p[12] = new Druga.Predmet("p12", 17, true, 2);
        p[13] = new Druga.Predmet("p13", 4, true, 3);
        p[14] = new Druga.Predmet("p14", 16, true, 2);
        p[15] = new Druga.Predmet("p15", 20, true, 3);
        p[16] = new Druga.Predmet("p16", 6, false, 2);
        p[17] = new Druga.Predmet("p17", 17, true, 2);
        p[18] = new Druga.Predmet("p18", 12, false, 2);
        p[19] = new Druga.Predmet("p19", 19, false, 5);
        p[20] = new Druga.Predmet("p20", 3, false, 1);
        p[21] = new Druga.Predmet("p21", 18, false, 3);
        p[22] = new Druga.Predmet("p22", 10, false, 4);
        p[23] = new Druga.Predmet("p23", 1, true, 2);
        p[24] = new Druga.Predmet("p24", 18, true, 2);
        p[25] = new Druga.Predmet("p25", 4, true, 3);
        p[26] = new Druga.Predmet("p26", 8, true, 2);
        p[27] = new Druga.Predmet("p27", 8, true, 4);
        p[28] = new Druga.Predmet("p28", 15, true, 3);
        p[29] = new Druga.Predmet("p29", 14, false, 1);
        p[30] = new Druga.Predmet("p30", 10, false, 5);
        p[31] = new Druga.Predmet("p31", 6, false, 2);

        Druga.Student[] s = new Druga.Student[22];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[7], p[13], p[14], p[17], p[24], p[26], p[27]}, new int[]{5, 3, 1, 1, 2, 2, 1, 1, 3, 0, 0});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[1], p[4], p[7], p[10], p[13], p[14], p[15], p[23], p[24], p[27]}, new int[]{5, 0, 9, 6, 2, 5, 7, 10, 0, 7});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[0], p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[14], p[15], p[17], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30]}, new int[]{5, 4, 1, 1, 3, 3, 3, 4, 4, 3, 2, 2, 4, 0, 3, 2, 5, 5, 1, 2, 5, 5, 2, 0, 5, 4, 5});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[4], p[6], p[7], p[10], p[11], p[12], p[16], p[18], p[19], p[22], p[23], p[24], p[25], p[26], p[28], p[29], p[31]}, new int[]{9, 6, 0, 8, 10, 7, 8, 8, 3, 9, 9, 6, 1, 10, 9, 0, 0});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[0], p[4], p[5], p[6], p[7], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[19], p[20], p[24], p[25], p[26], p[30], p[31]}, new int[]{8, 8, 5, 1, 4, 7, 6, 0, 7, 9, 2, 5, 8, 1, 10, 4, 9, 0, 7});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[3], p[16], p[18], p[28]}, new int[]{6, 5, 6, 6});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[1], p[3], p[5], p[6], p[11], p[15], p[17], p[24], p[25], p[31]}, new int[]{0, 9, 9, 5, 4, 8, 0, 6, 6, 8});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[3], p[4], p[5], p[6], p[21]}, new int[]{2, 9, 2, 6, 7});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[4], p[5], p[14], p[24]}, new int[]{3, 1, 6, 3});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[1], p[2], p[5]}, new int[]{2, 3, 4});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[2], p[14], p[16], p[25]}, new int[]{10, 7, 2, 6});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[1], p[5], p[17], p[24], p[27]}, new int[]{8, 3, 3, 5, 10});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[5], p[7], p[10], p[12], p[14], p[15], p[24], p[25], p[26], p[27], p[28]}, new int[]{0, 4, 2, 0, 4, 9, 9, 4, 5, 2, 0, 8, 8, 4, 7});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31]}, new int[]{6, 6, 8, 10, 4, 0, 1, 2, 4, 10, 6, 7, 7, 1, 5, 1, 8, 8, 4, 1, 7, 0, 6, 4, 6, 6, 8, 1, 4, 2, 5});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[0], p[2], p[3], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[15], p[16], p[17], p[19], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31]}, new int[]{0, 0, 3, 4, 3, 5, 3, 0, 0, 1, 5, 4, 4, 3, 4, 1, 3, 4, 5, 1, 2, 0, 3, 0, 0});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[7], p[8], p[9], p[10], p[12], p[13], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[25], p[26], p[27], p[28], p[29], p[30], p[31]}, new int[]{9, 2, 0, 4, 5, 4, 1, 8, 4, 8, 0, 6, 6, 6, 6, 1, 6, 10, 10, 7, 8, 7, 0, 3, 9, 9, 7});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[1], p[3], p[4], p[5], p[13], p[15], p[16], p[18], p[31]}, new int[]{6, 1, 1, 7, 10, 2, 5, 10, 6});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[1], p[4], p[10], p[12], p[21], p[23], p[28]}, new int[]{0, 5, 5, 4, 10, 8, 7});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31]}, new int[]{0, 2, 7, 10, 2, 2, 6, 0, 8, 6, 1, 2, 4, 2, 0, 9, 1, 6, 0, 10, 5, 7, 6, 4, 10, 6, 10, 10, 8, 7});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[1], p[5], p[24]}, new int[]{3, 5, 6});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[3], p[4], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[28], p[29], p[31]}, new int[]{1, 4, 4, 5, 0, 4, 3, 0, 4, 4, 3, 4, 5, 0, 2, 3, 2, 0, 3, 3, 4, 0, 2, 3});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[3], p[4], p[6], p[7], p[9], p[11], p[12], p[13], p[14], p[17], p[18], p[19], p[21], p[22], p[24], p[25], p[26], p[28], p[29], p[30], p[31]}, new int[]{2, 8, 6, 5, 10, 3, 8, 7, 7, 9, 9, 10, 8, 8, 3, 9, 10, 9, 6, 1, 6});

        for (int i = 0;  i < s.length;  i++) {
            System.out.println(s[i].imaProstoIzbirni());
        }
    }
}
