
import java.util.Arrays;

public class Test21 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[10];
        p[0] = new Druga.Predmet("p0", 17, true, 3);
        p[1] = new Druga.Predmet("p1", 7, false, 3);
        p[2] = new Druga.Predmet("p2", 4, true, 1);
        p[3] = new Druga.Predmet("p3", 20, false, 2);
        p[4] = new Druga.Predmet("p4", 20, false, 3);
        p[5] = new Druga.Predmet("p5", 8, true, 1);
        p[6] = new Druga.Predmet("p6", 1, false, 3);
        p[7] = new Druga.Predmet("p7", 13, true, 1);
        p[8] = new Druga.Predmet("p8", 2, true, 3);
        p[9] = new Druga.Predmet("p9", 14, false, 4);

        Druga.Student[] s = new Druga.Student[58];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[0], p[1], p[2], p[5], p[6], p[7], p[8], p[9]}, new int[]{2, 5, 7, 10, 8, 3, 6, 3});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[2], p[3], p[5], p[8]}, new int[]{8, 4, 5, 3});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[4], p[8]}, new int[]{10, 1});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[0], p[1], p[4], p[9]}, new int[]{8, 5, 0, 0});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[3], p[4], p[5], p[7], p[8]}, new int[]{6, 7, 4, 10, 7});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[0], p[7]}, new int[]{2, 5});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[0], p[1], p[5], p[7], p[9]}, new int[]{10, 2, 4, 8, 10});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{4, 1, 3, 4, 1, 0, 4, 3, 0});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[0], p[2], p[5], p[7], p[8]}, new int[]{5, 0, 10, 10, 5});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[0], p[2], p[4], p[6], p[8]}, new int[]{3, 10, 5, 2, 6});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[2]}, new int[]{1});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[0], p[1], p[2], p[4], p[5], p[6], p[8], p[9]}, new int[]{10, 3, 6, 6, 6, 5, 10, 2});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[0], p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{6, 5, 1, 9, 1, 2, 2, 4, 1});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{7, 4, 8, 7, 0, 8, 7, 3, 9, 7});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[0], p[7], p[9]}, new int[]{3, 1, 4});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[0], p[1], p[2], p[7], p[8]}, new int[]{2, 6, 6, 2, 8});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{1, 2, 7, 6, 9, 10, 10, 5, 7});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[0], p[1], p[3], p[5], p[7], p[8]}, new int[]{6, 6, 5, 6, 1, 6});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[7], p[8], p[9]}, new int[]{1, 6, 5, 4, 4, 5, 7});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[2], p[6], p[9]}, new int[]{9, 3, 5});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[2], p[3], p[4], p[7], p[8], p[9]}, new int[]{3, 7, 1, 9, 1, 0});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{9, 0, 2, 5, 9, 1, 5, 7, 7, 0});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[6], p[9]}, new int[]{1, 10, 3, 7, 8, 4});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[4], p[5], p[9]}, new int[]{5, 1, 3});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[2], p[3], p[4], p[9]}, new int[]{9, 5, 10, 0});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[2], p[3], p[6], p[7], p[9]}, new int[]{3, 4, 8, 4, 5});
        s[26] = new Druga.Student("s26", new Druga.Predmet[]{p[1]}, new int[]{4});
        s[27] = new Druga.Student("s27", new Druga.Predmet[]{p[0], p[1], p[5], p[7]}, new int[]{5, 2, 3, 1});
        s[28] = new Druga.Student("s28", new Druga.Predmet[]{p[7]}, new int[]{0});
        s[29] = new Druga.Student("s29", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[8], p[9]}, new int[]{2, 8, 0, 2, 5, 9, 10});
        s[30] = new Druga.Student("s30", new Druga.Predmet[]{p[0], p[5], p[7]}, new int[]{7, 10, 9});
        s[31] = new Druga.Student("s31", new Druga.Predmet[]{p[5]}, new int[]{5});
        s[32] = new Druga.Student("s32", new Druga.Predmet[]{p[0], p[4], p[7], p[9]}, new int[]{1, 9, 3, 7});
        s[33] = new Druga.Student("s33", new Druga.Predmet[]{p[3]}, new int[]{6});
        s[34] = new Druga.Student("s34", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[5], p[6], p[8], p[9]}, new int[]{9, 0, 8, 5, 3, 6, 4, 9});
        s[35] = new Druga.Student("s35", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{9, 4, 5, 9, 10, 1, 4, 8, 2, 9});
        s[36] = new Druga.Student("s36", new Druga.Predmet[]{p[0], p[1], p[3], p[5], p[7]}, new int[]{7, 2, 0, 6, 7});
        s[37] = new Druga.Student("s37", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9]}, new int[]{2, 2, 2, 1, 6, 6, 5, 2, 8, 8});
        s[38] = new Druga.Student("s38", new Druga.Predmet[]{p[1], p[6]}, new int[]{7, 7});
        s[39] = new Druga.Student("s39", new Druga.Predmet[]{p[1], p[2], p[4], p[8]}, new int[]{8, 3, 10, 7});
        s[40] = new Druga.Student("s40", new Druga.Predmet[]{p[2], p[3], p[4], p[5], p[6], p[8]}, new int[]{3, 2, 0, 0, 6, 9});
        s[41] = new Druga.Student("s41", new Druga.Predmet[]{p[0], p[2], p[5], p[7], p[8]}, new int[]{1, 7, 3, 9, 6});
        s[42] = new Druga.Student("s42", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[5], p[7], p[8], p[9]}, new int[]{1, 2, 1, 10, 10, 8, 9, 2});
        s[43] = new Druga.Student("s43", new Druga.Predmet[]{p[7]}, new int[]{3});
        s[44] = new Druga.Student("s44", new Druga.Predmet[]{p[0], p[2], p[8]}, new int[]{6, 1, 3});
        s[45] = new Druga.Student("s45", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[9]}, new int[]{5, 8, 6, 10, 2, 4, 0, 1, 6});
        s[46] = new Druga.Student("s46", new Druga.Predmet[]{p[1], p[6]}, new int[]{4, 1});
        s[47] = new Druga.Student("s47", new Druga.Predmet[]{p[2], p[3], p[5]}, new int[]{1, 1, 5});
        s[48] = new Druga.Student("s48", new Druga.Predmet[]{p[2], p[7]}, new int[]{1, 3});
        s[49] = new Druga.Student("s49", new Druga.Predmet[]{p[0], p[2], p[5]}, new int[]{3, 1, 2});
        s[50] = new Druga.Student("s50", new Druga.Predmet[]{p[2], p[3], p[8]}, new int[]{1, 6, 1});
        s[51] = new Druga.Student("s51", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[7], p[9]}, new int[]{10, 5, 10, 10, 7, 10});
        s[52] = new Druga.Student("s52", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[6], p[7], p[8], p[9]}, new int[]{6, 7, 1, 2, 7, 8, 4, 7});
        s[53] = new Druga.Student("s53", new Druga.Predmet[]{p[0], p[3], p[5], p[6]}, new int[]{3, 1, 8, 9});
        s[54] = new Druga.Student("s54", new Druga.Predmet[]{p[0], p[1], p[2], p[4], p[5], p[6], p[8], p[9]}, new int[]{4, 7, 5, 6, 2, 9, 2, 0});
        s[55] = new Druga.Student("s55", new Druga.Predmet[]{p[1], p[3], p[5], p[9]}, new int[]{4, 8, 8, 6});
        s[56] = new Druga.Student("s56", new Druga.Predmet[]{p[3]}, new int[]{3});
        s[57] = new Druga.Student("s57", new Druga.Predmet[]{p[5], p[6], p[7]}, new int[]{7, 4, 4});

        for (int i = 0;  i < s.length;  i++) {
            System.out.println(Arrays.toString(s[i].steviloKT()));
        }
    }
}
