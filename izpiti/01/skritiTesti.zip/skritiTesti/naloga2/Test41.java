
import java.util.Arrays;

public class Test41 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[47];
        p[0] = new Druga.Predmet("p0", 14, true, 1);
        p[1] = new Druga.Predmet("p1", 10, false, 1);
        p[2] = new Druga.Predmet("p2", 2, true, 1);
        p[3] = new Druga.Predmet("p3", 4, false, 1);
        p[4] = new Druga.Predmet("p4", 4, true, 2);
        p[5] = new Druga.Predmet("p5", 11, false, 4);
        p[6] = new Druga.Predmet("p6", 9, false, 1);
        p[7] = new Druga.Predmet("p7", 3, true, 4);
        p[8] = new Druga.Predmet("p8", 19, false, 2);
        p[9] = new Druga.Predmet("p9", 16, true, 1);
        p[10] = new Druga.Predmet("p10", 7, true, 1);
        p[11] = new Druga.Predmet("p11", 13, false, 2);
        p[12] = new Druga.Predmet("p12", 17, false, 5);
        p[13] = new Druga.Predmet("p13", 2, true, 1);
        p[14] = new Druga.Predmet("p14", 3, true, 4);
        p[15] = new Druga.Predmet("p15", 9, false, 3);
        p[16] = new Druga.Predmet("p16", 12, false, 3);
        p[17] = new Druga.Predmet("p17", 15, true, 5);
        p[18] = new Druga.Predmet("p18", 7, true, 3);
        p[19] = new Druga.Predmet("p19", 20, false, 4);
        p[20] = new Druga.Predmet("p20", 16, false, 2);
        p[21] = new Druga.Predmet("p21", 12, true, 4);
        p[22] = new Druga.Predmet("p22", 19, true, 1);
        p[23] = new Druga.Predmet("p23", 3, false, 1);
        p[24] = new Druga.Predmet("p24", 16, true, 4);
        p[25] = new Druga.Predmet("p25", 16, true, 2);
        p[26] = new Druga.Predmet("p26", 16, false, 5);
        p[27] = new Druga.Predmet("p27", 4, true, 5);
        p[28] = new Druga.Predmet("p28", 9, true, 2);
        p[29] = new Druga.Predmet("p29", 16, true, 4);
        p[30] = new Druga.Predmet("p30", 10, true, 5);
        p[31] = new Druga.Predmet("p31", 5, false, 5);
        p[32] = new Druga.Predmet("p32", 16, true, 1);
        p[33] = new Druga.Predmet("p33", 17, false, 4);
        p[34] = new Druga.Predmet("p34", 20, true, 1);
        p[35] = new Druga.Predmet("p35", 15, true, 4);
        p[36] = new Druga.Predmet("p36", 5, false, 1);
        p[37] = new Druga.Predmet("p37", 9, true, 4);
        p[38] = new Druga.Predmet("p38", 15, false, 5);
        p[39] = new Druga.Predmet("p39", 9, true, 2);
        p[40] = new Druga.Predmet("p40", 18, true, 4);
        p[41] = new Druga.Predmet("p41", 12, false, 1);
        p[42] = new Druga.Predmet("p42", 5, true, 5);
        p[43] = new Druga.Predmet("p43", 11, false, 3);
        p[44] = new Druga.Predmet("p44", 19, false, 5);
        p[45] = new Druga.Predmet("p45", 14, false, 2);
        p[46] = new Druga.Predmet("p46", 6, true, 4);

        Druga.Student[] s = new Druga.Student[32];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[2], p[3], p[8], p[12], p[13], p[14], p[15], p[17], p[18], p[20], p[21], p[24], p[27], p[28], p[32], p[35], p[37], p[38], p[40], p[42], p[44], p[45], p[46]}, new int[]{5, 1, 6, 3, 7, 9, 6, 1, 2, 4, 8, 3, 7, 1, 10, 2, 9, 2, 2, 3, 9, 7, 2});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[0], p[2], p[3], p[5], p[6], p[10], p[11], p[14], p[15], p[16], p[17], p[20], p[21], p[24], p[26], p[27], p[28], p[29], p[31], p[32], p[33], p[34], p[38], p[39], p[40], p[41], p[42], p[46]}, new int[]{4, 5, 0, 3, 3, 6, 6, 2, 10, 0, 8, 1, 3, 9, 10, 3, 1, 1, 2, 1, 8, 4, 3, 3, 3, 5, 6, 0});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[0], p[1], p[3], p[8], p[9], p[10], p[12], p[14], p[15], p[16], p[24], p[25], p[26], p[28], p[30], p[31], p[35], p[38], p[40], p[43], p[44], p[45], p[46]}, new int[]{4, 1, 4, 0, 4, 0, 5, 4, 4, 4, 4, 2, 2, 3, 2, 5, 2, 5, 2, 3, 0, 0, 5});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[2], p[4], p[7], p[9], p[13], p[14], p[17], p[21], p[22], p[24], p[28], p[29], p[32], p[34], p[35], p[40], p[42]}, new int[]{4, 10, 3, 9, 3, 3, 1, 1, 7, 7, 5, 5, 1, 9, 5, 1, 7});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[38], p[39], p[40], p[41], p[42], p[43], p[45], p[46]}, new int[]{10, 2, 5, 10, 3, 9, 2, 3, 4, 2, 8, 0, 5, 6, 8, 10, 8, 7, 7, 6, 0, 7, 8, 9, 7, 5, 0, 7, 7, 3, 3, 9, 7, 5, 0, 6, 4, 10, 5, 9, 7, 10, 7, 1, 8});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[10], p[21], p[28], p[35]}, new int[]{9, 1, 6, 6});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[0], p[2], p[3], p[5], p[7], p[15], p[17], p[18], p[19], p[21], p[22], p[26], p[28], p[36], p[39], p[42], p[45]}, new int[]{3, 1, 3, 3, 3, 3, 4, 3, 1, 2, 0, 1, 4, 5, 1, 2, 0});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[13], p[27], p[35], p[40]}, new int[]{2, 9, 8, 3});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[0], p[1], p[2], p[5], p[6], p[7], p[13], p[14], p[15], p[17], p[19], p[21], p[22], p[23], p[26], p[28], p[31], p[36], p[39], p[46]}, new int[]{2, 3, 1, 2, 1, 3, 4, 0, 3, 3, 5, 1, 2, 0, 5, 2, 2, 3, 5, 3});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[7], p[9], p[10], p[13], p[17], p[21], p[22], p[24], p[25], p[27], p[30], p[32], p[34], p[35], p[39], p[40], p[42]}, new int[]{1, 1, 3, 0, 5, 2, 5, 2, 1, 5, 1, 4, 1, 4, 1, 4, 5});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[8], p[9], p[12], p[14], p[16], p[19], p[21], p[23], p[26], p[28], p[29], p[30], p[32], p[34], p[36], p[37], p[38], p[39], p[41], p[42], p[43], p[44]}, new int[]{6, 8, 10, 10, 3, 3, 6, 7, 10, 5, 5, 10, 3, 7, 2, 7, 1, 6, 6, 10, 0, 6, 1, 2, 8, 7, 9, 5, 8});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[13], p[45]}, new int[]{2, 5});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[1], p[2], p[5], p[7], p[9], p[10], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[23], p[24], p[27], p[28], p[30], p[31], p[32], p[33], p[34], p[36], p[37], p[38], p[39], p[41], p[43], p[44], p[45]}, new int[]{1, 9, 5, 3, 9, 10, 4, 2, 9, 6, 1, 1, 2, 10, 2, 3, 4, 10, 0, 7, 2, 0, 6, 8, 3, 7, 5, 6, 2, 5, 5, 8});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[1], p[3], p[32], p[41], p[46]}, new int[]{4, 0, 3, 0, 6});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[0], p[2], p[7], p[9], p[28], p[32], p[39], p[40]}, new int[]{5, 1, 3, 3, 2, 2, 2, 1});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[5], p[6], p[7], p[8], p[9], p[10], p[12], p[13], p[14], p[15], p[17], p[18], p[19], p[20], p[22], p[23], p[24], p[25], p[26], p[28], p[29], p[31], p[34], p[35], p[36], p[38], p[39], p[41], p[42], p[45], p[46]}, new int[]{10, 2, 0, 4, 1, 2, 0, 6, 4, 5, 2, 8, 2, 8, 10, 7, 9, 5, 1, 3, 9, 5, 5, 0, 7, 8, 1, 0, 7, 4, 3, 1, 0, 0, 1});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[1], p[2], p[4], p[7], p[8], p[16], p[17], p[18], p[19], p[25], p[27], p[28], p[30], p[31], p[34], p[35], p[37], p[39], p[40], p[41], p[42], p[44], p[46]}, new int[]{1, 7, 2, 2, 6, 10, 4, 10, 10, 3, 4, 4, 0, 7, 4, 1, 1, 10, 7, 10, 8, 5, 10});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[0], p[4], p[7], p[10], p[14], p[17], p[18], p[21], p[22], p[24], p[25], p[27], p[28], p[32], p[37], p[40], p[42]}, new int[]{4, 7, 10, 7, 0, 7, 4, 1, 10, 10, 3, 5, 0, 9, 10, 6, 5});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[1], p[6], p[10], p[11], p[13], p[14], p[15], p[16], p[17], p[19], p[20], p[23], p[24], p[30], p[31], p[34], p[37], p[38], p[40], p[41], p[42], p[43], p[45]}, new int[]{4, 2, 0, 7, 8, 4, 9, 9, 8, 8, 8, 8, 8, 9, 7, 1, 2, 4, 2, 10, 10, 10, 4, 9});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[28], p[29], p[30]}, new int[]{4, 5, 7});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[38], p[39], p[40], p[41], p[42], p[43], p[44], p[45], p[46]}, new int[]{0, 3, 1, 7, 2, 9, 1, 1, 8, 0, 7, 4, 10, 6, 4, 4, 3, 4, 1, 6, 6, 4, 5, 8, 7, 3, 2, 1, 4, 3, 10, 1, 2, 7, 10, 9, 8, 0, 4, 0, 6, 7, 10, 4, 1, 2, 3});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[1], p[2], p[5], p[7], p[12], p[13], p[16], p[20], p[23], p[25], p[27], p[28], p[29], p[31], p[33], p[35], p[40], p[41], p[45]}, new int[]{2, 10, 3, 7, 3, 3, 10, 9, 7, 6, 8, 8, 3, 3, 9, 7, 10, 8, 2});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[0], p[2], p[9], p[21], p[24], p[29], p[30], p[37], p[40], p[42]}, new int[]{0, 3, 4, 6, 8, 2, 4, 4, 8, 10});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[1], p[2], p[3], p[5], p[6], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[28], p[30], p[32], p[33], p[34], p[35], p[36], p[39], p[40], p[41], p[43], p[44], p[45], p[46]}, new int[]{4, 4, 0, 3, 2, 4, 0, 5, 5, 2, 0, 5, 3, 5, 4, 2, 5, 4, 2, 2, 4, 0, 2, 2, 1, 0, 4, 0, 0, 2, 4, 3, 4});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[5], p[6], p[7], p[8], p[9], p[10], p[12], p[13], p[15], p[16], p[17], p[18], p[20], p[21], p[23], p[25], p[26], p[27], p[28], p[29], p[30], p[32], p[33], p[34], p[36], p[37], p[38], p[39], p[40], p[41], p[42], p[43], p[46]}, new int[]{3, 5, 2, 5, 4, 5, 2, 4, 4, 2, 5, 0, 4, 2, 3, 4, 3, 4, 1, 5, 0, 3, 1, 1, 0, 2, 5, 5, 0, 4, 1, 0, 1, 5, 0, 0, 1});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[10], p[27], p[30], p[32], p[39]}, new int[]{0, 10, 3, 7, 8});
        s[26] = new Druga.Student("s26", new Druga.Predmet[]{p[4], p[7], p[10], p[13], p[14], p[17], p[18], p[22], p[25], p[27], p[28], p[29], p[30], p[32], p[34], p[35], p[37], p[39], p[40], p[42], p[46]}, new int[]{4, 5, 5, 5, 1, 0, 4, 2, 0, 0, 4, 4, 3, 5, 2, 3, 2, 0, 3, 5, 3});
        s[27] = new Druga.Student("s27", new Druga.Predmet[]{p[13], p[14], p[17], p[21], p[22], p[25], p[27], p[28], p[29], p[40], p[42]}, new int[]{3, 3, 4, 2, 1, 4, 3, 0, 2, 4, 3});
        s[28] = new Druga.Student("s28", new Druga.Predmet[]{p[9], p[13], p[16], p[24], p[25], p[29], p[35], p[39], p[41], p[42], p[46]}, new int[]{2, 5, 0, 4, 2, 2, 3, 1, 5, 4, 5});
        s[29] = new Druga.Student("s29", new Druga.Predmet[]{p[4], p[9], p[14], p[17], p[21], p[32], p[34], p[35]}, new int[]{6, 10, 2, 5, 2, 6, 0, 10});
        s[30] = new Druga.Student("s30", new Druga.Predmet[]{p[0], p[2], p[4], p[9], p[10], p[13], p[14], p[17], p[18], p[21], p[24], p[25], p[27], p[29], p[30], p[32], p[35], p[37], p[39], p[40], p[42], p[46]}, new int[]{2, 5, 1, 4, 4, 1, 3, 0, 1, 2, 1, 1, 3, 3, 0, 5, 4, 2, 1, 1, 3, 2});
        s[31] = new Druga.Student("s31", new Druga.Predmet[]{p[0], p[2], p[4], p[10], p[12], p[13], p[15], p[16], p[18], p[19], p[23], p[25], p[27], p[30], p[31], p[32], p[33], p[34], p[36], p[43], p[46]}, new int[]{5, 3, 1, 4, 2, 3, 2, 4, 1, 4, 1, 0, 0, 0, 3, 4, 0, 1, 3, 1, 5});

        Druga.Letnik letnik = new Druga.Letnik(s);
        for (int d = 1;  d <= 5;  d++) {
            System.out.println(letnik.morebitnaPrekrivanja(d));
        }
    }
}
