
import java.util.Arrays;

public class Test23 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[37];
        p[0] = new Druga.Predmet("p0", 12, false, 5);
        p[1] = new Druga.Predmet("p1", 14, true, 4);
        p[2] = new Druga.Predmet("p2", 12, true, 1);
        p[3] = new Druga.Predmet("p3", 9, false, 1);
        p[4] = new Druga.Predmet("p4", 17, true, 1);
        p[5] = new Druga.Predmet("p5", 8, true, 3);
        p[6] = new Druga.Predmet("p6", 9, true, 2);
        p[7] = new Druga.Predmet("p7", 10, true, 2);
        p[8] = new Druga.Predmet("p8", 1, true, 4);
        p[9] = new Druga.Predmet("p9", 19, true, 1);
        p[10] = new Druga.Predmet("p10", 11, false, 4);
        p[11] = new Druga.Predmet("p11", 1, true, 3);
        p[12] = new Druga.Predmet("p12", 9, false, 3);
        p[13] = new Druga.Predmet("p13", 13, false, 2);
        p[14] = new Druga.Predmet("p14", 15, true, 5);
        p[15] = new Druga.Predmet("p15", 5, false, 3);
        p[16] = new Druga.Predmet("p16", 11, true, 4);
        p[17] = new Druga.Predmet("p17", 19, true, 1);
        p[18] = new Druga.Predmet("p18", 20, true, 1);
        p[19] = new Druga.Predmet("p19", 10, false, 1);
        p[20] = new Druga.Predmet("p20", 8, false, 4);
        p[21] = new Druga.Predmet("p21", 9, false, 5);
        p[22] = new Druga.Predmet("p22", 7, false, 1);
        p[23] = new Druga.Predmet("p23", 19, true, 4);
        p[24] = new Druga.Predmet("p24", 16, true, 5);
        p[25] = new Druga.Predmet("p25", 16, true, 2);
        p[26] = new Druga.Predmet("p26", 15, false, 4);
        p[27] = new Druga.Predmet("p27", 14, false, 2);
        p[28] = new Druga.Predmet("p28", 4, false, 4);
        p[29] = new Druga.Predmet("p29", 3, false, 5);
        p[30] = new Druga.Predmet("p30", 12, true, 3);
        p[31] = new Druga.Predmet("p31", 2, true, 3);
        p[32] = new Druga.Predmet("p32", 18, false, 4);
        p[33] = new Druga.Predmet("p33", 10, true, 1);
        p[34] = new Druga.Predmet("p34", 8, false, 3);
        p[35] = new Druga.Predmet("p35", 8, true, 5);
        p[36] = new Druga.Predmet("p36", 15, false, 4);

        Druga.Student[] s = new Druga.Student[47];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[4], p[6], p[9], p[10], p[11], p[12], p[14], p[15], p[17], p[19], p[20], p[26], p[28], p[29], p[30], p[33], p[34], p[35]}, new int[]{3, 3, 5, 2, 3, 2, 3, 2, 3, 5, 3, 1, 1, 2, 2, 0, 4, 1});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[6], p[7], p[9], p[10], p[11], p[18], p[27], p[28], p[30], p[31], p[36]}, new int[]{0, 6, 9, 5, 9, 8, 0, 3, 2, 1, 2, 2, 3, 9, 0});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[5], p[6], p[7], p[9], p[10], p[11], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[32], p[33], p[34], p[35], p[36]}, new int[]{8, 5, 3, 9, 5, 3, 0, 7, 8, 9, 0, 8, 3, 5, 7, 1, 6, 1, 5, 7, 4, 10, 1, 2, 3, 5, 7, 8, 3, 7, 7, 7, 7});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[1], p[6], p[8], p[11], p[14], p[16], p[17], p[30], p[33], p[35]}, new int[]{4, 7, 5, 9, 7, 2, 10, 8, 1, 0});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[2], p[3], p[4], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[19], p[20], p[22], p[23], p[24], p[25], p[26], p[28], p[29], p[30], p[31], p[32], p[33], p[35], p[36]}, new int[]{8, 5, 8, 4, 0, 2, 3, 5, 9, 9, 5, 5, 7, 5, 9, 7, 10, 4, 10, 7, 1, 2, 6, 1, 3, 4, 4, 5});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[5], p[6], p[8], p[10], p[12], p[24], p[27], p[32]}, new int[]{3, 2, 5, 4, 5, 0, 5, 3});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[23]}, new int[]{10});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[1], p[3], p[4], p[6], p[8], p[9], p[11], p[12], p[14], p[15], p[17], p[21], p[22], p[23], p[24], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35]}, new int[]{5, 5, 6, 5, 7, 9, 2, 7, 5, 2, 1, 6, 5, 3, 8, 9, 2, 0, 6, 4, 4, 4, 8, 2});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[1], p[2], p[3], p[6], p[7], p[8], p[9], p[10], p[12], p[13], p[14], p[17], p[19], p[21], p[23], p[24], p[25], p[26], p[27], p[28], p[30], p[32], p[33], p[35], p[36]}, new int[]{3, 6, 7, 4, 10, 4, 6, 1, 4, 8, 10, 8, 2, 8, 0, 6, 7, 1, 9, 3, 9, 3, 6, 4, 1});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[4], p[7], p[8], p[10], p[11], p[14], p[18], p[23], p[26], p[29], p[31], p[34], p[35]}, new int[]{2, 1, 3, 3, 0, 9, 0, 4, 10, 8, 0, 8, 4});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[2], p[5], p[6], p[7], p[8], p[9], p[11], p[12], p[13], p[14], p[16], p[17], p[19], p[21], p[22], p[25], p[27], p[28], p[29], p[30], p[31], p[32], p[35], p[36]}, new int[]{0, 5, 0, 1, 10, 6, 3, 4, 5, 8, 7, 4, 3, 8, 10, 2, 3, 0, 10, 8, 2, 5, 4, 6});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[4], p[8], p[14], p[18], p[32], p[36]}, new int[]{1, 10, 5, 2, 5, 4});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[20]}, new int[]{4});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[0], p[1], p[3], p[6], p[9], p[10], p[13], p[14], p[18], p[21], p[25], p[26], p[31], p[35]}, new int[]{9, 6, 9, 6, 9, 2, 0, 6, 1, 1, 10, 6, 1, 10});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36]}, new int[]{3, 0, 6, 1, 2, 6, 2, 1, 5, 5, 8, 1, 3, 5, 6, 2, 2, 10, 6, 8, 5, 7, 7, 9, 5, 3, 3, 9, 7, 7, 5, 5, 3, 1, 7, 2, 5});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[1], p[11], p[12], p[34], p[36]}, new int[]{10, 3, 5, 6, 0});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[0], p[2], p[3], p[11], p[19], p[21], p[27], p[33]}, new int[]{5, 0, 0, 2, 5, 0, 2, 4});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[6], p[9], p[10], p[13], p[16], p[22], p[25], p[29], p[33], p[34]}, new int[]{0, 0, 9, 9, 4, 8, 10, 6, 4, 9, 4, 6, 4, 10});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[2], p[5], p[6], p[7], p[8], p[9], p[10], p[12], p[13], p[14], p[15], p[16], p[19], p[21], p[23], p[25], p[29], p[31], p[33], p[34], p[35]}, new int[]{5, 3, 7, 5, 4, 3, 7, 0, 2, 10, 10, 10, 6, 8, 10, 2, 9, 9, 0, 10, 2});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[0], p[2], p[3], p[5], p[8], p[9], p[10], p[11], p[14], p[16], p[18], p[21], p[26], p[31], p[33], p[36]}, new int[]{10, 10, 0, 4, 2, 10, 6, 7, 5, 8, 10, 4, 7, 9, 10, 8});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[1], p[2], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[16], p[17], p[18], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[29], p[30], p[31], p[33], p[34], p[36]}, new int[]{6, 7, 10, 4, 0, 0, 3, 2, 1, 2, 3, 1, 7, 7, 5, 3, 9, 7, 5, 5, 10, 6, 7, 5, 1, 5, 9});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[12], p[13], p[14], p[15], p[18], p[20], p[21], p[23], p[24], p[26], p[29], p[30], p[31], p[32], p[36]}, new int[]{4, 10, 10, 5, 5, 10, 4, 5, 10, 4, 1, 10, 4, 10, 2, 1, 9, 6, 2, 4, 10, 8, 1});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[21], p[23], p[24], p[25], p[26], p[27], p[29], p[31], p[32], p[33], p[34], p[35], p[36]}, new int[]{3, 3, 3, 0, 5, 4, 3, 4, 5, 1, 5, 0, 4, 1, 4, 3, 3, 2, 1, 2, 1, 3, 4, 1, 4, 5, 2, 3, 0, 1, 2});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[1], p[4], p[8], p[10], p[15], p[20], p[24], p[25], p[31]}, new int[]{0, 2, 7, 1, 6, 7, 5, 1, 7});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[21], p[22], p[25], p[26], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35]}, new int[]{0, 8, 5, 6, 3, 3, 10, 5, 7, 9, 9, 3, 7, 6, 7, 10, 8, 1, 1, 0, 4, 7, 2, 8, 0, 7, 2, 7, 5, 4, 5});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[4], p[11], p[14], p[16], p[17], p[35]}, new int[]{0, 0, 9, 6, 6, 6});
        s[26] = new Druga.Student("s26", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[6], p[8], p[9], p[10], p[12], p[13], p[14], p[16], p[17], p[19], p[22], p[23], p[25], p[27], p[29], p[30], p[31], p[35], p[36]}, new int[]{10, 9, 3, 9, 3, 6, 3, 6, 8, 5, 4, 1, 0, 4, 4, 1, 1, 10, 5, 9, 2, 8, 1});
        s[27] = new Druga.Student("s27", new Druga.Predmet[]{p[0], p[1], p[3], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36]}, new int[]{6, 3, 7, 1, 8, 7, 9, 9, 1, 5, 0, 4, 0, 1, 9, 0, 0, 6, 8, 6, 0, 7, 5, 9, 2, 9, 9, 1, 5, 8, 3, 6, 9, 1});
        s[28] = new Druga.Student("s28", new Druga.Predmet[]{p[0], p[4], p[11], p[16], p[17], p[21], p[25], p[34]}, new int[]{2, 2, 6, 8, 1, 10, 8, 1});
        s[29] = new Druga.Student("s29", new Druga.Predmet[]{p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[9], p[11], p[14], p[16], p[17], p[18], p[24], p[25], p[30], p[31], p[33]}, new int[]{3, 1, 0, 4, 0, 1, 2, 5, 0, 2, 4, 3, 0, 2, 0, 2, 5, 1});
        s[30] = new Druga.Student("s30", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36]}, new int[]{0, 8, 5, 3, 10, 10, 9, 8, 2, 0, 4, 0, 3, 9, 1, 0, 10, 3, 4, 9, 4, 2, 1, 3, 0, 4, 10, 7, 3, 5, 9, 3, 4, 2, 4, 2});
        s[31] = new Druga.Student("s31", new Druga.Predmet[]{p[0], p[1], p[3], p[5], p[6], p[7], p[8], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[19], p[20], p[21], p[22], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36]}, new int[]{5, 5, 4, 1, 5, 0, 4, 2, 1, 2, 2, 1, 2, 0, 0, 5, 2, 4, 1, 1, 3, 5, 3, 2, 2, 0, 0, 2, 1, 3, 0});
        s[32] = new Druga.Student("s32", new Druga.Predmet[]{p[3], p[13]}, new int[]{2, 2});
        s[33] = new Druga.Student("s33", new Druga.Predmet[]{p[0], p[1], p[4], p[5], p[6], p[9], p[10], p[11], p[12], p[14], p[15], p[16], p[17], p[19], p[20], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35]}, new int[]{4, 1, 10, 10, 9, 1, 0, 3, 7, 2, 2, 5, 8, 1, 1, 10, 6, 5, 1, 1, 4, 3, 2, 7, 8, 10, 5, 10});
        s[34] = new Druga.Student("s34", new Druga.Predmet[]{p[4], p[11], p[14], p[17], p[21], p[22], p[23], p[29], p[30], p[34]}, new int[]{2, 9, 0, 3, 6, 4, 6, 5, 0, 2});
        s[35] = new Druga.Student("s35", new Druga.Predmet[]{p[1], p[3], p[4], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[19], p[20], p[23], p[24], p[25], p[27], p[29], p[32], p[34], p[35]}, new int[]{10, 2, 5, 1, 7, 9, 1, 10, 2, 5, 10, 10, 1, 3, 5, 9, 10, 4, 9, 5, 1, 7});
        s[36] = new Druga.Student("s36", new Druga.Predmet[]{p[1], p[4], p[5], p[11], p[14], p[18], p[31], p[33]}, new int[]{8, 7, 10, 4, 6, 9, 4, 10});
        s[37] = new Druga.Student("s37", new Druga.Predmet[]{p[17], p[25], p[30], p[35]}, new int[]{7, 10, 10, 6});
        s[38] = new Druga.Student("s38", new Druga.Predmet[]{p[1], p[2], p[5], p[6], p[7], p[8], p[9], p[11], p[16], p[17], p[18], p[24], p[25], p[30], p[31], p[33]}, new int[]{8, 5, 7, 9, 10, 7, 7, 0, 2, 8, 7, 8, 3, 6, 0, 8});
        s[39] = new Druga.Student("s39", new Druga.Predmet[]{p[4], p[5], p[8], p[9], p[11], p[14], p[18], p[35]}, new int[]{1, 3, 6, 2, 5, 0, 7, 0});
        s[40] = new Druga.Student("s40", new Druga.Predmet[]{p[3], p[26]}, new int[]{6, 7});
        s[41] = new Druga.Student("s41", new Druga.Predmet[]{p[1], p[2], p[4], p[5], p[8], p[11], p[14], p[16], p[17], p[23], p[24], p[25], p[30], p[33], p[35]}, new int[]{2, 10, 9, 2, 3, 9, 8, 2, 10, 5, 5, 3, 0, 6, 1});
        s[42] = new Druga.Student("s42", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[7], p[10], p[11], p[12], p[13], p[14], p[15], p[17], p[18], p[19], p[20], p[21], p[22], p[24], p[25], p[26], p[27], p[30], p[31], p[32], p[33], p[34], p[35]}, new int[]{0, 2, 1, 3, 5, 0, 4, 5, 4, 6, 6, 3, 6, 1, 10, 6, 9, 10, 2, 1, 6, 4, 4, 2, 8, 0, 2, 0});
        s[43] = new Druga.Student("s43", new Druga.Predmet[]{p[2], p[3], p[6], p[16], p[17], p[19], p[21], p[23], p[24], p[25], p[33]}, new int[]{7, 1, 9, 6, 6, 8, 7, 9, 0, 0, 7});
        s[44] = new Druga.Student("s44", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36]}, new int[]{7, 6, 6, 3, 10, 10, 4, 10, 3, 7, 10, 7, 2, 3, 8, 4, 10, 5, 6, 8, 9, 4, 10, 4, 8, 3, 3, 10, 9, 4, 0, 2, 5, 5, 6, 2});
        s[45] = new Druga.Student("s45", new Druga.Predmet[]{p[1], p[5], p[8], p[17], p[20], p[33], p[34]}, new int[]{2, 1, 8, 2, 9, 3, 8});
        s[46] = new Druga.Student("s46", new Druga.Predmet[]{p[0], p[1], p[4], p[5], p[6], p[7], p[8], p[9], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[22], p[24], p[25], p[26], p[29], p[30], p[32], p[33], p[34]}, new int[]{4, 10, 0, 3, 1, 9, 10, 2, 4, 7, 2, 8, 4, 1, 0, 2, 7, 0, 3, 2, 4, 6, 4, 6, 9});

        for (int i = 0;  i < s.length;  i++) {
            System.out.println(Arrays.toString(s[i].steviloKT()));
        }
    }
}
