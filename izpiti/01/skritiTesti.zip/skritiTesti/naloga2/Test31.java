
import java.util.Arrays;

public class Test31 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[39];
        p[0] = new Druga.Predmet("p0", 19, true, 4);
        p[1] = new Druga.Predmet("p1", 18, true, 3);
        p[2] = new Druga.Predmet("p2", 17, true, 5);
        p[3] = new Druga.Predmet("p3", 5, true, 5);
        p[4] = new Druga.Predmet("p4", 15, true, 2);
        p[5] = new Druga.Predmet("p5", 20, false, 3);
        p[6] = new Druga.Predmet("p6", 1, false, 4);
        p[7] = new Druga.Predmet("p7", 10, true, 1);
        p[8] = new Druga.Predmet("p8", 17, false, 5);
        p[9] = new Druga.Predmet("p9", 13, false, 5);
        p[10] = new Druga.Predmet("p10", 10, true, 4);
        p[11] = new Druga.Predmet("p11", 8, true, 4);
        p[12] = new Druga.Predmet("p12", 9, false, 2);
        p[13] = new Druga.Predmet("p13", 1, false, 1);
        p[14] = new Druga.Predmet("p14", 20, true, 4);
        p[15] = new Druga.Predmet("p15", 8, false, 1);
        p[16] = new Druga.Predmet("p16", 13, false, 4);
        p[17] = new Druga.Predmet("p17", 13, true, 5);
        p[18] = new Druga.Predmet("p18", 15, false, 3);
        p[19] = new Druga.Predmet("p19", 7, false, 4);
        p[20] = new Druga.Predmet("p20", 5, false, 3);
        p[21] = new Druga.Predmet("p21", 11, false, 2);
        p[22] = new Druga.Predmet("p22", 6, false, 4);
        p[23] = new Druga.Predmet("p23", 12, false, 5);
        p[24] = new Druga.Predmet("p24", 2, true, 5);
        p[25] = new Druga.Predmet("p25", 11, true, 3);
        p[26] = new Druga.Predmet("p26", 2, true, 5);
        p[27] = new Druga.Predmet("p27", 18, false, 3);
        p[28] = new Druga.Predmet("p28", 7, true, 4);
        p[29] = new Druga.Predmet("p29", 3, true, 3);
        p[30] = new Druga.Predmet("p30", 20, false, 1);
        p[31] = new Druga.Predmet("p31", 2, true, 4);
        p[32] = new Druga.Predmet("p32", 8, false, 5);
        p[33] = new Druga.Predmet("p33", 19, false, 5);
        p[34] = new Druga.Predmet("p34", 11, true, 3);
        p[35] = new Druga.Predmet("p35", 17, true, 3);
        p[36] = new Druga.Predmet("p36", 18, false, 5);
        p[37] = new Druga.Predmet("p37", 16, true, 1);
        p[38] = new Druga.Predmet("p38", 9, false, 5);

        Druga.Student[] s = new Druga.Student[34];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[11], p[25]}, new int[]{4, 1});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[2], p[37]}, new int[]{3, 8});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[0], p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[10], p[11], p[12], p[14], p[15], p[16], p[18], p[19], p[20], p[22], p[23], p[25], p[26], p[30], p[32], p[33], p[34], p[35], p[36], p[38]}, new int[]{0, 0, 0, 2, 3, 2, 2, 2, 2, 2, 2, 1, 1, 4, 5, 3, 5, 5, 4, 0, 5, 3, 3, 2, 4, 0, 3, 0});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[1], p[3], p[5], p[7], p[11], p[15], p[20], p[37], p[38]}, new int[]{10, 4, 2, 9, 2, 10, 4, 4, 10});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[1], p[2], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[17], p[19], p[20], p[22], p[25], p[27], p[28], p[30], p[31], p[33], p[35], p[37], p[38]}, new int[]{9, 9, 8, 6, 5, 3, 2, 5, 10, 4, 10, 9, 7, 8, 1, 5, 5, 9, 7, 10, 4, 8, 4, 10, 6});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[5], p[9], p[10], p[11], p[13], p[14], p[16], p[17], p[18], p[19], p[20], p[23], p[25], p[26], p[29], p[30], p[31], p[34], p[35], p[36], p[38]}, new int[]{1, 5, 8, 0, 8, 7, 8, 7, 10, 9, 0, 3, 8, 6, 10, 5, 5, 10, 1, 1, 5, 9, 7, 10, 0});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[1], p[9], p[10], p[12], p[22], p[35]}, new int[]{10, 4, 0, 2, 3, 7});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[1], p[2], p[11], p[12], p[13], p[15], p[26], p[31], p[34], p[36]}, new int[]{3, 9, 2, 3, 10, 6, 1, 0, 3, 3});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[5], p[6], p[9], p[11], p[13], p[14], p[16], p[19], p[20], p[21], p[23], p[25], p[27], p[29], p[30], p[31], p[32], p[34], p[37], p[38]}, new int[]{0, 7, 10, 4, 4, 2, 7, 0, 2, 9, 5, 7, 3, 9, 10, 8, 7, 7, 8, 6, 4, 7, 5, 1});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[0], p[8], p[10], p[11], p[17], p[18], p[25], p[30], p[34], p[36]}, new int[]{9, 4, 10, 9, 3, 8, 0, 2, 5, 7});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[38]}, new int[]{6, 9, 2, 5, 6, 1, 10, 3, 7, 10, 6, 9, 10, 10, 10, 8, 6, 6, 4, 5, 1, 2, 9, 8, 1, 4, 10, 5, 0, 7, 5, 8, 1, 1, 9, 3, 7});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[0], p[1], p[3], p[6], p[7], p[8], p[11], p[14], p[15], p[16], p[17], p[19], p[21], p[23], p[26], p[29], p[30], p[31], p[33], p[34], p[35]}, new int[]{2, 6, 0, 3, 0, 7, 2, 6, 3, 0, 4, 3, 4, 7, 5, 8, 2, 4, 1, 1, 7});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[10]}, new int[]{2});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[1], p[17], p[20], p[29]}, new int[]{10, 4, 6, 4});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[2], p[3], p[4], p[7], p[10], p[11], p[14], p[17], p[25], p[26], p[28], p[29], p[31], p[35], p[37]}, new int[]{8, 8, 0, 8, 4, 1, 5, 2, 3, 0, 7, 7, 5, 4, 2});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[6], p[8], p[9], p[11], p[13], p[14], p[15], p[17], p[20], p[21], p[22], p[24], p[25], p[26], p[27], p[29], p[35], p[38]}, new int[]{4, 5, 1, 9, 2, 5, 4, 0, 8, 7, 5, 0, 8, 10, 9, 10, 8, 9, 8, 5, 2, 5, 0});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[0], p[4], p[7], p[11], p[17], p[26]}, new int[]{3, 1, 5, 0, 10, 5});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[1], p[10], p[12], p[15], p[17], p[18], p[19], p[20], p[21], p[22], p[24], p[29], p[31], p[32]}, new int[]{4, 7, 6, 5, 5, 2, 1, 3, 6, 8, 9, 5, 9, 0});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[33], p[34], p[35], p[37], p[38]}, new int[]{1, 6, 10, 10, 5, 5, 10, 10, 5, 5, 3, 6, 7, 7, 6, 9, 10, 10, 9, 10, 4, 3, 1, 3, 9, 2, 10, 5, 8, 5, 7, 10, 3, 7, 5});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[0], p[1], p[2], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[18], p[19], p[20], p[21], p[23], p[24], p[25], p[26], p[27], p[29], p[30], p[32], p[34], p[35], p[36], p[38]}, new int[]{3, 3, 5, 1, 5, 2, 0, 0, 0, 4, 5, 2, 3, 0, 3, 4, 4, 5, 0, 5, 1, 5, 3, 4, 0, 2, 5, 1, 4, 5});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[7], p[9], p[12], p[14], p[18], p[24], p[26], p[29], p[30], p[35], p[36]}, new int[]{0, 3, 0, 2, 2, 2, 4, 3, 5, 1, 4, 4, 5, 0, 3});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[19], p[20], p[21], p[22], p[23], p[25], p[26], p[27], p[28], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[38]}, new int[]{2, 7, 9, 1, 1, 3, 6, 7, 3, 1, 0, 7, 0, 5, 7, 3, 3, 1, 9, 7, 7, 5, 3, 10, 0, 3, 4, 3, 2, 9, 0, 7, 5, 7, 10, 2});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[1], p[2], p[4], p[7], p[10], p[11], p[14], p[17], p[24], p[25], p[26], p[28], p[29], p[34], p[35], p[37]}, new int[]{9, 9, 5, 5, 3, 9, 4, 9, 7, 4, 0, 6, 4, 2, 7, 3});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[0], p[2], p[4], p[6], p[7], p[9], p[10], p[12], p[13], p[14], p[15], p[16], p[18], p[19], p[20], p[21], p[26], p[28], p[29], p[31], p[33], p[34], p[36], p[38]}, new int[]{7, 4, 6, 3, 2, 0, 7, 6, 2, 9, 9, 10, 5, 5, 5, 4, 4, 10, 10, 4, 1, 0, 7, 0});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[3], p[5], p[6], p[7], p[8], p[9], p[11], p[13], p[14], p[16], p[19], p[22], p[23], p[25], p[26], p[31], p[33], p[34], p[35], p[36], p[37], p[38]}, new int[]{2, 5, 0, 4, 6, 7, 3, 10, 1, 8, 6, 2, 10, 1, 10, 7, 10, 10, 1, 2, 8, 8});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[0], p[2], p[4], p[6], p[8], p[10], p[12], p[13], p[14], p[15], p[16], p[18], p[21], p[22], p[23], p[26], p[27], p[29], p[32], p[35], p[36], p[37], p[38]}, new int[]{4, 0, 5, 2, 6, 5, 1, 7, 1, 7, 0, 1, 7, 0, 9, 4, 2, 4, 3, 8, 3, 7, 4});
        s[26] = new Druga.Student("s26", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[38]}, new int[]{2, 1, 1, 2, 3, 7, 4, 7, 3, 7, 5, 6, 6, 6, 2, 9, 0, 7, 7, 0, 3, 9, 10, 1, 10, 0, 0, 1, 0, 2, 10, 2, 5, 4, 7, 7, 3});
        s[27] = new Druga.Student("s27", new Druga.Predmet[]{p[21], p[31], p[38]}, new int[]{9, 0, 4});
        s[28] = new Druga.Student("s28", new Druga.Predmet[]{p[1], p[4], p[7], p[8], p[9], p[10], p[16], p[17], p[18], p[19], p[25], p[26], p[27], p[29], p[30], p[32], p[33], p[34], p[35], p[36]}, new int[]{4, 4, 1, 4, 2, 1, 0, 0, 5, 0, 4, 2, 0, 2, 4, 1, 5, 3, 4, 2});
        s[29] = new Druga.Student("s29", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[5], p[6], p[8], p[9], p[10], p[11], p[13], p[14], p[15], p[18], p[19], p[20], p[21], p[23], p[25], p[26], p[27], p[29], p[30], p[31], p[32], p[33], p[35], p[36], p[37], p[38]}, new int[]{2, 7, 0, 10, 0, 0, 5, 6, 2, 8, 4, 9, 5, 10, 1, 4, 0, 4, 1, 1, 4, 3, 8, 8, 5, 2, 4, 9, 0, 0});
        s[30] = new Druga.Student("s30", new Druga.Predmet[]{p[0], p[1], p[2], p[16], p[37]}, new int[]{3, 0, 7, 0, 3});
        s[31] = new Druga.Student("s31", new Druga.Predmet[]{p[4], p[8], p[10], p[17], p[20], p[21], p[22], p[24], p[25], p[30], p[31], p[33], p[35], p[37]}, new int[]{5, 5, 6, 4, 3, 2, 5, 5, 10, 5, 1, 8, 2, 1});
        s[32] = new Druga.Student("s32", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[18], p[19], p[20], p[21], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[37], p[38]}, new int[]{4, 6, 7, 1, 3, 2, 3, 0, 8, 7, 0, 6, 8, 6, 1, 3, 7, 0, 5, 1, 8, 3, 10, 6, 1, 9, 0, 7, 6, 0, 7, 3});
        s[33] = new Druga.Student("s33", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[6], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[16], p[17], p[19], p[23], p[24], p[25], p[28], p[29], p[30], p[31], p[32], p[33], p[35], p[36], p[37]}, new int[]{8, 4, 6, 0, 1, 0, 9, 4, 5, 10, 4, 0, 4, 9, 8, 4, 4, 3, 5, 2, 6, 3, 7, 10, 6, 9, 2, 0});

        Druga.Letnik letnik = new Druga.Letnik(s);
        System.out.println(letnik.steviloNeuspesnih());
    }
}
