
import java.util.Arrays;

public class Test43 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[41];
        p[0] = new Druga.Predmet("p0", 14, true, 1);
        p[1] = new Druga.Predmet("p1", 20, false, 2);
        p[2] = new Druga.Predmet("p2", 11, true, 5);
        p[3] = new Druga.Predmet("p3", 4, false, 4);
        p[4] = new Druga.Predmet("p4", 7, true, 1);
        p[5] = new Druga.Predmet("p5", 20, true, 1);
        p[6] = new Druga.Predmet("p6", 1, true, 2);
        p[7] = new Druga.Predmet("p7", 2, false, 3);
        p[8] = new Druga.Predmet("p8", 16, false, 2);
        p[9] = new Druga.Predmet("p9", 15, true, 3);
        p[10] = new Druga.Predmet("p10", 2, true, 5);
        p[11] = new Druga.Predmet("p11", 4, false, 5);
        p[12] = new Druga.Predmet("p12", 12, false, 4);
        p[13] = new Druga.Predmet("p13", 15, true, 3);
        p[14] = new Druga.Predmet("p14", 14, true, 4);
        p[15] = new Druga.Predmet("p15", 8, false, 1);
        p[16] = new Druga.Predmet("p16", 8, true, 5);
        p[17] = new Druga.Predmet("p17", 15, false, 2);
        p[18] = new Druga.Predmet("p18", 15, true, 4);
        p[19] = new Druga.Predmet("p19", 14, true, 5);
        p[20] = new Druga.Predmet("p20", 13, true, 3);
        p[21] = new Druga.Predmet("p21", 17, false, 4);
        p[22] = new Druga.Predmet("p22", 17, true, 3);
        p[23] = new Druga.Predmet("p23", 2, true, 2);
        p[24] = new Druga.Predmet("p24", 2, true, 2);
        p[25] = new Druga.Predmet("p25", 2, true, 4);
        p[26] = new Druga.Predmet("p26", 10, false, 2);
        p[27] = new Druga.Predmet("p27", 7, false, 2);
        p[28] = new Druga.Predmet("p28", 18, true, 2);
        p[29] = new Druga.Predmet("p29", 3, false, 4);
        p[30] = new Druga.Predmet("p30", 15, false, 1);
        p[31] = new Druga.Predmet("p31", 20, true, 1);
        p[32] = new Druga.Predmet("p32", 19, true, 5);
        p[33] = new Druga.Predmet("p33", 3, false, 3);
        p[34] = new Druga.Predmet("p34", 8, true, 1);
        p[35] = new Druga.Predmet("p35", 7, false, 3);
        p[36] = new Druga.Predmet("p36", 2, true, 1);
        p[37] = new Druga.Predmet("p37", 19, true, 1);
        p[38] = new Druga.Predmet("p38", 13, false, 3);
        p[39] = new Druga.Predmet("p39", 12, false, 2);
        p[40] = new Druga.Predmet("p40", 4, true, 4);

        Druga.Student[] s = new Druga.Student[31];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[2], p[9], p[14], p[18], p[19], p[22], p[23], p[32], p[37]}, new int[]{5, 1, 1, 1, 5, 9, 7, 1, 3});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[0], p[3], p[4], p[5], p[6], p[8], p[11], p[12], p[17], p[18], p[21], p[22], p[23], p[24], p[27], p[29], p[31], p[32], p[36], p[37], p[39], p[40]}, new int[]{7, 5, 0, 9, 3, 10, 2, 4, 8, 3, 0, 6, 5, 2, 0, 0, 1, 8, 9, 10, 5, 3});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[5], p[7], p[9], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[31], p[32], p[33], p[34], p[35], p[36], p[38], p[40]}, new int[]{8, 10, 4, 2, 5, 7, 0, 7, 5, 3, 3, 8, 2, 7, 2, 1, 4, 10, 3, 1, 5, 1, 0, 8, 5, 10, 7, 7, 1});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[3], p[5], p[22], p[23], p[27], p[34], p[38], p[39], p[40]}, new int[]{3, 0, 3, 3, 2, 2, 2, 5, 4});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[1], p[2], p[3], p[4], p[5], p[6], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[17], p[19], p[20], p[21], p[22], p[23], p[26], p[27], p[28], p[29], p[30], p[31], p[33], p[34], p[35], p[36], p[38], p[39], p[40]}, new int[]{8, 4, 4, 6, 6, 8, 6, 1, 3, 1, 1, 5, 0, 3, 9, 4, 9, 5, 10, 4, 3, 9, 4, 9, 7, 0, 3, 2, 9, 2, 3, 3});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[0], p[10], p[20], p[24], p[29], p[30], p[31], p[39]}, new int[]{1, 3, 1, 8, 9, 9, 4, 10});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[1], p[4], p[8], p[9], p[12], p[13], p[14], p[18], p[27], p[31], p[39]}, new int[]{4, 4, 1, 4, 1, 7, 3, 8, 1, 0, 1});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[0], p[2], p[5], p[6], p[9], p[10], p[13], p[14], p[16], p[18], p[19], p[20], p[22], p[23], p[24], p[25], p[28], p[31], p[32], p[34], p[36], p[37], p[40]}, new int[]{5, 2, 6, 4, 10, 2, 0, 5, 10, 3, 6, 1, 4, 5, 8, 4, 1, 10, 5, 9, 5, 6, 2});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[0], p[1], p[3], p[5], p[7], p[8], p[9], p[10], p[12], p[13], p[14], p[16], p[17], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[37], p[38], p[39], p[40]}, new int[]{2, 3, 0, 6, 8, 1, 10, 4, 3, 3, 0, 5, 6, 10, 0, 9, 10, 8, 0, 0, 8, 4, 6, 7, 8, 6, 9, 7, 3, 8, 0, 3, 6, 3});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[5], p[6], p[23]}, new int[]{9, 9, 8});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[14], p[15], p[30], p[33]}, new int[]{8, 1, 1, 2});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[38], p[39], p[40]}, new int[]{6, 7, 10, 9, 4, 1, 2, 4, 4, 9, 4, 0, 7, 0, 9, 10, 6, 5, 7, 6, 2, 4, 3, 0, 8, 5, 8, 8, 5, 0, 9, 9, 2, 1, 6, 0, 7, 9, 6, 9, 1});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[5], p[6], p[9], p[24], p[32], p[34]}, new int[]{9, 6, 2, 2, 3, 7});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[0], p[1], p[3], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[14], p[15], p[16], p[19], p[20], p[21], p[22], p[23], p[25], p[26], p[28], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[39]}, new int[]{7, 10, 10, 2, 5, 8, 3, 6, 3, 0, 9, 2, 7, 5, 5, 8, 4, 5, 7, 4, 5, 0, 8, 4, 5, 7, 10, 8, 2, 4});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[2], p[4], p[6], p[10], p[13], p[14], p[18], p[19], p[20], p[23], p[24], p[25], p[31], p[32], p[34], p[37], p[40]}, new int[]{10, 8, 5, 7, 7, 9, 8, 4, 0, 3, 8, 8, 5, 3, 1, 4, 1});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[5], p[22], p[24], p[34], p[36], p[40]}, new int[]{5, 9, 7, 7, 7, 9});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[9], p[11], p[12], p[13], p[14], p[17], p[18], p[19], p[20], p[22], p[25], p[26], p[27], p[28], p[30], p[31], p[33], p[34], p[35], p[37], p[38], p[39], p[40]}, new int[]{4, 3, 0, 9, 4, 10, 6, 3, 0, 10, 4, 3, 0, 6, 0, 6, 2, 4, 8, 6, 10, 3, 6, 9, 4, 7, 4, 2, 0, 1, 5});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[5], p[8], p[11], p[17], p[19], p[20], p[22], p[25], p[26], p[28], p[29], p[30], p[31], p[35]}, new int[]{10, 0, 9, 9, 10, 1, 3, 5, 7, 3, 9, 10, 8, 10});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[7], p[8], p[10], p[13], p[18], p[21], p[22], p[27], p[37], p[38], p[40]}, new int[]{5, 0, 1, 3, 5, 0, 0, 3, 0, 3, 2});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[13], p[15], p[16], p[17], p[19], p[20], p[21], p[22], p[25], p[28], p[29], p[31], p[34], p[36]}, new int[]{2, 10, 2, 10, 6, 9, 9, 3, 10, 5, 8, 5, 1, 7, 5, 1, 0, 10, 5, 3, 9, 4});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[12], p[13], p[18], p[22], p[24], p[31]}, new int[]{5, 5, 0, 3, 9, 10});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[9], p[28], p[36]}, new int[]{2, 3, 6});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[6], p[7], p[8], p[9], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[21], p[23], p[24], p[27], p[29], p[30], p[31], p[32], p[35], p[36], p[37], p[38], p[40]}, new int[]{10, 2, 9, 4, 0, 2, 4, 3, 4, 5, 8, 8, 9, 0, 0, 9, 2, 1, 7, 1, 9, 9, 5, 4, 6, 10, 3, 2, 8, 1, 8});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[6], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[18], p[19], p[20], p[21], p[23], p[25], p[26], p[27], p[28], p[29], p[30], p[34], p[35], p[36], p[37], p[38], p[39], p[40]}, new int[]{10, 6, 3, 10, 2, 1, 10, 9, 0, 4, 3, 1, 0, 1, 3, 2, 8, 1, 3, 0, 9, 4, 5, 4, 7, 6, 9, 5, 0, 3, 0, 1});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[31], p[32], p[33], p[34], p[35], p[36], p[37], p[38], p[39], p[40]}, new int[]{4, 5, 1, 5, 1, 3, 2, 1, 2, 2, 2, 4, 5, 4, 3, 4, 3, 2, 3, 0, 3, 2, 1, 3, 5, 1, 4, 2, 2, 4, 4, 2, 0, 5, 4, 5, 4, 3, 2, 5, 5});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[0], p[6], p[9], p[12], p[14], p[16], p[19], p[21], p[22], p[24], p[25], p[26], p[30], p[31], p[32], p[33], p[34], p[35], p[39]}, new int[]{0, 6, 6, 5, 4, 6, 2, 8, 4, 8, 9, 5, 6, 0, 4, 10, 3, 9, 1});
        s[26] = new Druga.Student("s26", new Druga.Predmet[]{p[2], p[3], p[7], p[9], p[11], p[16], p[17], p[18], p[20], p[23], p[25], p[26], p[28], p[29], p[30], p[31], p[34], p[35], p[39]}, new int[]{2, 3, 4, 3, 2, 4, 0, 7, 9, 5, 3, 0, 9, 10, 7, 5, 1, 3, 0});
        s[27] = new Druga.Student("s27", new Druga.Predmet[]{p[0], p[19], p[20], p[25], p[31]}, new int[]{5, 7, 10, 7, 2});
        s[28] = new Druga.Student("s28", new Druga.Predmet[]{p[0], p[4], p[5], p[10], p[13], p[19], p[23], p[25], p[34], p[36], p[37], p[40]}, new int[]{8, 0, 2, 9, 2, 0, 3, 5, 1, 7, 6, 9});
        s[29] = new Druga.Student("s29", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[20], p[21], p[22], p[23], p[24], p[25], p[26], p[27], p[28], p[29], p[30], p[32], p[33], p[34], p[35], p[36], p[38], p[39], p[40]}, new int[]{9, 2, 10, 0, 0, 10, 6, 5, 10, 3, 10, 1, 5, 5, 8, 7, 1, 4, 0, 5, 7, 5, 10, 9, 6, 10, 3, 5, 3, 7, 5, 9, 3, 8, 2, 9, 8});
        s[30] = new Druga.Student("s30", new Druga.Predmet[]{p[0], p[2], p[7], p[9], p[10], p[11], p[15], p[16], p[19], p[21], p[22], p[26], p[27], p[35], p[37], p[40]}, new int[]{9, 10, 7, 10, 9, 4, 8, 6, 6, 8, 4, 10, 5, 1, 2, 8});

        Druga.Letnik letnik = new Druga.Letnik(s);
        for (int d = 1;  d <= 5;  d++) {
            System.out.println(letnik.morebitnaPrekrivanja(d));
        }
    }
}
