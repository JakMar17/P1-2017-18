
import java.util.Arrays;

public class Test46 {

    public static void main(String[] args) {
        Druga.Predmet[] p = new Druga.Predmet[25];
        p[0] = new Druga.Predmet("p0", 8, true, 2);
        p[1] = new Druga.Predmet("p1", 13, false, 4);
        p[2] = new Druga.Predmet("p2", 8, false, 2);
        p[3] = new Druga.Predmet("p3", 14, true, 3);
        p[4] = new Druga.Predmet("p4", 6, false, 1);
        p[5] = new Druga.Predmet("p5", 9, true, 3);
        p[6] = new Druga.Predmet("p6", 8, false, 2);
        p[7] = new Druga.Predmet("p7", 2, true, 5);
        p[8] = new Druga.Predmet("p8", 14, true, 1);
        p[9] = new Druga.Predmet("p9", 16, true, 3);
        p[10] = new Druga.Predmet("p10", 13, true, 2);
        p[11] = new Druga.Predmet("p11", 4, true, 1);
        p[12] = new Druga.Predmet("p12", 8, false, 1);
        p[13] = new Druga.Predmet("p13", 16, false, 3);
        p[14] = new Druga.Predmet("p14", 1, false, 2);
        p[15] = new Druga.Predmet("p15", 1, false, 5);
        p[16] = new Druga.Predmet("p16", 20, true, 4);
        p[17] = new Druga.Predmet("p17", 16, false, 3);
        p[18] = new Druga.Predmet("p18", 18, true, 1);
        p[19] = new Druga.Predmet("p19", 10, true, 3);
        p[20] = new Druga.Predmet("p20", 7, true, 4);
        p[21] = new Druga.Predmet("p21", 13, false, 1);
        p[22] = new Druga.Predmet("p22", 14, true, 1);
        p[23] = new Druga.Predmet("p23", 16, true, 2);
        p[24] = new Druga.Predmet("p24", 4, false, 2);

        Druga.Student[] s = new Druga.Student[39];
        s[0] = new Druga.Student("s0", new Druga.Predmet[]{p[0], p[2], p[3], p[5], p[6], p[7], p[9], p[11], p[13], p[14], p[15], p[16], p[17], p[18], p[23]}, new int[]{5, 0, 6, 3, 2, 8, 8, 3, 8, 5, 0, 9, 1, 2, 8});
        s[1] = new Druga.Student("s1", new Druga.Predmet[]{p[0], p[6], p[8], p[11], p[13], p[16], p[17], p[19], p[21], p[22], p[24]}, new int[]{1, 4, 2, 3, 1, 3, 0, 1, 1, 2, 4});
        s[2] = new Druga.Student("s2", new Druga.Predmet[]{p[3], p[10], p[11], p[13], p[14], p[15], p[24]}, new int[]{1, 2, 2, 5, 4, 4, 3});
        s[3] = new Druga.Student("s3", new Druga.Predmet[]{p[3], p[7], p[23], p[24]}, new int[]{8, 6, 0, 10});
        s[4] = new Druga.Student("s4", new Druga.Predmet[]{p[1], p[2], p[4], p[5], p[7], p[8], p[10], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21]}, new int[]{10, 8, 7, 10, 7, 1, 5, 8, 8, 8, 0, 7, 1, 6, 2, 7, 8});
        s[5] = new Druga.Student("s5", new Druga.Predmet[]{p[1], p[4], p[5], p[6], p[7], p[10], p[11], p[14], p[18], p[20], p[21]}, new int[]{2, 1, 2, 4, 3, 2, 1, 2, 1, 4, 2});
        s[6] = new Druga.Student("s6", new Druga.Predmet[]{p[4], p[11], p[12], p[13], p[19], p[20], p[21]}, new int[]{3, 3, 2, 4, 3, 4, 4});
        s[7] = new Druga.Student("s7", new Druga.Predmet[]{p[0], p[1], p[2], p[5], p[6], p[7], p[8], p[10], p[11], p[12], p[13], p[14], p[19], p[20], p[22]}, new int[]{6, 6, 8, 7, 10, 9, 10, 3, 6, 1, 0, 9, 4, 6, 4});
        s[8] = new Druga.Student("s8", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[6], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[17], p[19], p[20], p[21], p[23], p[24]}, new int[]{2, 4, 1, 4, 7, 5, 4, 1, 2, 3, 10, 8, 1, 10, 8, 5, 2, 4});
        s[9] = new Druga.Student("s9", new Druga.Predmet[]{p[10]}, new int[]{8});
        s[10] = new Druga.Student("s10", new Druga.Predmet[]{p[0], p[2], p[3], p[4], p[5], p[6], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[21], p[23], p[24]}, new int[]{1, 7, 10, 6, 3, 2, 10, 8, 2, 7, 3, 5, 10, 7, 10, 7, 2, 7, 4});
        s[11] = new Druga.Student("s11", new Druga.Predmet[]{p[0], p[4], p[9], p[10], p[12], p[18], p[19], p[23], p[24]}, new int[]{6, 2, 10, 3, 9, 4, 1, 7, 1});
        s[12] = new Druga.Student("s12", new Druga.Predmet[]{p[10]}, new int[]{6});
        s[13] = new Druga.Student("s13", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[6], p[7], p[8], p[9], p[10], p[12], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[22], p[23], p[24]}, new int[]{2, 6, 0, 8, 9, 7, 10, 8, 1, 3, 9, 3, 6, 10, 0, 6, 3, 1, 7, 10, 9});
        s[14] = new Druga.Student("s14", new Druga.Predmet[]{p[4], p[11]}, new int[]{2, 5});
        s[15] = new Druga.Student("s15", new Druga.Predmet[]{p[18], p[20], p[24]}, new int[]{9, 0, 2});
        s[16] = new Druga.Student("s16", new Druga.Predmet[]{p[0], p[3], p[5], p[7], p[8], p[9], p[11], p[16], p[18], p[19], p[20], p[23]}, new int[]{0, 0, 6, 8, 10, 0, 0, 2, 6, 0, 9, 10});
        s[17] = new Druga.Student("s17", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[10], p[15], p[18], p[24]}, new int[]{1, 4, 0, 0, 5, 1, 3, 4, 3});
        s[18] = new Druga.Student("s18", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[5], p[7], p[9], p[11], p[12], p[13], p[14], p[16], p[17], p[18], p[20], p[21], p[22], p[23], p[24]}, new int[]{0, 4, 2, 0, 5, 7, 0, 5, 7, 8, 9, 10, 8, 3, 10, 3, 8, 2, 6});
        s[19] = new Druga.Student("s19", new Druga.Predmet[]{p[0], p[5], p[6], p[7], p[9], p[11], p[14], p[18], p[19], p[22], p[24]}, new int[]{1, 0, 3, 6, 0, 5, 1, 3, 2, 0, 10});
        s[20] = new Druga.Student("s20", new Druga.Predmet[]{p[19]}, new int[]{5});
        s[21] = new Druga.Student("s21", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24]}, new int[]{1, 0, 0, 0, 2, 2, 4, 4, 3, 3, 1, 5, 3, 5, 1, 0, 4, 0, 0, 3, 2, 1, 4, 3, 3});
        s[22] = new Druga.Student("s22", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[8], p[9], p[10], p[13], p[14], p[15], p[16], p[17], p[18], p[20], p[21], p[22], p[23], p[24]}, new int[]{3, 8, 9, 0, 0, 0, 8, 7, 5, 9, 4, 6, 8, 10, 4, 6, 8, 7, 6, 0, 2});
        s[23] = new Druga.Student("s23", new Druga.Predmet[]{p[2], p[3], p[5], p[7], p[10], p[11], p[13], p[15], p[16], p[17], p[19], p[24]}, new int[]{2, 3, 6, 8, 9, 10, 9, 6, 1, 9, 1, 2});
        s[24] = new Druga.Student("s24", new Druga.Predmet[]{p[3], p[6], p[18]}, new int[]{9, 6, 8});
        s[25] = new Druga.Student("s25", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[21], p[22], p[23], p[24]}, new int[]{8, 8, 3, 5, 0, 4, 7, 6, 2, 2, 10, 3, 3, 0, 8, 3, 7, 9, 10, 3, 9, 4, 3, 8});
        s[26] = new Druga.Student("s26", new Druga.Predmet[]{p[1], p[2], p[3], p[5], p[6], p[7], p[8], p[9], p[10], p[12], p[13], p[14], p[15], p[17], p[18], p[19], p[20], p[24]}, new int[]{4, 1, 4, 0, 0, 3, 0, 2, 5, 2, 4, 3, 5, 1, 1, 0, 3, 4});
        s[27] = new Druga.Student("s27", new Druga.Predmet[]{p[0], p[4], p[5], p[22]}, new int[]{4, 3, 2, 4});
        s[28] = new Druga.Student("s28", new Druga.Predmet[]{p[2], p[12], p[23]}, new int[]{0, 5, 1});
        s[29] = new Druga.Student("s29", new Druga.Predmet[]{p[0], p[8]}, new int[]{4, 0});
        s[30] = new Druga.Student("s30", new Druga.Predmet[]{p[1], p[4], p[6], p[17], p[18]}, new int[]{2, 2, 8, 10, 3});
        s[31] = new Druga.Student("s31", new Druga.Predmet[]{p[6], p[7], p[8], p[10], p[11], p[12], p[13], p[14], p[20], p[24]}, new int[]{2, 10, 7, 7, 5, 3, 3, 10, 2, 5});
        s[32] = new Druga.Student("s32", new Druga.Predmet[]{p[13]}, new int[]{6});
        s[33] = new Druga.Student("s33", new Druga.Predmet[]{p[0], p[3], p[5], p[6], p[7], p[8], p[10], p[11], p[14], p[17], p[19], p[21], p[22], p[23]}, new int[]{0, 4, 4, 5, 5, 1, 2, 1, 3, 4, 5, 2, 0, 1});
        s[34] = new Druga.Student("s34", new Druga.Predmet[]{p[0], p[1], p[3], p[4], p[7], p[8], p[10], p[13], p[18], p[21], p[22]}, new int[]{5, 4, 4, 1, 2, 2, 0, 1, 4, 5, 1});
        s[35] = new Druga.Student("s35", new Druga.Predmet[]{p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[11], p[12], p[13], p[14], p[15], p[16], p[17], p[18], p[19], p[20], p[21], p[22], p[23], p[24]}, new int[]{0, 3, 10, 4, 4, 9, 8, 5, 8, 4, 8, 8, 3, 7, 3, 10, 8, 6, 0, 3, 0, 0, 3, 1, 9});
        s[36] = new Druga.Student("s36", new Druga.Predmet[]{p[0], p[3], p[5], p[7], p[8], p[9], p[10], p[11], p[16], p[18], p[19], p[20], p[22], p[23]}, new int[]{5, 5, 2, 4, 0, 2, 5, 4, 2, 1, 0, 4, 2, 1});
        s[37] = new Druga.Student("s37", new Druga.Predmet[]{p[11], p[12], p[14], p[21]}, new int[]{4, 10, 5, 4});
        s[38] = new Druga.Student("s38", new Druga.Predmet[]{p[0], p[1], p[2], p[4], p[5], p[8], p[9], p[10], p[15], p[19], p[21], p[22], p[24]}, new int[]{7, 5, 0, 2, 4, 7, 0, 5, 7, 7, 2, 9, 1});

        Druga.Letnik letnik = new Druga.Letnik(s);
        for (int d = 1;  d <= 5;  d++) {
            System.out.println(letnik.morebitnaPrekrivanja(d));
        }
    }
}
