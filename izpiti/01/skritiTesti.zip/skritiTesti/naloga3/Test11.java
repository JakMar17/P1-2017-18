// _NE_ODSTRANI_

import java.awt.Color;

public class Test11 {

    public static void main(String[] args) {

        double wHise = 25.0;
        double hHise = 29.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 1.00, 21.50, 2.90, 1.50),
            new Tretja.Stena(false, 9.30, 1.10, 26.10, 2.00),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat11.png", "600x696"});
    }
}
