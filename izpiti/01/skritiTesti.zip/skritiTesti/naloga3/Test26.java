// _NE_ODSTRANI_

import java.awt.Color;

public class Test26 {

    public static void main(String[] args) {

        double wHise = 2.0;
        double hHise = 3.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 0.40, 0.10, 2.70, 0.12),
            new Tretja.Stena(true, 0.10, 0.40, 1.80, 0.15),
            new Tretja.StenaZOdprtino(false, 1.80, 0.30, 2.70, 0.08, Color.ORANGE, 0.95),
            new Tretja.StenaZOdprtino(true, 0.90, 2.20, 0.80, 0.30, Color.PINK, 0.58),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat26.png", "424x636"});
    }
}
