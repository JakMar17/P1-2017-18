// _NE_ODSTRANI_

import java.awt.Color;

public class Test49 {

    public static void main(String[] args) {

        double wHise = 6.0;
        double hHise = 4.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 2.80, 1.10, 2.40, 0.16),
            new Tretja.StenaZOdprtino(true, 4.30, 2.30, 0.60, 0.08, Color.BLUE, 0.16),
            new Tretja.StenaZOknom(false, 2.60, 0.20, 1.60, 0.24, Color.MAGENTA, 0.66),
            new Tretja.StenaZVrati(true, 4.00, 2.40, 1.80, 0.28, Color.BLUE, 1.41, true),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat49.png", "606x404"});
    }
}
