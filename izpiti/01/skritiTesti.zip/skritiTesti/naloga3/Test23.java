// _NE_ODSTRANI_

import java.awt.Color;

public class Test23 {

    public static void main(String[] args) {

        double wHise = 4.0;
        double hHise = 5.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 2.80, 1.00, 3.50, 0.04, Color.ORANGE, 2.76),
            new Tretja.StenaZOdprtino(true, 1.00, 1.50, 2.00, 0.15, Color.BLUE, 0.99),
            new Tretja.StenaZOdprtino(true, 1.10, 3.60, 1.60, 0.05, Color.ORANGE, 0.58),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat23.png", "516x645"});
    }
}
