// _NE_ODSTRANI_

import java.awt.Color;

public class Test39 {

    public static void main(String[] args) {

        double wHise = 48.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(false, 4.60, 0.70, 45.00, 1.44, Color.BLUE, 20.26),
            new Tretja.StenaZOknom(false, 9.20, 22.70, 15.00, 1.92, Color.YELLOW, 5.85),
            new Tretja.StenaZOknom(false, 34.00, 0.20, 45.00, 3.84, Color.CYAN, 27.12),
            new Tretja.StenaZOknom(false, 18.80, 2.60, 30.00, 3.36, Color.PINK, 13.68),
            new Tretja.StenaZOknom(false, 13.00, 29.40, 15.00, 3.36, Color.MAGENTA, 3.56),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat39.png", "432x450"});
    }
}
