// _NE_ODSTRANI_

import java.awt.Color;

public class Test33 {

    public static void main(String[] args) {

        double wHise = 35.0;
        double hHise = 40.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(true, 7.00, 19.30, 24.50, 1.60, Color.CYAN, 14.01),
            new Tretja.StenaZOknom(true, 6.80, 9.70, 21.00, 1.60, Color.GREEN, 6.52),
            new Tretja.StenaZOknom(true, 14.00, 8.70, 7.00, 4.00, Color.ORANGE, 2.97),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat33.png", "350x400"});
    }
}
