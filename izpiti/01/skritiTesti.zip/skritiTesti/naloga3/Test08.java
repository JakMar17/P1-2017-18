
public class Test08 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(14, 2, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.pikNaMeter(280, 40)));
        System.out.println(Platno.ri(tretja.pikNaMeter(560, 80)));
        System.out.println(Platno.ri(tretja.pikNaMeter(280, 40)));
    }
}
