// _NE_ODSTRANI_

import java.awt.Color;

public class Test45 {

    public static void main(String[] args) {

        double wHise = 16.0;
        double hHise = 9.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(true, 4.60, 2.00, 11.20, 0.18, Color.YELLOW, 8.87),
            new Tretja.StenaZOknom(false, 7.30, 1.80, 1.80, 1.12, Color.ORANGE, 0.75),
            new Tretja.StenaZVrati(false, 12.00, 0.50, 3.60, 1.12, Color.MAGENTA, 2.27, true),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat45.png", "848x477"});
    }
}
