// _NE_ODSTRANI_

import java.awt.Color;

public class Test28 {

    public static void main(String[] args) {

        double wHise = 24.0;
        double hHise = 30.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 9.30, 18.50, 2.40, 0.60),
            new Tretja.Stena(false, 10.60, 4.20, 12.00, 1.44),
            new Tretja.StenaZOdprtino(false, 5.80, 17.30, 12.00, 1.68, Color.MAGENTA, 4.32),
            new Tretja.StenaZOdprtino(true, 16.30, 17.50, 7.20, 0.30, Color.MAGENTA, 4.90),
            new Tretja.StenaZOdprtino(false, 17.30, 0.00, 30.00, 1.44, Color.ORANGE, 10.42),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat28.png", "696x870"});
    }
}
