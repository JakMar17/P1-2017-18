// _NE_ODSTRANI_

import java.awt.Color;

public class Test38 {

    public static void main(String[] args) {

        double wHise = 47.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 2.30, 33.80, 42.30, 5.00),
            new Tretja.StenaZOdprtino(true, 0.70, 18.10, 42.30, 4.00, Color.ORANGE, 25.04),
            new Tretja.StenaZOknom(false, 33.70, 9.40, 35.00, 4.70, Color.YELLOW, 22.59),
            new Tretja.StenaZOknom(false, 37.00, 25.40, 15.00, 0.94, Color.MAGENTA, 6.44),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat38.png", "752x800"});
    }
}
