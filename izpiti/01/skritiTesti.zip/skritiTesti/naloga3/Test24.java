// _NE_ODSTRANI_

import java.awt.Color;

public class Test24 {

    public static void main(String[] args) {

        double wHise = 36.0;
        double hHise = 47.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 26.00, 2.40, 32.90, 2.52),
            new Tretja.StenaZOdprtino(true, 8.70, 43.20, 7.20, 0.47, Color.PINK, 1.53),
            new Tretja.StenaZOdprtino(false, 12.70, 1.80, 23.50, 3.60, Color.YELLOW, 12.74),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat24.png", "396x517"});
    }
}
