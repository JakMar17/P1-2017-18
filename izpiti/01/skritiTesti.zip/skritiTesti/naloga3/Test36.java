// _NE_ODSTRANI_

import java.awt.Color;

public class Test36 {

    public static void main(String[] args) {

        double wHise = 20.0;
        double hHise = 11.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(false, 5.40, 1.70, 8.80, 1.20, Color.CYAN, 3.31),
            new Tretja.StenaZOknom(true, 0.00, 6.10, 20.00, 0.55, Color.ORANGE, 13.63),
            new Tretja.StenaZOknom(true, 11.20, 9.20, 6.00, 0.33, Color.RED, 4.66),
            new Tretja.StenaZOknom(true, 2.70, 2.40, 2.00, 0.55, Color.CYAN, 1.59),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat36.png", "780x429"});
    }
}
