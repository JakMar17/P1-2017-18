// _NE_ODSTRANI_

import java.awt.Color;

public class Test46 {

    public static void main(String[] args) {

        double wHise = 23.0;
        double hHise = 32.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZVrati(false, 16.20, 9.10, 12.80, 1.38, Color.BLUE, 10.21, true),
            new Tretja.StenaZVrati(false, 8.30, 20.20, 3.20, 0.92, Color.MAGENTA, 0.89, true),
            new Tretja.StenaZVrati(false, 10.60, 15.80, 3.20, 0.46, Color.PINK, 2.42, false),
            new Tretja.StenaZVrati(false, 1.50, 2.90, 28.80, 1.38, Color.BLUE, 17.84, false),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat46.png", "598x832"});
    }
}
