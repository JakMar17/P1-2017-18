
public class Test01 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(14, 18, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.xTlorisa(1260, 1620)));
        System.out.println(Platno.ri(tretja.xTlorisa(700, 900)));
        System.out.println(Platno.ri(tretja.xTlorisa(840, 1080)));
    }
}
