
public class Test07 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(12, 10, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.pikNaMeter(600, 500)));
        System.out.println(Platno.ri(tretja.pikNaMeter(120, 100)));
        System.out.println(Platno.ri(tretja.pikNaMeter(360, 300)));
    }
}
