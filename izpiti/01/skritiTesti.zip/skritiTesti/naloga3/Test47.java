// _NE_ODSTRANI_

import java.awt.Color;

public class Test47 {

    public static void main(String[] args) {

        double wHise = 9.0;
        double hHise = 8.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(true, 0.00, 4.40, 9.00, 0.48, Color.CYAN, 6.48),
            new Tretja.StenaZVrati(false, 0.20, 0.20, 1.60, 0.27, Color.ORANGE, 1.00, false),
            new Tretja.StenaZVrati(true, 5.20, 5.30, 3.60, 0.16, Color.PINK, 1.99, true),
            new Tretja.StenaZVrati(true, 4.70, 1.90, 0.90, 0.24, Color.CYAN, 0.60, false),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat47.png", "477x424"});
    }
}
