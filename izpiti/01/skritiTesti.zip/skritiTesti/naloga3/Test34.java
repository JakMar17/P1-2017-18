// _NE_ODSTRANI_

import java.awt.Color;

public class Test34 {

    public static void main(String[] args) {

        double wHise = 46.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(true, 21.50, 3.50, 13.80, 3.50, Color.YELLOW, 5.97),
            new Tretja.StenaZOknom(true, 10.70, 32.40, 27.60, 2.50, Color.MAGENTA, 6.19),
            new Tretja.StenaZOknom(false, 9.90, 1.20, 35.00, 4.60, Color.RED, 19.07),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat34.png", "782x850"});
    }
}
