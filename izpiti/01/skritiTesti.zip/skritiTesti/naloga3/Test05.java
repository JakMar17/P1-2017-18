
public class Test05 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(16, 19, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.yTlorisa(1440, 1710)));
        System.out.println(Platno.ri(tretja.yTlorisa(160, 190)));
        System.out.println(Platno.ri(tretja.yTlorisa(800, 950)));
    }
}
