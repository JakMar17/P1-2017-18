// _NE_ODSTRANI_

import java.awt.Color;

public class Test13 {

    public static void main(String[] args) {

        double wHise = 1.0;
        double hHise = 2.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 0.00, 1.40, 0.10, 0.10),
            new Tretja.Stena(true, 0.40, 0.50, 0.50, 0.20),
            new Tretja.Stena(true, 0.40, 1.20, 0.30, 0.14),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat13.png", "409x818"});
    }
}
