// _NE_ODSTRANI_

import java.awt.Color;

public class Test42 {

    public static void main(String[] args) {

        double wHise = 33.0;
        double hHise = 36.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(false, 12.20, 1.70, 32.40, 1.32, Color.YELLOW, 14.69),
            new Tretja.StenaZVrati(false, 24.90, 26.20, 7.20, 2.97, Color.RED, 4.39, false),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat42.png", "726x792"});
    }
}
