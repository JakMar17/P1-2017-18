// _NE_ODSTRANI_

import java.awt.Color;

public class Test21 {

    public static void main(String[] args) {

        double wHise = 18.0;
        double hHise = 18.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 15.20, 5.40, 1.80, 0.54, Color.RED, 0.96),
            new Tretja.StenaZOdprtino(true, 6.10, 5.80, 7.20, 0.54, Color.RED, 1.84),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat21.png", "468x468"});
    }
}
