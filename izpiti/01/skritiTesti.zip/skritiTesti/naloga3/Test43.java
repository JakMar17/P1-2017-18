// _NE_ODSTRANI_

import java.awt.Color;

public class Test43 {

    public static void main(String[] args) {

        double wHise = 32.0;
        double hHise = 33.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZVrati(true, 10.60, 18.90, 16.00, 3.30, Color.PINK, 9.86, false),
            new Tretja.StenaZVrati(true, 13.30, 13.30, 9.60, 0.33, Color.CYAN, 4.79, true),
            new Tretja.StenaZVrati(true, 5.60, 29.20, 25.60, 0.99, Color.YELLOW, 12.21, true),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat43.png", "832x858"});
    }
}
