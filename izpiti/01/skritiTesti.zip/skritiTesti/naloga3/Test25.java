// _NE_ODSTRANI_

import java.awt.Color;

public class Test25 {

    public static void main(String[] args) {

        double wHise = 17.0;
        double hHise = 22.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 13.40, 0.20, 19.80, 0.85, Color.GREEN, 11.06),
            new Tretja.StenaZOdprtino(false, 11.60, 2.00, 17.60, 1.70, Color.ORANGE, 11.75),
            new Tretja.StenaZOdprtino(false, 4.60, 2.50, 15.40, 1.02, Color.MAGENTA, 7.64),
            new Tretja.StenaZOdprtino(true, 2.60, 0.70, 8.50, 1.54, Color.RED, 3.17),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat25.png", "646x836"});
    }
}
