
public class Test06 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(12, 5, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.pikNaMeter(480, 200)));
        System.out.println(Platno.ri(tretja.pikNaMeter(840, 350)));
        System.out.println(Platno.ri(tretja.pikNaMeter(600, 250)));
    }
}
