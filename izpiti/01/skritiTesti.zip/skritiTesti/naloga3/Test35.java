// _NE_ODSTRANI_

import java.awt.Color;

public class Test35 {

    public static void main(String[] args) {

        double wHise = 4.0;
        double hHise = 3.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 3.20, 0.20, 2.10, 0.24),
            new Tretja.StenaZOdprtino(false, 1.00, 0.20, 0.90, 0.36, Color.YELLOW, 0.64),
            new Tretja.StenaZOknom(true, 1.30, 0.30, 2.00, 0.30, Color.BLUE, 1.49),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat35.png", "600x450"});
    }
}
