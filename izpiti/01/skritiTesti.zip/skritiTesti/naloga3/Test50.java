// _NE_ODSTRANI_

import java.awt.Color;

public class Test50 {

    public static void main(String[] args) {

        double wHise = 21.0;
        double hHise = 19.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZVrati(true, 5.70, 11.90, 12.60, 1.71, Color.YELLOW, 5.19, false),
            new Tretja.StenaZVrati(true, 1.90, 7.10, 18.90, 1.33, Color.ORANGE, 5.55, true),
            new Tretja.StenaZVrati(false, 18.80, 0.20, 9.50, 2.10, Color.GREEN, 4.28, true),
            new Tretja.StenaZVrati(false, 16.70, 0.10, 3.80, 1.05, Color.YELLOW, 2.49, true),
            new Tretja.StenaZVrati(true, 0.20, 6.10, 18.90, 0.38, Color.CYAN, 12.44, false),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat50.png", "420x380"});
    }
}
