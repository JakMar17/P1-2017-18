
public class Test04 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(9, 11, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.yTlorisa(720, 880)));
        System.out.println(Platno.ri(tretja.yTlorisa(360, 440)));
        System.out.println(Platno.ri(tretja.yTlorisa(450, 550)));
    }
}
