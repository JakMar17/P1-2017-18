// _NE_ODSTRANI_

import java.awt.Color;

public class Test17 {

    public static void main(String[] args) {

        double wHise = 28.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 12.50, 19.00, 10.00, 2.24),
            new Tretja.Stena(false, 6.30, 15.70, 30.00, 1.96),
            new Tretja.Stena(false, 25.70, 2.80, 40.00, 0.56),
            new Tretja.Stena(true, 7.50, 4.00, 14.00, 4.00),
            new Tretja.Stena(false, 22.70, 2.70, 25.00, 1.96),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat17.png", "224x400"});
    }
}
