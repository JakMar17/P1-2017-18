// _NE_ODSTRANI_

import java.awt.Color;

public class Test16 {

    public static void main(String[] args) {

        double wHise = 27.0;
        double hHise = 33.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 5.50, 24.40, 8.10, 2.64),
            new Tretja.Stena(false, 24.90, 0.00, 33.00, 1.35),
            new Tretja.Stena(true, 11.50, 27.90, 13.50, 2.97),
            new Tretja.Stena(true, 0.20, 3.50, 10.80, 1.32),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat16.png", "432x528"});
    }
}
