
public class Test03 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(10, 17, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.xTlorisa(500, 850)));
        System.out.println(Platno.ri(tretja.xTlorisa(400, 680)));
        System.out.println(Platno.ri(tretja.xTlorisa(600, 1020)));
    }
}
