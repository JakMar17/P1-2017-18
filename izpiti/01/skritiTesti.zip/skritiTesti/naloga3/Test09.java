
public class Test09 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(13, 6, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.pikNaMeter(130, 60)));
        System.out.println(Platno.ri(tretja.pikNaMeter(520, 240)));
        System.out.println(Platno.ri(tretja.pikNaMeter(390, 180)));
    }
}
