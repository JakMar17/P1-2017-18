
public class Test10 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(3, 20, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.pikNaMeter(210, 1400)));
        System.out.println(Platno.ri(tretja.pikNaMeter(90, 600)));
        System.out.println(Platno.ri(tretja.pikNaMeter(150, 1000)));
    }
}
