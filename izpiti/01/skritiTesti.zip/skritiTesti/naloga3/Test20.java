// _NE_ODSTRANI_

import java.awt.Color;

public class Test20 {

    public static void main(String[] args) {

        double wHise = 23.0;
        double hHise = 18.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 11.40, 4.10, 9.20, 1.62),
            new Tretja.Stena(true, 0.60, 7.30, 20.70, 1.62),
            new Tretja.Stena(true, 9.30, 10.30, 11.50, 1.26),
            new Tretja.Stena(false, 5.00, 9.00, 9.00, 0.46),
            new Tretja.Stena(false, 8.80, 3.40, 10.80, 2.30),
            new Tretja.Stena(false, 18.50, 9.70, 5.40, 2.07),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat20.png", "667x522"});
    }
}
