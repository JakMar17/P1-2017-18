// _NE_ODSTRANI_

import java.awt.Color;

public class Test44 {

    public static void main(String[] args) {

        double wHise = 1.0;
        double hHise = 1.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(true, 0.20, 0.60, 0.20, 0.08, Color.BLUE, 0.13),
            new Tretja.StenaZVrati(false, 0.00, 0.10, 0.60, 0.05, Color.BLUE, 0.47, false),
            new Tretja.StenaZVrati(false, 0.70, 0.70, 0.10, 0.09, Color.CYAN, 0.02, true),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat44.png", "663x663"});
    }
}
