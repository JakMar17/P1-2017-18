// _NE_ODSTRANI_

import java.awt.Color;

public class Test12 {

    public static void main(String[] args) {

        double wHise = 21.0;
        double hHise = 25.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 0.50, 21.50, 10.50, 2.25),
            new Tretja.Stena(true, 14.30, 11.00, 2.10, 2.50),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat12.png", "735x875"});
    }
}
