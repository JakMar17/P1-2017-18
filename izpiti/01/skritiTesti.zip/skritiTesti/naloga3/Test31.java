// _NE_ODSTRANI_

import java.awt.Color;

public class Test31 {

    public static void main(String[] args) {

        double wHise = 48.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOknom(false, 36.70, 4.50, 45.00, 4.32, Color.RED, 16.65),
            new Tretja.StenaZOknom(true, 7.70, 24.50, 38.40, 4.00, Color.BLUE, 18.90),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat31.png", "720x750"});
    }
}
