// _NE_ODSTRANI_

import java.awt.Color;

public class Test48 {

    public static void main(String[] args) {

        double wHise = 1.0;
        double hHise = 2.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 0.60, 0.20, 1.40, 0.08, Color.BLUE, 0.91),
            new Tretja.StenaZOknom(false, 1.00, 0.10, 1.80, 0.03, Color.PINK, 1.16),
            new Tretja.StenaZVrati(false, 0.40, 0.70, 0.60, 0.07, Color.RED, 0.25, true),
            new Tretja.StenaZVrati(true, 0.80, 0.80, 0.10, 0.16, Color.ORANGE, 0.08, true),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat48.png", "277x554"});
    }
}
