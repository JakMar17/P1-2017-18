// _NE_ODSTRANI_

import java.awt.Color;

public class Test30 {

    public static void main(String[] args) {

        double wHise = 49.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 5.00, 5.20, 40.00, 0.98),
            new Tretja.Stena(false, 17.20, 10.60, 30.00, 3.43),
            new Tretja.Stena(true, 0.00, 5.00, 49.00, 4.00),
            new Tretja.StenaZOdprtino(true, 7.30, 4.00, 14.70, 4.00, Color.YELLOW, 11.41),
            new Tretja.StenaZOdprtino(false, 15.30, 9.20, 30.00, 4.41, Color.CYAN, 20.51),
            new Tretja.StenaZOdprtino(false, 30.20, 30.60, 10.00, 4.90, Color.MAGENTA, 6.89),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat30.png", "686x700"});
    }
}
