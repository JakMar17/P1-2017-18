// _NE_ODSTRANI_

import java.awt.Color;

public class Test18 {

    public static void main(String[] args) {

        double wHise = 37.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 33.00, 0.00, 50.00, 1.85),
            new Tretja.Stena(true, 24.90, 25.10, 3.70, 3.00),
            new Tretja.Stena(false, 9.10, 14.80, 30.00, 1.85),
            new Tretja.Stena(false, 28.10, 6.10, 5.00, 0.37),
            new Tretja.Stena(false, 4.60, 44.40, 5.00, 2.22),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat18.png", "333x450"});
    }
}
