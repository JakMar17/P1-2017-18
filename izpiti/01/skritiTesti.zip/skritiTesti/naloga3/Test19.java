// _NE_ODSTRANI_

import java.awt.Color;

public class Test19 {

    public static void main(String[] args) {

        double wHise = 40.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 11.60, 13.80, 15.00, 0.80),
            new Tretja.Stena(true, 3.70, 2.30, 24.00, 5.00),
            new Tretja.Stena(false, 23.80, 14.30, 5.00, 1.20),
            new Tretja.Stena(true, 7.50, 32.20, 4.00, 5.00),
            new Tretja.Stena(true, 1.90, 19.00, 36.00, 1.00),
            new Tretja.Stena(false, 19.60, 20.00, 25.00, 1.60),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat19.png", "360x450"});
    }
}
