// _NE_ODSTRANI_

import java.awt.Color;

public class Test29 {

    public static void main(String[] args) {

        double wHise = 29.0;
        double hHise = 38.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 23.60, 0.00, 38.00, 2.32, Color.ORANGE, 14.77),
            new Tretja.StenaZOdprtino(false, 7.90, 19.80, 11.40, 2.32, Color.MAGENTA, 3.16),
            new Tretja.StenaZOdprtino(true, 8.50, 35.90, 20.30, 1.90, Color.ORANGE, 8.18),
            new Tretja.StenaZOdprtino(false, 14.40, 6.40, 11.40, 1.74, Color.PINK, 2.41),
            new Tretja.StenaZOdprtino(false, 24.70, 0.80, 3.80, 2.61, Color.BLUE, 1.01),
            new Tretja.StenaZOdprtino(false, 15.80, 6.50, 30.40, 0.29, Color.BLUE, 22.75),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat29.png", "319x418"});
    }
}
