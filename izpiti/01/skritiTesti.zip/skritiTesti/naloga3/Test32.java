// _NE_ODSTRANI_

import java.awt.Color;

public class Test32 {

    public static void main(String[] args) {

        double wHise = 48.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 16.10, 9.40, 40.00, 4.32, Color.MAGENTA, 12.61),
            new Tretja.StenaZOknom(false, 29.20, 21.20, 25.00, 1.44, Color.CYAN, 6.34),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat32.png", "672x700"});
    }
}
