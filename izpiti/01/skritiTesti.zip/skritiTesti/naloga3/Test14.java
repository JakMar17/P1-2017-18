// _NE_ODSTRANI_

import java.awt.Color;

public class Test14 {

    public static void main(String[] args) {

        double wHise = 42.0;
        double hHise = 50.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(true, 19.50, 13.60, 21.00, 2.50),
            new Tretja.Stena(true, 0.00, 18.80, 42.00, 4.50),
            new Tretja.Stena(true, 0.60, 45.60, 8.40, 2.50),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat14.png", "420x500"});
    }
}
