
public class Test02 {

    public static void main(String[] args) {

        Tretja tretja = new Tretja(7, 13, new Tretja.Stena[0]);
        System.out.println(Platno.ri(tretja.xTlorisa(280, 520)));
        System.out.println(Platno.ri(tretja.xTlorisa(350, 650)));
        System.out.println(Platno.ri(tretja.xTlorisa(210, 390)));
    }
}
