// _NE_ODSTRANI_

import java.awt.Color;

public class Test22 {

    public static void main(String[] args) {

        double wHise = 11.0;
        double hHise = 15.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 2.00, 6.70, 6.00, 0.77),
            new Tretja.StenaZOdprtino(true, 1.60, 2.60, 4.40, 0.90, Color.ORANGE, 1.36),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat22.png", "440x600"});
    }
}
