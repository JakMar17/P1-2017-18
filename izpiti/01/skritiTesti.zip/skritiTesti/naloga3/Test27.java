// _NE_ODSTRANI_

import java.awt.Color;

public class Test27 {

    public static void main(String[] args) {

        double wHise = 16.0;
        double hHise = 14.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(true, 2.90, 12.80, 12.80, 1.12, Color.BLUE, 9.72),
            new Tretja.StenaZOdprtino(true, 2.00, 6.20, 8.00, 0.98, Color.RED, 4.97),
            new Tretja.StenaZOdprtino(true, 2.00, 12.10, 6.40, 0.84, Color.RED, 1.72),
            new Tretja.StenaZOdprtino(false, 6.70, 2.50, 9.80, 1.60, Color.CYAN, 3.22),
            new Tretja.StenaZOdprtino(true, 7.10, 0.80, 8.00, 0.84, Color.RED, 4.73),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat27.png", "720x630"});
    }
}
