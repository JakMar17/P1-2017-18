// _NE_ODSTRANI_

import java.awt.Color;

public class Test15 {

    public static void main(String[] args) {

        double wHise = 26.0;
        double hHise = 15.0;

        Tretja.Stena[] stene = {
            new Tretja.Stena(false, 11.10, 0.30, 10.50, 2.08),
            new Tretja.Stena(true, 12.00, 0.70, 13.00, 0.90),
            new Tretja.Stena(false, 20.20, 0.10, 12.00, 1.30),
            new Tretja.Stena(false, 14.60, 2.00, 12.00, 2.60),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat15.png", "494x285"});
    }
}
