// _NE_ODSTRANI_

import java.awt.Color;

public class Test41 {

    public static void main(String[] args) {

        double wHise = 5.0;
        double hHise = 4.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZVrati(false, 3.60, 0.40, 1.20, 0.05, Color.RED, 0.72, true),
            new Tretja.StenaZVrati(false, 2.10, 0.10, 2.40, 0.35, Color.PINK, 1.31, true),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat41.png", "540x432"});
    }
}
