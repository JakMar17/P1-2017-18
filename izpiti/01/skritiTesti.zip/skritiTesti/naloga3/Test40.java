// _NE_ODSTRANI_

import java.awt.Color;

public class Test40 {

    public static void main(String[] args) {

        double wHise = 7.0;
        double hHise = 3.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(false, 2.20, 0.50, 0.60, 0.28, Color.CYAN, 0.23),
            new Tretja.StenaZOknom(true, 0.00, 2.40, 7.00, 0.24, Color.PINK, 2.98),
            new Tretja.StenaZOknom(false, 3.10, 1.50, 0.60, 0.70, Color.CYAN, 0.42),
            new Tretja.StenaZOknom(false, 2.00, 0.10, 1.20, 0.70, Color.RED, 0.48),
            new Tretja.StenaZOknom(false, 0.80, 0.50, 1.50, 0.63, Color.BLUE, 0.63),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat40.png", "672x288"});
    }
}
