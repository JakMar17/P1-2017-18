// _NE_ODSTRANI_

import java.awt.Color;

public class Test37 {

    public static void main(String[] args) {

        double wHise = 34.0;
        double hHise = 28.0;

        Tretja.Stena[] stene = {
            new Tretja.StenaZOdprtino(true, 1.90, 4.60, 30.60, 2.24, Color.CYAN, 19.33),
            new Tretja.StenaZOknom(true, 16.30, 25.40, 3.40, 2.24, Color.RED, 2.48),
            new Tretja.StenaZOknom(true, 8.80, 23.40, 20.40, 2.80, Color.CYAN, 4.14),
            new Tretja.StenaZOknom(true, 12.10, 18.20, 13.60, 2.24, Color.PINK, 9.42),
        };

        Tretja tretja = new Tretja(wHise, hHise, stene);
        tretja.sproziRisanje(new String[]{"rezultat37.png", "646x532"});
    }
}
