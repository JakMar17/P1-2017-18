
public class Test26 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(160L));
        System.out.println(Prva.odstraniNicle(860L));
        System.out.println(Prva.odstraniNicle(803L));
        System.out.println(Prva.odstraniNicle(570L));
        System.out.println(Prva.odstraniNicle(740L));
        System.out.println(Prva.odstraniNicle(630L));
    }
}
