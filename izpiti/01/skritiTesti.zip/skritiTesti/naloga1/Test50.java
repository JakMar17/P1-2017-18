
public class Test50 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(83568100186000L));
        System.out.println(Prva.odstraniNicle(80010644409504L));
        System.out.println(Prva.odstraniNicle(32409200010637L));
        System.out.println(Prva.odstraniNicle(37804937006008L));
        System.out.println(Prva.odstraniNicle(40804013480104L));
        System.out.println(Prva.odstraniNicle(75055004204408L));
        System.out.println(Prva.odstraniNicle(40010330053679L));
    }
}
