
public class Test34 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(9150693L));
        System.out.println(Prva.odstraniNicle(8654404L));
        System.out.println(Prva.odstraniNicle(4790375L));
        System.out.println(Prva.odstraniNicle(2489209L));
        System.out.println(Prva.odstraniNicle(1994071L));
    }
}
