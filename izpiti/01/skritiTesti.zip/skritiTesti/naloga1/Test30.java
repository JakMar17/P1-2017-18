
public class Test30 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(780L));
        System.out.println(Prva.odstraniNicle(460L));
        System.out.println(Prva.odstraniNicle(805L));
        System.out.println(Prva.odstraniNicle(201L));
        System.out.println(Prva.odstraniNicle(750L));
        System.out.println(Prva.odstraniNicle(504L));
        System.out.println(Prva.odstraniNicle(406L));
        System.out.println(Prva.odstraniNicle(106L));
        System.out.println(Prva.odstraniNicle(608L));
        System.out.println(Prva.odstraniNicle(880L));
    }
}
