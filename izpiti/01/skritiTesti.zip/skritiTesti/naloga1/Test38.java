
public class Test38 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(7978900210007L));
        System.out.println(Prva.odstraniNicle(2307050060823L));
        System.out.println(Prva.odstraniNicle(2329008013900L));
        System.out.println(Prva.odstraniNicle(9020885800440L));
        System.out.println(Prva.odstraniNicle(7202090403740L));
        System.out.println(Prva.odstraniNicle(6521700200520L));
    }
}
