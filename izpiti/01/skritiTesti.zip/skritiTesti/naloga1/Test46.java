
public class Test46 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(802100407L));
        System.out.println(Prva.odstraniNicle(101330050L));
        System.out.println(Prva.odstraniNicle(540308700L));
        System.out.println(Prva.odstraniNicle(904301800L));
        System.out.println(Prva.odstraniNicle(802830030L));
        System.out.println(Prva.odstraniNicle(404060902L));
        System.out.println(Prva.odstraniNicle(300467070L));
    }
}
