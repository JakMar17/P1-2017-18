
public class Test39 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(52186000107L));
        System.out.println(Prva.odstraniNicle(17817000019L));
        System.out.println(Prva.odstraniNicle(50170290510L));
        System.out.println(Prva.odstraniNicle(89406900606L));
        System.out.println(Prva.odstraniNicle(25800027990L));
        System.out.println(Prva.odstraniNicle(30006277503L));
    }
}
