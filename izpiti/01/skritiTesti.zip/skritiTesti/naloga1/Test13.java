
public class Test13 {

    public static void main(String[] args) {
        int delitelj = 84;
        int[] tabela1 = {5292, 4116, 1344, 18060, 2352, 12264, 50148, 7560, 62916, 24108, 61152, 35952, 54852, 44520, 15204, 42420, 62496, 80472};
        int[] tabela2 = {79471, 28613, 28356, 48779, 81319, 2053, 30908, 5856, 64692, 81531, 65574, 10597, 41664, 53035, 71586, 7302, 4032, 74893};
        int[] tabela3 = {21252, 9576, 30828, 50736, 6920, 75516, 34188, 70140, 28896, 48720, 77196, 34524, 49392, 48630, 64663, 70392, 36822, 26376};
        int[] tabela4 = {68040, 75096, 76944, 75432, 52080, 8400, 73752, 18732, 68880, 58800, 3528, 80472, 16716, 32592, 69972, 57288, 19488, 57624};
        int[] tabela5 = {56818, 16370, 61908, 3780, 47700, 55944, 30240, 49607, 20286, 19028, 59825, 45276, 64860, 23352, 25704, 37213, 43253, 35700};
        int[] tabela6 = {58128, 17587, 46580, 11172, 35700, 23857, 4368, 47038, 10500, 81243, 63014, 10500, 5208, 11602, 47964, 49308, 1483, 23373};
        int[] tabela7 = {71492, 31416, 34692, 36120, 53928, 60060, 1260, 49308, 11256, 10416, 44604, 75096, 54264, 56700, 77784, 79884, 45230, 76188};

        System.out.println(Prva.zadnjiDeljiviPar(tabela1, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela2, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela3, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela4, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela5, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela6, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela7, delitelj));
    }
}
