
public class Test33 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(7432066489885L));
        System.out.println(Prva.odstraniNicle(2082817152315L));
        System.out.println(Prva.odstraniNicle(5282230663995L));
        System.out.println(Prva.odstraniNicle(6853077645996L));
        System.out.println(Prva.odstraniNicle(7354920563747L));
        System.out.println(Prva.odstraniNicle(2977801787739L));
        System.out.println(Prva.odstraniNicle(7635046734994L));
        System.out.println(Prva.odstraniNicle(9319221502217L));
    }
}
