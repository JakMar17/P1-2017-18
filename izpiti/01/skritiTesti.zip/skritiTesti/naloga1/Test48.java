
public class Test48 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(707500L));
        System.out.println(Prva.odstraniNicle(204700L));
        System.out.println(Prva.odstraniNicle(400015L));
        System.out.println(Prva.odstraniNicle(808100L));
        System.out.println(Prva.odstraniNicle(901040L));
    }
}
