
public class Test44 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(704909859L));
        System.out.println(Prva.odstraniNicle(799302806L));
        System.out.println(Prva.odstraniNicle(396018506L));
        System.out.println(Prva.odstraniNicle(779098303L));
        System.out.println(Prva.odstraniNicle(607370372L));
        System.out.println(Prva.odstraniNicle(179960079L));
    }
}
