
public class Test07 {

    public static void main(String[] args) {
        int delitelj = 63;
        int[] tabela1 = {55697, 13307, 47386, 7439, 41881, 27400, 30896, 45340, 55196, 39699, 59767, 24255, 35595, 41795, 58741};
        int[] tabela2 = {23216, 7686, 30870, 22219, 23096, 33069, 61286, 34194, 13202, 36758, 43351, 33357, 57419, 2892, 9670};
        int[] tabela3 = {38057, 42438, 43813, 10324, 30569, 18538, 12971, 35312, 461, 3414, 57960, 61110, 46082, 29288, 46420};
        int[] tabela4 = {10094, 47672, 62937, 58212, 61031, 46834, 12342, 14714, 34999, 135, 10610, 26632, 46647, 21117, 46696};
        int[] tabela5 = {59771, 30344, 4158, 56196, 39749, 17330, 22703, 16685, 47934, 40822, 32070, 21622, 4318, 48634, 38061};
        int[] tabela6 = {22040, 1590, 12246, 31923, 44177, 28398, 42835, 49978, 55944, 53298, 1330, 23483, 45644, 18217, 50918};
        int[] tabela7 = {25223, 38969, 34892, 48381, 31648, 48558, 6538, 55698, 6678, 42966, 42947, 45010, 37657, 20565, 16437};
        int[] tabela8 = {46326, 9576, 40572, 40392, 27744, 20726, 41728, 15843, 36128, 54125, 40337, 38261, 31409, 17587, 33616};
        int[] tabela9 = {52028, 60652, 29492, 7896, 17712, 57333, 22713, 5094, 50629, 2957, 42936, 41013, 14805, 31523, 23691};

        System.out.println(Prva.zadnjiDeljiviPar(tabela1, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela2, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela3, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela4, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela5, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela6, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela7, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela8, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela9, delitelj));
    }
}
