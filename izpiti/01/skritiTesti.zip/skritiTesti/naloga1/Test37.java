
public class Test37 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(710936268799203366L));
        System.out.println(Prva.odstraniNicle(108047645277227479L));
        System.out.println(Prva.odstraniNicle(694448804379145409L));
        System.out.println(Prva.odstraniNicle(278763173552811003L));
        System.out.println(Prva.odstraniNicle(528670240199582724L));
        System.out.println(Prva.odstraniNicle(607783780663361544L));
        System.out.println(Prva.odstraniNicle(864460068564311767L));
        System.out.println(Prva.odstraniNicle(731590519496928140L));
        System.out.println(Prva.odstraniNicle(137177436614307501L));
    }
}
