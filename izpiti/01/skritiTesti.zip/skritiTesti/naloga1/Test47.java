
public class Test47 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(528830728240890576L));
        System.out.println(Prva.odstraniNicle(354664190760759098L));
        System.out.println(Prva.odstraniNicle(258605550383890864L));
        System.out.println(Prva.odstraniNicle(668191550794040791L));
        System.out.println(Prva.odstraniNicle(704086181589158605L));
        System.out.println(Prva.odstraniNicle(387695360058608488L));
    }
}
