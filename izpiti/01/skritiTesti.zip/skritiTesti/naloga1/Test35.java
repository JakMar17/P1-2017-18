
public class Test35 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(69285340542671L));
        System.out.println(Prva.odstraniNicle(92755604754119L));
        System.out.println(Prva.odstraniNicle(62817435047452L));
        System.out.println(Prva.odstraniNicle(88584350914548L));
        System.out.println(Prva.odstraniNicle(47783043934665L));
        System.out.println(Prva.odstraniNicle(17939191461079L));
    }
}
