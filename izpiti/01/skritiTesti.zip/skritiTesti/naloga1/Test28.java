
public class Test28 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(822443170414L));
        System.out.println(Prva.odstraniNicle(581924444105L));
        System.out.println(Prva.odstraniNicle(313627320697L));
        System.out.println(Prva.odstraniNicle(724833407793L));
        System.out.println(Prva.odstraniNicle(456803343138L));
        System.out.println(Prva.odstraniNicle(766347363102L));
        System.out.println(Prva.odstraniNicle(295653236407L));
        System.out.println(Prva.odstraniNicle(119298571077L));
        System.out.println(Prva.odstraniNicle(268537661308L));
    }
}
