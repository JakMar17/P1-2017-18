
public class Test41 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(100000L));
        System.out.println(Prva.odstraniNicle(700000L));
        System.out.println(Prva.odstraniNicle(200000L));
        System.out.println(Prva.odstraniNicle(700000L));
        System.out.println(Prva.odstraniNicle(300000L));
    }
}
