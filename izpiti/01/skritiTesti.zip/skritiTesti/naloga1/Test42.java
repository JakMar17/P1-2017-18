
public class Test42 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(6600L));
        System.out.println(Prva.odstraniNicle(4002L));
        System.out.println(Prva.odstraniNicle(6800L));
        System.out.println(Prva.odstraniNicle(6060L));
        System.out.println(Prva.odstraniNicle(4010L));
        System.out.println(Prva.odstraniNicle(4500L));
    }
}
