
public class Test01 {

    public static void main(String[] args) {
        int delitelj = 59;
        int[] tabela1 = {4637, 51806, 13139, 25332, 30983, 4447, 20616, 31219, 23654, 2603, 53800, 20650, 36875, 16125, 20925, 45494, 48731, 45928};
        int[] tabela2 = {52419, 39352, 55506, 55376, 54374, 51754, 17038, 3118, 44935, 29857, 1545, 32167, 1560, 27140, 49737, 45113, 49602, 13037};
        int[] tabela3 = {26471, 53513, 11977, 48220, 59017, 43770, 55019, 32321, 46088, 16080, 35978, 28463, 53153, 41287, 16146, 16542, 33181, 11697};
        int[] tabela4 = {37915, 45893, 2925, 29419, 11171, 29606, 25689, 22506, 2228, 22616, 50552, 45391, 28569, 27258, 2773, 46214, 53118, 46365};
        int[] tabela5 = {7032, 18264, 41359, 31093, 53588, 25913, 54464, 57031, 40800, 50004, 27176, 44680, 46125, 56160, 52937, 23026, 39508, 41530};
        int[] tabela6 = {27196, 9374, 37421, 49644, 51882, 21616, 55342, 4779, 11748, 49721, 52526, 50396, 4955, 45790, 17810, 32084, 6928, 30155};
        int[] tabela7 = {48295, 27898, 26975, 43200, 20799, 26958, 8430, 44486, 13570, 904, 56352, 58795, 9680, 32412, 10170, 2630, 30260, 48031};

        System.out.println(Prva.zadnjiDeljiviPar(tabela1, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela2, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela3, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela4, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela5, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela6, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela7, delitelj));
    }
}
