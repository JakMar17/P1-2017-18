
public class Test45 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(5091219783707880L));
        System.out.println(Prva.odstraniNicle(3770787300772275L));
        System.out.println(Prva.odstraniNicle(2040233234553602L));
        System.out.println(Prva.odstraniNicle(8908354969920703L));
        System.out.println(Prva.odstraniNicle(2335102040633268L));
        System.out.println(Prva.odstraniNicle(7230194636356070L));
        System.out.println(Prva.odstraniNicle(2033727650475406L));
        System.out.println(Prva.odstraniNicle(8130690072173634L));
        System.out.println(Prva.odstraniNicle(4904190272460634L));
        System.out.println(Prva.odstraniNicle(2304707119418503L));
    }
}
