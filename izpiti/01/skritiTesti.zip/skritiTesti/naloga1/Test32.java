
public class Test32 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(860L));
        System.out.println(Prva.odstraniNicle(105L));
        System.out.println(Prva.odstraniNicle(870L));
        System.out.println(Prva.odstraniNicle(102L));
        System.out.println(Prva.odstraniNicle(760L));
        System.out.println(Prva.odstraniNicle(110L));
        System.out.println(Prva.odstraniNicle(970L));
        System.out.println(Prva.odstraniNicle(760L));
        System.out.println(Prva.odstraniNicle(205L));
        System.out.println(Prva.odstraniNicle(130L));
    }
}
