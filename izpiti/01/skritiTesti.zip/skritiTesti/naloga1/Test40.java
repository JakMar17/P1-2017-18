
public class Test40 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(600696038055273457L));
        System.out.println(Prva.odstraniNicle(297083017303038867L));
        System.out.println(Prva.odstraniNicle(373350794823006088L));
        System.out.println(Prva.odstraniNicle(588253856020478800L));
        System.out.println(Prva.odstraniNicle(800422971714070488L));
        System.out.println(Prva.odstraniNicle(670339239555600930L));
    }
}
