
public class Test27 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(117036L));
        System.out.println(Prva.odstraniNicle(701288L));
        System.out.println(Prva.odstraniNicle(626054L));
        System.out.println(Prva.odstraniNicle(490994L));
        System.out.println(Prva.odstraniNicle(940182L));
        System.out.println(Prva.odstraniNicle(375704L));
        System.out.println(Prva.odstraniNicle(325099L));
    }
}
