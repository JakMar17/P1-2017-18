
public class Test43 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(226675670003070881L));
        System.out.println(Prva.odstraniNicle(307290094161392200L));
        System.out.println(Prva.odstraniNicle(109962034746210008L));
        System.out.println(Prva.odstraniNicle(586700018404530592L));
        System.out.println(Prva.odstraniNicle(120235750006249045L));
        System.out.println(Prva.odstraniNicle(250860965250270809L));
        System.out.println(Prva.odstraniNicle(972200054307169809L));
        System.out.println(Prva.odstraniNicle(172044950774010506L));
        System.out.println(Prva.odstraniNicle(520833390839900803L));
        System.out.println(Prva.odstraniNicle(720000818658450778L));
    }
}
