
public class Test49 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(40300704900L));
        System.out.println(Prva.odstraniNicle(50000505104L));
        System.out.println(Prva.odstraniNicle(10001503003L));
        System.out.println(Prva.odstraniNicle(15002020300L));
        System.out.println(Prva.odstraniNicle(50070906100L));
        System.out.println(Prva.odstraniNicle(59930000008L));
        System.out.println(Prva.odstraniNicle(48000015030L));
        System.out.println(Prva.odstraniNicle(40000152008L));
    }
}
