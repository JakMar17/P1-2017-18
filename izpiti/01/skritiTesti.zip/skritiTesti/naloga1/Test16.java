
public class Test16 {

    public static void main(String[] args) {
        int delitelj = 10;
        int[] tabela1 = {4766, 7452, 61, 709, 6949, 9246, 1654, 2784, 6173};
        int[] tabela2 = {9284, 2870, 5670, 9485, 5320, 7276, 4488, 7506, 6447};
        int[] tabela3 = {1164, 5540, 8413, 3680, 9800, 7550, 1282, 4535, 7820};
        int[] tabela4 = {3255, 7811, 1050, 3036, 5938, 2544, 1927, 6891, 2667};
        int[] tabela5 = {7770, 9950, 1940, 5714, 8148, 247, 443, 7762, 2020};
        int[] tabela6 = {6722, 8663, 5320, 9297, 8270, 266, 1389, 5882, 4778};
        int[] tabela7 = {636, 5247, 6890, 3233, 1280, 8380, 8972, 5420, 7039};
        int[] tabela8 = {8068, 4988, 6481, 3177, 7577, 4677, 2738, 2082, 9520};
        int[] tabela9 = {5021, 2802, 2023, 6792, 7940, 6781, 6088, 7446, 7427};

        System.out.println(Prva.zadnjiDeljiviPar(tabela1, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela2, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela3, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela4, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela5, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela6, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela7, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela8, delitelj));
        System.out.println(Prva.zadnjiDeljiviPar(tabela9, delitelj));
    }
}
