
public class Test31 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(880624871L));
        System.out.println(Prva.odstraniNicle(969932052L));
        System.out.println(Prva.odstraniNicle(916467303L));
        System.out.println(Prva.odstraniNicle(371710713L));
        System.out.println(Prva.odstraniNicle(125606286L));
    }
}
