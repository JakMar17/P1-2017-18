
public class Test36 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(30500803L));
        System.out.println(Prva.odstraniNicle(86300009L));
        System.out.println(Prva.odstraniNicle(20010066L));
        System.out.println(Prva.odstraniNicle(20870007L));
        System.out.println(Prva.odstraniNicle(27807000L));
        System.out.println(Prva.odstraniNicle(50002150L));
        System.out.println(Prva.odstraniNicle(12108000L));
    }
}
