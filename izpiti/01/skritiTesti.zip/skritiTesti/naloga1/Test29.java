
public class Test29 {

    public static void main(String[] args) {
        System.out.println(Prva.odstraniNicle(78353167122330L));
        System.out.println(Prva.odstraniNicle(56404829884614L));
        System.out.println(Prva.odstraniNicle(85130123711882L));
        System.out.println(Prva.odstraniNicle(56583063691555L));
        System.out.println(Prva.odstraniNicle(52095876726769L));
        System.out.println(Prva.odstraniNicle(79017752818332L));
        System.out.println(Prva.odstraniNicle(33303179785487L));
        System.out.println(Prva.odstraniNicle(45830853353327L));
        System.out.println(Prva.odstraniNicle(41101428131638L));
        System.out.println(Prva.odstraniNicle(72045965311772L));
    }
}
