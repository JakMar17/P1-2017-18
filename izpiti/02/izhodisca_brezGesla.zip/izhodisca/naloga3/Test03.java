// _NE_ODSTRANI_

import java.awt.*;

public class Test03 {

    public static void main(String[] args) {

        int sirinaStolpca = 7;

        Tretja.Objava[][] objave = {
            { new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3) }
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat03.png", "660x480"});
    }
}
