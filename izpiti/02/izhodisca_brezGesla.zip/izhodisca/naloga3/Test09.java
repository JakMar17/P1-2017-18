// _NE_ODSTRANI_

public class Test09 {

    public static void main(String[] args) {

        int sirinaStolpca = 5;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(5), new Tretja.Clanek(9), new Tretja.Clanek(3), new Tretja.Clanek(3), new Tretja.Clanek(2), new Tretja.Clanek(6)},
            {new Tretja.Oglas(3), new Tretja.Oglas(5), new Tretja.Clanek(9), new Tretja.Clanek(2), new Tretja.Clanek(3), new Tretja.Oglas(3)},
            {new Tretja.Clanek(5), new Tretja.Clanek(6), new Tretja.Clanek(5), new Tretja.Clanek(2), new Tretja.Clanek(4), new Tretja.Oglas(8)},
            {new Tretja.Oglas(1), new Tretja.Clanek(2), new Tretja.Oglas(6), new Tretja.Oglas(10), new Tretja.Clanek(8), new Tretja.Oglas(5)},
            {new Tretja.Oglas(4), new Tretja.Clanek(1), new Tretja.Clanek(3), new Tretja.Oglas(1), new Tretja.Oglas(6), new Tretja.Oglas(2)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat09.png", "592x609"});

    }
}
