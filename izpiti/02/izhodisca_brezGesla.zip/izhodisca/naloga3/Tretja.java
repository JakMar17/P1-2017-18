
// 
// (na konec prej"snje vrstice zapi"site va"so vpisno "stevilko)

import java.awt.*;

/*
 * TESTNI PRIMERI:
 *
 * J1--J2, S1--S10: klici metode pikNaCm
 *
 * J3--J4, S11--S20: ena sama vrstica
 *
 * J3--J6, S11--S30: vse objave so enako visoke
 *
 * J3, J5, J7, S11--S15, S21--S25, S31--S35: samo oglasi
 */

public class Tretja extends Platno {

    public static void main(String[] args) {

        int sirinaStolpca = 4;

        Objava[][] objave = {
            { new Clanek(5), new Oglas(2), new Oglas(3), new Clanek(1) },
            { new Oglas(1), new Oglas(4), new Clanek(2), new Clanek(3) },
            { new Oglas(3), new Clanek(4), new Oglas(6), new Oglas(2) },
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(args);
    }

    //=========================================================================
    public static abstract class Objava {

        private int visina;

        protected Objava(int visina) {
            this.visina = visina;
        }

        public int vrniVisino() {
            return this.visina;
        }

        // po potrebi dopolnite ...
    }

    //=========================================================================
    public static class Clanek extends Objava {

        public Clanek(int visina) {
            super(visina);
        }

        // po potrebi dopolnite ...
    }

    //=========================================================================
    public static class Oglas extends Objava {

        public Oglas(int visina) {
            super(visina);
        }

        // po potrebi dopolnite ...
    }

    //=========================================================================

    private int sirinaStolpca;
    private Objava[][] objave;

    public Tretja(int sirinaStolpca, Objava[][] objave) {
        this.sirinaStolpca = sirinaStolpca;
        this.objave = objave;
    }

    protected void narisi(Graphics2D g, double wp, double hp) {
        // dopolnite ...
    }

    public double pikNaCm(double wp, double hp) {
        // popravite / dopolnite ...
        return 0.0;
    }
}
