// _NE_ODSTRANI_

public class Test06 {

    public static void main(String[] args) {

        int sirinaStolpca = 4;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Clanek(3)},
            {new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3)},
            {new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Clanek(3), new Tretja.Clanek(3)},
            {new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3)},
            {new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3), new Tretja.Clanek(3), new Tretja.Clanek(3), new Tretja.Oglas(3)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat06.png", "969x414"});

    }
}
