
public class Test02 {

    public static void main(String[] args) {

        int sirinaStolpca = 3;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(8), new Tretja.Clanek(3), new Tretja.Clanek(3), new Tretja.Oglas(9), new Tretja.Oglas(10), new Tretja.Clanek(2), new Tretja.Clanek(1), new Tretja.Oglas(4)},
            {new Tretja.Oglas(7), new Tretja.Clanek(1), new Tretja.Clanek(2), new Tretja.Clanek(10), new Tretja.Oglas(5), new Tretja.Oglas(6), new Tretja.Clanek(5), new Tretja.Oglas(6)},
            {new Tretja.Oglas(7), new Tretja.Clanek(7), new Tretja.Clanek(6), new Tretja.Clanek(10), new Tretja.Oglas(2), new Tretja.Clanek(6), new Tretja.Oglas(4), new Tretja.Oglas(4)},
            {new Tretja.Oglas(4), new Tretja.Oglas(5), new Tretja.Oglas(10), new Tretja.Oglas(7), new Tretja.Oglas(1), new Tretja.Clanek(2), new Tretja.Oglas(10), new Tretja.Clanek(5)},
            {new Tretja.Clanek(5), new Tretja.Clanek(7), new Tretja.Oglas(3), new Tretja.Oglas(4), new Tretja.Clanek(9), new Tretja.Oglas(7), new Tretja.Oglas(6), new Tretja.Oglas(1)},
            {new Tretja.Clanek(2), new Tretja.Oglas(3), new Tretja.Clanek(2), new Tretja.Oglas(3), new Tretja.Clanek(8), new Tretja.Clanek(7), new Tretja.Oglas(7), new Tretja.Oglas(10)},
            {new Tretja.Clanek(5), new Tretja.Clanek(9), new Tretja.Clanek(2), new Tretja.Oglas(1), new Tretja.Clanek(1), new Tretja.Oglas(10), new Tretja.Clanek(2), new Tretja.Oglas(2)},
            {new Tretja.Clanek(10), new Tretja.Oglas(6), new Tretja.Clanek(5), new Tretja.Oglas(2), new Tretja.Clanek(4), new Tretja.Oglas(8), new Tretja.Oglas(9), new Tretja.Clanek(1)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);

        System.out.println(Platno.ri(tretja.pikNaCm(363, 757)));
        System.out.println(Platno.ri(tretja.pikNaCm(264, 764)));
        System.out.println(Platno.ri(tretja.pikNaCm(858, 513)));
    }
}
