// _NE_ODSTRANI_

import java.awt.*;

public class Test08 {

    public static void main(String[] args) {

        int sirinaStolpca = 4;

        Tretja.Objava[][] objave = {
            { new Tretja.Clanek(5), new Tretja.Oglas(2),  new Tretja.Oglas(3),  new Tretja.Clanek(1) },
            { new Tretja.Oglas(1),  new Tretja.Oglas(4),  new Tretja.Clanek(2), new Tretja.Clanek(3) },
            { new Tretja.Oglas(3),  new Tretja.Clanek(4), new Tretja.Oglas(6),  new Tretja.Oglas(2) },
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat08.png", "630x500"});
    }
}
