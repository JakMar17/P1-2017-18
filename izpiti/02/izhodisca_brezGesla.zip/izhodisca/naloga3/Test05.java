// _NE_ODSTRANI_

import java.awt.*;

public class Test05 {

    public static void main(String[] args) {

        int sirinaStolpca = 7;

        Tretja.Objava[][] objave = {
            { new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5) },
            { new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5) },
            { new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5) },
            { new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5) },
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat05.png", "720x800"});
    }
}
