
import java.util.Arrays;

public class Test09 {

    public static void main(String[] args) {
        int stIgralcev = 5;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(0, 3, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(4, 0, 2);
        portal.zabeleziPartijo(3, 4, 0);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(3, 1, 0);
        portal.zabeleziPartijo(0, 4, 0);
        portal.zabeleziPartijo(1, 4, 0);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(0, 4, 0);
        portal.zabeleziPartijo(4, 2, 1);
        portal.zabeleziPartijo(3, 0, 2);
        portal.zabeleziPartijo(3, 2, 0);
        portal.zabeleziPartijo(3, 0, 2);
        portal.zabeleziPartijo(2, 3, 0);

        System.out.println(portal.pariZRemijem());
    }
}
