
// 
// (na konec prej"snje vrstice zapi"site va"so vpisno "stevilko)

public class Druga {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }

    // po potrebi lahko dodate pomo"zne razrede ...

    //=========================================================================
    public static class Portal {

        // dodajte atribute in metode (po potrebi) ...

        //---------------------------------------------------------------------
        // V vseh testnih primerih velja stIgralcev >= 2 in stIgralcev <= 100.
        //---------------------------------------------------------------------
        public Portal(int stIgralcev) {
            // dopolnite ...
        }

        //---------------------------------------------------------------------
        // V vseh testnih primerih velja beli >= 0, beli < stIgralcev,
        // crni >= 0, crni < stIgralcev in beli != crni.
        //---------------------------------------------------------------------
        public void zabeleziPartijo(int beli, int crni, int izid) {
            // dopolnite ...
        }

        //---------------------------------------------------------------------
        public int steviloRemijev() {
            // popravite / dopolnite ...
            return -1;
        }

        //---------------------------------------------------------------------
        // V vseh testnih primerih velja igralec >= 0 in igralec < stIgralcev.
        //---------------------------------------------------------------------
        public int tocke(int igralec) {
            // popravite / dopolnite ...
            return -1;
        }

        //---------------------------------------------------------------------
        // V vseh testnih primerih velja a >= 0, a < stIgralcev,
        // b >= 0, b < stIgralcev in a != b.
        //---------------------------------------------------------------------
        public int[] medsebojneTocke(int a, int b) {
            // popravite / dopolnite ...
            return null;
        }

        //---------------------------------------------------------------------
        public int pariZRemijem() {
            // popravite / dopolnite ...
            return -1;
        }
    }
}
