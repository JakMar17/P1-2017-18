
import java.util.Arrays;

public class Test04 {

    public static void main(String[] args) {
        int stIgralcev = 2;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(1, 0, 1);

        for (int i = 0;  i < stIgralcev;  i++) {
            System.out.printf("%d -> %d%n", i, portal.tocke(i));
        }
    }
}
