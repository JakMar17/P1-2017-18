
public class Test03 {

    public static void main(String[] args) {
        int stIgralcev = 4;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(1, 2, 0);   // remi
        portal.zabeleziPartijo(3, 1, 0);   // remi
        portal.zabeleziPartijo(2, 1, 0);   // remi
        portal.zabeleziPartijo(3, 1, 2);   // zmaga "crnega
        portal.zabeleziPartijo(2, 0, 0);   // remi
        portal.zabeleziPartijo(0, 2, 1);   // zmaga belega
        portal.zabeleziPartijo(1, 3, 0);   // remi
        portal.zabeleziPartijo(3, 0, 2);   // zmaga "crnega
        portal.zabeleziPartijo(1, 2, 0);   // remi
        portal.zabeleziPartijo(1, 3, 1);   // zmaga belega

        for (int i = 0;  i < stIgralcev;  i++) {
            System.out.printf("%d -> %d%n", i, portal.tocke(i));
        }
    }
}
