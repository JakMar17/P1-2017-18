
public class Test01 {

    public static void main(String[] args) {
        int[] a = {7, 10, 8, 7, 10, 8};
        int[] b = {7, 10, 8, 20, 7, 10, 8, 20};
        int[] c = {7, 10, 8, 20, 6, 7, 10, 8};
        int[] d = {1, 2, 3, 4, 1, 2, 3, 4};
        int[] e = {1, 2, 3, 4, 2, 2, 3, 4};

        System.out.println(Prva.jePodvojena(a));
        System.out.println(Prva.jePodvojena(b));
        System.out.println(Prva.jePodvojena(c));
        System.out.println(Prva.jePodvojena(d));
        System.out.println(Prva.jePodvojena(e));
    }
}
