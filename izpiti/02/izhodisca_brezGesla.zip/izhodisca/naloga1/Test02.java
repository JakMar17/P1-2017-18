
public class Test02 {

    public static void main(String[] args) {
        int[] a = {7, 6, 7, 6, 7, 6, 7, 6, 7, 6};
        int[] b = {7, 6, 7, 6, 7, 6, 7, 6, 7, 6, 7, 6};
        int[] c = {1, 2, 3, 4, 5, 1, 2, 3, 4, 6};
        int[] d = {1, 2, 3, 4, 5, 1, 2, 3, 5, 5};
        int[] e = {1, 2, 3, 4, 5, 1, 2, 2, 3, 4};

        System.out.println(Prva.jePodvojena(a));
        System.out.println(Prva.jePodvojena(b));
        System.out.println(Prva.jePodvojena(c));
        System.out.println(Prva.jePodvojena(d));
        System.out.println(Prva.jePodvojena(e));
    }
}
