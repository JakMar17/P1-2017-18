
import java.util.Arrays;

public class Test08 {

    public static void main(String[] args) {
        int[][] a = {
            { 10,  5, 20, 42, 28},
            { 15, 23, 14, 35,  9},
            { 30,  7, 70, 63, 11},
            { 20, 10, 21, 56, 49},
        };

        System.out.println(Arrays.toString(Prva.steviloDeljivih(a, 5)));
        System.out.println(Arrays.toString(Prva.steviloDeljivih(a, 7)));
    }
}
