
public class Test03 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{94, 56, 94, 55}));
        System.out.println(Prva.jePodvojena(new int[]{43, 11, 24, 82, 46, 62, 69, 63, 43, 11, 24, 82, 46, 62, 69, 63}));
        System.out.println(Prva.jePodvojena(new int[]{77, 77}));
        System.out.println(Prva.jePodvojena(new int[]{85, 5, 85, 5}));
        System.out.println(Prva.jePodvojena(new int[]{63, 69, 68, 73, 63, 69, 80, 37}));
        System.out.println(Prva.jePodvojena(new int[]{72, 59, 4, 64, 1, 73, 84, 33, 58, 72, 59, 4, 64, 1, 73, 84, 33, 56}));
        System.out.println(Prva.jePodvojena(new int[]{67, 8}));
        System.out.println(Prva.jePodvojena(new int[]{21, 77, 23, 62, 71, 16, 50, 21, 77, 23, 62, 71, 17, 65}));
        System.out.println(Prva.jePodvojena(new int[]{33, 69, 3, 42, 64, 25, 77, 33, 69, 3, 42, 64, 25, 77}));
        System.out.println(Prva.jePodvojena(new int[]{94, 7, 86, 43, 27, 29, 78, 94, 7, 86, 9, 19, 59, 48}));
    }
}
