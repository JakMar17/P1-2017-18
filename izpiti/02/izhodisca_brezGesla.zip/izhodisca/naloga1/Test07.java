
import java.util.Arrays;

public class Test07 {

    public static void main(String[] args) {
        int[][] a = {
            {50},
            {30},
            {21},
            {40},
            {16},
            {60},
            {27},
        };

        System.out.println(Arrays.toString(Prva.steviloDeljivih(a, 2)));
        System.out.println(Arrays.toString(Prva.steviloDeljivih(a, 3)));
        System.out.println(Arrays.toString(Prva.steviloDeljivih(a, 10)));
    }
}
