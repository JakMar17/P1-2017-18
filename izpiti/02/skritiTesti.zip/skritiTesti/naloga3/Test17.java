// _NE_ODSTRANI_

public class Test17 {

    public static void main(String[] args) {

        int sirinaStolpca = 6;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(6), new Tretja.Clanek(6), new Tretja.Oglas(6), new Tretja.Clanek(6), new Tretja.Oglas(6), new Tretja.Clanek(6), new Tretja.Oglas(6), new Tretja.Clanek(6), new Tretja.Oglas(6), new Tretja.Oglas(6)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat17.png", "852x120"});

    }
}
