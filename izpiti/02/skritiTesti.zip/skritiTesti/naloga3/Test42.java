// _NE_ODSTRANI_

public class Test42 {

    public static void main(String[] args) {

        int sirinaStolpca = 1;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(5), new Tretja.Clanek(1)},
            {new Tretja.Clanek(2), new Tretja.Oglas(4)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat42.png", "480x1238"});

    }
}
