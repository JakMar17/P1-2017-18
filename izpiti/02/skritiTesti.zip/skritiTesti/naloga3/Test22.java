// _NE_ODSTRANI_

public class Test22 {

    public static void main(String[] args) {

        int sirinaStolpca = 1;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5)},
            {new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat22.png", "840x968"});

    }
}
