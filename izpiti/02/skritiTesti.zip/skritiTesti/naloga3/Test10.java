
public class Test10 {

    public static void main(String[] args) {

        int sirinaStolpca = 5;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(2), new Tretja.Oglas(4), new Tretja.Clanek(2), new Tretja.Oglas(8), new Tretja.Clanek(8)},
            {new Tretja.Oglas(10), new Tretja.Oglas(4), new Tretja.Clanek(9), new Tretja.Clanek(8), new Tretja.Oglas(4)},
            {new Tretja.Clanek(1), new Tretja.Clanek(7), new Tretja.Oglas(4), new Tretja.Oglas(8), new Tretja.Oglas(7)},
            {new Tretja.Clanek(9), new Tretja.Oglas(4), new Tretja.Oglas(8), new Tretja.Clanek(4), new Tretja.Clanek(2)},
            {new Tretja.Clanek(7), new Tretja.Oglas(7), new Tretja.Oglas(9), new Tretja.Clanek(3), new Tretja.Oglas(10)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);

        System.out.println(Platno.ri(tretja.pikNaCm(651, 483)));
        System.out.println(Platno.ri(tretja.pikNaCm(465, 697)));
        System.out.println(Platno.ri(tretja.pikNaCm(651, 321)));
    }
}
