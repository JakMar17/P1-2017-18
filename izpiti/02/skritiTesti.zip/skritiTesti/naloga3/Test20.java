// _NE_ODSTRANI_

public class Test20 {

    public static void main(String[] args) {

        int sirinaStolpca = 10;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(7), new Tretja.Oglas(7), new Tretja.Oglas(7), new Tretja.Oglas(7), new Tretja.Oglas(7), new Tretja.Oglas(7)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat20.png", "804x136"});

    }
}
