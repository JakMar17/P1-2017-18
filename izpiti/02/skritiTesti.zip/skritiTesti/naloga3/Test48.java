// _NE_ODSTRANI_

public class Test48 {

    public static void main(String[] args) {

        int sirinaStolpca = 7;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(10), new Tretja.Clanek(2), new Tretja.Clanek(6), new Tretja.Clanek(5)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Clanek(6), new Tretja.Oglas(6)},
            {new Tretja.Oglas(6), new Tretja.Clanek(6), new Tretja.Oglas(9), new Tretja.Clanek(5)},
            {new Tretja.Oglas(2), new Tretja.Oglas(3), new Tretja.Clanek(1), new Tretja.Oglas(1)},
            {new Tretja.Clanek(2), new Tretja.Clanek(8), new Tretja.Clanek(8), new Tretja.Oglas(2)},
            {new Tretja.Oglas(9), new Tretja.Clanek(2), new Tretja.Clanek(4), new Tretja.Clanek(2)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat48.png", "396x601"});

    }
}
