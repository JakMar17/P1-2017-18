// _NE_ODSTRANI_

public class Test32 {

    public static void main(String[] args) {

        int sirinaStolpca = 10;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(7), new Tretja.Oglas(8), new Tretja.Oglas(4), new Tretja.Oglas(4), new Tretja.Oglas(6), new Tretja.Oglas(1), new Tretja.Oglas(7), new Tretja.Oglas(1), new Tretja.Oglas(9), new Tretja.Oglas(10)},
            {new Tretja.Oglas(3), new Tretja.Oglas(5), new Tretja.Oglas(7), new Tretja.Oglas(8), new Tretja.Oglas(10), new Tretja.Oglas(7), new Tretja.Oglas(10), new Tretja.Oglas(8), new Tretja.Oglas(6), new Tretja.Oglas(1)},
            {new Tretja.Oglas(3), new Tretja.Oglas(1), new Tretja.Oglas(1), new Tretja.Oglas(7), new Tretja.Oglas(9), new Tretja.Oglas(5), new Tretja.Oglas(3), new Tretja.Oglas(10), new Tretja.Oglas(8), new Tretja.Oglas(1)},
            {new Tretja.Oglas(4), new Tretja.Oglas(6), new Tretja.Oglas(7), new Tretja.Oglas(6), new Tretja.Oglas(10), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(5), new Tretja.Oglas(10), new Tretja.Oglas(6)},
            {new Tretja.Oglas(9), new Tretja.Oglas(10), new Tretja.Oglas(10), new Tretja.Oglas(6), new Tretja.Oglas(10), new Tretja.Oglas(3), new Tretja.Oglas(9), new Tretja.Oglas(2), new Tretja.Oglas(2), new Tretja.Oglas(1)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat32.png", "999x523"});

    }
}
