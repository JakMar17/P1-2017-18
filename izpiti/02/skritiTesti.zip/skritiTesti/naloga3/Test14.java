// _NE_ODSTRANI_

public class Test14 {

    public static void main(String[] args) {

        int sirinaStolpca = 3;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(2), new Tretja.Oglas(2), new Tretja.Oglas(2), new Tretja.Oglas(2), new Tretja.Oglas(2)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat14.png", "945x264"});

    }
}
