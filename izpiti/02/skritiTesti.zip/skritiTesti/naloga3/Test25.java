// _NE_ODSTRANI_

public class Test25 {

    public static void main(String[] args) {

        int sirinaStolpca = 10;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat25.png", "666x236"});

    }
}
