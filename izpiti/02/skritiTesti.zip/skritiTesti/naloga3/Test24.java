// _NE_ODSTRANI_

public class Test24 {

    public static void main(String[] args) {

        int sirinaStolpca = 4;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat24.png", "615x696"});

    }
}
