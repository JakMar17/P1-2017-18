// _NE_ODSTRANI_

public class Test45 {

    public static void main(String[] args) {

        int sirinaStolpca = 8;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(8), new Tretja.Oglas(10), new Tretja.Clanek(5), new Tretja.Clanek(1)},
            {new Tretja.Oglas(7), new Tretja.Oglas(5), new Tretja.Clanek(6), new Tretja.Clanek(8)},
            {new Tretja.Oglas(4), new Tretja.Oglas(1), new Tretja.Oglas(8), new Tretja.Clanek(1)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat45.png", "444x356"});

    }
}
