// _NE_ODSTRANI_

public class Test30 {

    public static void main(String[] args) {

        int sirinaStolpca = 2;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Clanek(5)},
            {new Tretja.Clanek(5), new Tretja.Clanek(5), new Tretja.Clanek(5), new Tretja.Clanek(5)},
            {new Tretja.Oglas(5), new Tretja.Clanek(5), new Tretja.Oglas(5), new Tretja.Clanek(5)},
            {new Tretja.Clanek(5), new Tretja.Clanek(5), new Tretja.Clanek(5), new Tretja.Oglas(5)},
            {new Tretja.Clanek(5), new Tretja.Clanek(5), new Tretja.Oglas(5), new Tretja.Oglas(5)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat30.png", "195x571"});

    }
}
