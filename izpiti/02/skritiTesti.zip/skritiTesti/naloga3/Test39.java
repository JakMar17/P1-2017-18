// _NE_ODSTRANI_

public class Test39 {

    public static void main(String[] args) {

        int sirinaStolpca = 7;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(7), new Tretja.Clanek(2), new Tretja.Clanek(10)},
            {new Tretja.Oglas(3), new Tretja.Clanek(9), new Tretja.Clanek(7)},
            {new Tretja.Clanek(6), new Tretja.Oglas(1), new Tretja.Clanek(4)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat39.png", "525x661"});

    }
}
