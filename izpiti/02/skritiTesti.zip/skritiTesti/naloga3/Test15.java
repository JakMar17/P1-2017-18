// _NE_ODSTRANI_

public class Test15 {

    public static void main(String[] args) {

        int sirinaStolpca = 10;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(6), new Tretja.Oglas(6), new Tretja.Oglas(6)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat15.png", "816x192"});

    }
}
