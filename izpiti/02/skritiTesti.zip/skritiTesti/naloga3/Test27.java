// _NE_ODSTRANI_

public class Test27 {

    public static void main(String[] args) {

        int sirinaStolpca = 6;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Oglas(4), new Tretja.Oglas(4), new Tretja.Oglas(4), new Tretja.Clanek(4), new Tretja.Clanek(4)},
            {new Tretja.Oglas(4), new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Oglas(4), new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Clanek(4), new Tretja.Oglas(4)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat27.png", "704x121"});

    }
}
