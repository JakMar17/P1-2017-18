
public class Test07 {

    public static void main(String[] args) {

        int sirinaStolpca = 6;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(9), new Tretja.Oglas(4)},
            {new Tretja.Clanek(7), new Tretja.Clanek(4)},
            {new Tretja.Oglas(1), new Tretja.Clanek(6)},
            {new Tretja.Oglas(8), new Tretja.Oglas(7)},
            {new Tretja.Clanek(5), new Tretja.Oglas(10)},
            {new Tretja.Clanek(3), new Tretja.Clanek(6)},
            {new Tretja.Oglas(6), new Tretja.Oglas(7)},
            {new Tretja.Oglas(7), new Tretja.Clanek(9)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);

        System.out.println(Platno.ri(tretja.pikNaCm(630, 948)));
        System.out.println(Platno.ri(tretja.pikNaCm(270, 355)));
        System.out.println(Platno.ri(tretja.pikNaCm(960, 600)));
    }
}
