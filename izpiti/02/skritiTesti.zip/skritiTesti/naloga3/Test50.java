// _NE_ODSTRANI_

public class Test50 {

    public static void main(String[] args) {

        int sirinaStolpca = 3;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(9), new Tretja.Clanek(1)},
            {new Tretja.Clanek(3), new Tretja.Clanek(3)},
            {new Tretja.Clanek(1), new Tretja.Clanek(9)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat50.png", "126x266"});

    }
}
