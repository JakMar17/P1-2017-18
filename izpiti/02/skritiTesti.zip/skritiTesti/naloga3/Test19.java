// _NE_ODSTRANI_

public class Test19 {

    public static void main(String[] args) {

        int sirinaStolpca = 2;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(2), new Tretja.Clanek(2), new Tretja.Oglas(2), new Tretja.Clanek(2), new Tretja.Oglas(2), new Tretja.Clanek(2), new Tretja.Oglas(2), new Tretja.Clanek(2), new Tretja.Clanek(2)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat19.png", "700x107"});

    }
}
