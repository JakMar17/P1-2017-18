// _NE_ODSTRANI_

public class Test21 {

    public static void main(String[] args) {

        int sirinaStolpca = 5;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5)},
            {new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5), new Tretja.Oglas(5)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat21.png", "559x192"});

    }
}
