// _NE_ODSTRANI_

public class Test18 {

    public static void main(String[] args) {

        int sirinaStolpca = 9;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(3), new Tretja.Oglas(3), new Tretja.Oglas(3)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat18.png", "682x133"});

    }
}
