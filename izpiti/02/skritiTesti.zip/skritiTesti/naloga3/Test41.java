// _NE_ODSTRANI_

public class Test41 {

    public static void main(String[] args) {

        int sirinaStolpca = 9;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(8), new Tretja.Clanek(10), new Tretja.Clanek(10), new Tretja.Clanek(3)},
            {new Tretja.Clanek(6), new Tretja.Oglas(5), new Tretja.Clanek(10), new Tretja.Clanek(2)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat41.png", "697x512"});

    }
}
