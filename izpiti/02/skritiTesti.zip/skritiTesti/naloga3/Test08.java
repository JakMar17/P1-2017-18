
public class Test08 {

    public static void main(String[] args) {

        int sirinaStolpca = 3;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(10), new Tretja.Clanek(1), new Tretja.Clanek(6), new Tretja.Clanek(4), new Tretja.Oglas(8), new Tretja.Clanek(6), new Tretja.Oglas(6), new Tretja.Oglas(7), new Tretja.Oglas(5), new Tretja.Oglas(9)},
            {new Tretja.Oglas(7), new Tretja.Oglas(9), new Tretja.Oglas(1), new Tretja.Oglas(2), new Tretja.Clanek(7), new Tretja.Oglas(7), new Tretja.Clanek(5), new Tretja.Clanek(1), new Tretja.Clanek(6), new Tretja.Oglas(6)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);

        System.out.println(Platno.ri(tretja.pikNaCm(164, 670)));
        System.out.println(Platno.ri(tretja.pikNaCm(697, 632)));
        System.out.println(Platno.ri(tretja.pikNaCm(943, 252)));
    }
}
