// _NE_ODSTRANI_

public class Test13 {

    public static void main(String[] args) {

        int sirinaStolpca = 9;

        Tretja.Objava[][] objave = {
            {new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8), new Tretja.Oglas(8)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat13.png", "915x186"});

    }
}
