// _NE_ODSTRANI_

public class Test36 {

    public static void main(String[] args) {

        int sirinaStolpca = 10;

        Tretja.Objava[][] objave = {
            {new Tretja.Clanek(2), new Tretja.Clanek(7), new Tretja.Clanek(4)},
            {new Tretja.Oglas(6), new Tretja.Oglas(4), new Tretja.Clanek(7)},
            {new Tretja.Clanek(10), new Tretja.Oglas(7), new Tretja.Oglas(3)},
            {new Tretja.Clanek(1), new Tretja.Oglas(4), new Tretja.Oglas(8)},
        };

        Tretja tretja = new Tretja(sirinaStolpca, objave);
        tretja.sproziRisanje(new String[]{"rezultat36.png", "612x719"});

    }
}
