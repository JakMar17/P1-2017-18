
import java.util.Arrays;

public class Test32 {

    public static void main(String[] args) {
        int stIgralcev = 17;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(3, 10, 2);
        portal.zabeleziPartijo(11, 16, 0);
        portal.zabeleziPartijo(11, 9, 1);
        portal.zabeleziPartijo(10, 6, 2);
        portal.zabeleziPartijo(6, 8, 1);
        portal.zabeleziPartijo(14, 10, 0);
        portal.zabeleziPartijo(16, 15, 1);
        portal.zabeleziPartijo(9, 8, 2);
        portal.zabeleziPartijo(8, 11, 2);
        portal.zabeleziPartijo(5, 0, 1);
        portal.zabeleziPartijo(3, 0, 1);
        portal.zabeleziPartijo(5, 7, 1);
        portal.zabeleziPartijo(8, 0, 2);
        portal.zabeleziPartijo(5, 3, 2);
        portal.zabeleziPartijo(0, 6, 1);
        portal.zabeleziPartijo(9, 6, 1);
        portal.zabeleziPartijo(1, 15, 0);
        portal.zabeleziPartijo(9, 3, 2);
        portal.zabeleziPartijo(8, 13, 1);
        portal.zabeleziPartijo(13, 4, 2);
        portal.zabeleziPartijo(2, 8, 0);
        portal.zabeleziPartijo(14, 2, 1);
        portal.zabeleziPartijo(0, 10, 2);
        portal.zabeleziPartijo(7, 10, 2);
        portal.zabeleziPartijo(4, 6, 1);
        portal.zabeleziPartijo(2, 14, 2);
        portal.zabeleziPartijo(4, 3, 0);
        portal.zabeleziPartijo(4, 1, 0);
        portal.zabeleziPartijo(14, 1, 1);
        portal.zabeleziPartijo(5, 10, 1);
        portal.zabeleziPartijo(8, 5, 0);
        portal.zabeleziPartijo(3, 2, 2);
        portal.zabeleziPartijo(11, 6, 0);
        portal.zabeleziPartijo(16, 3, 2);
        portal.zabeleziPartijo(16, 8, 1);
        portal.zabeleziPartijo(6, 4, 0);
        portal.zabeleziPartijo(13, 11, 0);
        portal.zabeleziPartijo(15, 6, 0);
        portal.zabeleziPartijo(4, 0, 1);
        portal.zabeleziPartijo(16, 14, 1);
        portal.zabeleziPartijo(15, 1, 1);
        portal.zabeleziPartijo(2, 16, 0);
        portal.zabeleziPartijo(6, 5, 2);
        portal.zabeleziPartijo(10, 12, 2);
        portal.zabeleziPartijo(7, 1, 2);
        portal.zabeleziPartijo(3, 10, 1);
        portal.zabeleziPartijo(5, 0, 1);
        portal.zabeleziPartijo(7, 12, 1);
        portal.zabeleziPartijo(2, 8, 2);
        portal.zabeleziPartijo(7, 5, 0);
        portal.zabeleziPartijo(5, 16, 2);
        portal.zabeleziPartijo(13, 4, 1);
        portal.zabeleziPartijo(1, 15, 0);
        portal.zabeleziPartijo(6, 3, 0);
        portal.zabeleziPartijo(1, 16, 2);
        portal.zabeleziPartijo(11, 4, 2);
        portal.zabeleziPartijo(10, 16, 2);
        portal.zabeleziPartijo(12, 16, 1);
        portal.zabeleziPartijo(11, 13, 1);
        portal.zabeleziPartijo(12, 1, 2);
        portal.zabeleziPartijo(9, 12, 2);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(15, 5, 0);
        portal.zabeleziPartijo(6, 9, 1);
        portal.zabeleziPartijo(16, 15, 0);
        portal.zabeleziPartijo(13, 5, 0);
        portal.zabeleziPartijo(11, 10, 1);
        portal.zabeleziPartijo(11, 8, 1);
        portal.zabeleziPartijo(8, 10, 0);
        portal.zabeleziPartijo(15, 1, 1);
        portal.zabeleziPartijo(6, 9, 2);
        portal.zabeleziPartijo(8, 3, 1);
        portal.zabeleziPartijo(7, 13, 1);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(1, 12, 1);
        portal.zabeleziPartijo(16, 7, 2);
        portal.zabeleziPartijo(15, 14, 2);
        portal.zabeleziPartijo(8, 6, 0);
        portal.zabeleziPartijo(15, 0, 0);
        portal.zabeleziPartijo(2, 16, 2);
        portal.zabeleziPartijo(8, 14, 0);
        portal.zabeleziPartijo(16, 11, 2);
        portal.zabeleziPartijo(11, 15, 1);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(13, 2, 1);
        portal.zabeleziPartijo(4, 11, 2);
        portal.zabeleziPartijo(14, 8, 0);
        portal.zabeleziPartijo(8, 0, 0);
        portal.zabeleziPartijo(16, 9, 0);
        portal.zabeleziPartijo(4, 1, 0);
        portal.zabeleziPartijo(11, 12, 0);
        portal.zabeleziPartijo(6, 10, 0);
        portal.zabeleziPartijo(5, 0, 0);
        portal.zabeleziPartijo(0, 13, 1);
        portal.zabeleziPartijo(3, 9, 2);
        portal.zabeleziPartijo(9, 11, 1);
        portal.zabeleziPartijo(6, 12, 2);
        portal.zabeleziPartijo(9, 1, 0);
        portal.zabeleziPartijo(13, 1, 0);
        portal.zabeleziPartijo(6, 4, 0);
        portal.zabeleziPartijo(3, 14, 1);
        portal.zabeleziPartijo(16, 3, 2);
        portal.zabeleziPartijo(3, 15, 2);
        portal.zabeleziPartijo(13, 12, 2);
        portal.zabeleziPartijo(12, 13, 1);
        portal.zabeleziPartijo(5, 0, 2);
        portal.zabeleziPartijo(13, 5, 2);
        portal.zabeleziPartijo(7, 3, 1);
        portal.zabeleziPartijo(3, 15, 0);
        portal.zabeleziPartijo(8, 14, 0);

        for (int i = 0;  i < stIgralcev;  i++) {
            for (int j = i + 1;  j < stIgralcev;  j++) {
                System.out.printf("(%d, %d) -> %s%n", i, j, Arrays.toString(portal.medsebojneTocke(i, j)));
            }
        }
    }
}
