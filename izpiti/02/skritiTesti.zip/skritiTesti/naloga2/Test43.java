
import java.util.Arrays;

public class Test43 {

    public static void main(String[] args) {
        int stIgralcev = 20;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(2, 16, 2);
        portal.zabeleziPartijo(13, 12, 1);
        portal.zabeleziPartijo(4, 19, 2);
        portal.zabeleziPartijo(8, 19, 1);
        portal.zabeleziPartijo(3, 14, 1);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(6, 0, 0);
        portal.zabeleziPartijo(18, 12, 1);
        portal.zabeleziPartijo(13, 8, 1);
        portal.zabeleziPartijo(17, 18, 0);
        portal.zabeleziPartijo(10, 11, 0);
        portal.zabeleziPartijo(13, 19, 0);
        portal.zabeleziPartijo(9, 3, 0);
        portal.zabeleziPartijo(7, 12, 0);
        portal.zabeleziPartijo(8, 7, 2);
        portal.zabeleziPartijo(0, 6, 1);
        portal.zabeleziPartijo(13, 16, 1);
        portal.zabeleziPartijo(16, 15, 2);
        portal.zabeleziPartijo(16, 11, 1);
        portal.zabeleziPartijo(19, 0, 1);
        portal.zabeleziPartijo(6, 14, 2);
        portal.zabeleziPartijo(6, 17, 2);
        portal.zabeleziPartijo(2, 4, 0);
        portal.zabeleziPartijo(9, 15, 0);
        portal.zabeleziPartijo(14, 7, 0);
        portal.zabeleziPartijo(12, 18, 2);
        portal.zabeleziPartijo(7, 18, 0);
        portal.zabeleziPartijo(13, 1, 2);
        portal.zabeleziPartijo(19, 17, 2);
        portal.zabeleziPartijo(4, 14, 0);
        portal.zabeleziPartijo(4, 1, 2);
        portal.zabeleziPartijo(19, 17, 1);
        portal.zabeleziPartijo(7, 9, 1);
        portal.zabeleziPartijo(1, 17, 1);
        portal.zabeleziPartijo(10, 9, 1);
        portal.zabeleziPartijo(14, 18, 0);
        portal.zabeleziPartijo(17, 7, 0);
        portal.zabeleziPartijo(13, 0, 2);
        portal.zabeleziPartijo(16, 18, 0);
        portal.zabeleziPartijo(6, 4, 1);
        portal.zabeleziPartijo(12, 15, 0);
        portal.zabeleziPartijo(1, 6, 2);
        portal.zabeleziPartijo(10, 19, 1);
        portal.zabeleziPartijo(13, 8, 1);
        portal.zabeleziPartijo(12, 18, 2);
        portal.zabeleziPartijo(10, 16, 0);
        portal.zabeleziPartijo(3, 19, 0);
        portal.zabeleziPartijo(17, 16, 2);
        portal.zabeleziPartijo(18, 3, 0);
        portal.zabeleziPartijo(11, 0, 2);
        portal.zabeleziPartijo(16, 0, 2);
        portal.zabeleziPartijo(4, 15, 1);
        portal.zabeleziPartijo(9, 10, 2);
        portal.zabeleziPartijo(17, 8, 0);
        portal.zabeleziPartijo(9, 8, 1);
        portal.zabeleziPartijo(11, 12, 1);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(17, 6, 1);
        portal.zabeleziPartijo(0, 4, 2);
        portal.zabeleziPartijo(10, 11, 0);
        portal.zabeleziPartijo(7, 11, 2);
        portal.zabeleziPartijo(19, 11, 1);
        portal.zabeleziPartijo(12, 14, 1);
        portal.zabeleziPartijo(2, 10, 2);
        portal.zabeleziPartijo(8, 14, 0);
        portal.zabeleziPartijo(15, 18, 0);
        portal.zabeleziPartijo(6, 10, 2);

        System.out.println(portal.pariZRemijem());
    }
}
