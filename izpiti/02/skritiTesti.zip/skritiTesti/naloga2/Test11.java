
import java.util.Arrays;

public class Test11 {

    public static void main(String[] args) {
        int stIgralcev = 10;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(3, 5, 0);
        portal.zabeleziPartijo(9, 8, 0);
        portal.zabeleziPartijo(4, 2, 1);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(5, 8, 2);
        portal.zabeleziPartijo(5, 4, 2);
        portal.zabeleziPartijo(3, 6, 2);
        portal.zabeleziPartijo(4, 9, 0);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(2, 6, 1);
        portal.zabeleziPartijo(6, 8, 0);
        portal.zabeleziPartijo(5, 4, 0);
        portal.zabeleziPartijo(0, 8, 1);
        portal.zabeleziPartijo(8, 6, 2);
        portal.zabeleziPartijo(4, 8, 1);
        portal.zabeleziPartijo(6, 8, 0);
        portal.zabeleziPartijo(4, 5, 1);
        portal.zabeleziPartijo(5, 7, 1);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(1, 3, 0);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(4, 8, 0);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(5, 8, 0);
        portal.zabeleziPartijo(3, 8, 1);
        portal.zabeleziPartijo(3, 4, 2);
        portal.zabeleziPartijo(5, 4, 2);
        portal.zabeleziPartijo(8, 1, 2);
        portal.zabeleziPartijo(2, 9, 1);
        portal.zabeleziPartijo(9, 3, 1);
        portal.zabeleziPartijo(6, 8, 0);
        portal.zabeleziPartijo(0, 6, 1);
        portal.zabeleziPartijo(7, 9, 0);
        portal.zabeleziPartijo(3, 4, 1);
        portal.zabeleziPartijo(9, 1, 1);
        portal.zabeleziPartijo(3, 9, 0);
        portal.zabeleziPartijo(8, 2, 0);
        portal.zabeleziPartijo(9, 1, 1);
        portal.zabeleziPartijo(7, 6, 0);
        portal.zabeleziPartijo(0, 3, 1);
        portal.zabeleziPartijo(4, 0, 1);
        portal.zabeleziPartijo(9, 8, 2);
        portal.zabeleziPartijo(7, 2, 0);

        System.out.println(portal.steviloRemijev());
    }
}
