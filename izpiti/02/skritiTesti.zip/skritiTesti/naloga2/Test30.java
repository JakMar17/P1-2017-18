
import java.util.Arrays;

public class Test30 {

    public static void main(String[] args) {
        int stIgralcev = 5;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(4, 3, 2);
        portal.zabeleziPartijo(0, 3, 1);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(3, 2, 1);
        portal.zabeleziPartijo(1, 3, 2);
        portal.zabeleziPartijo(4, 1, 0);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(1, 4, 2);
        portal.zabeleziPartijo(4, 2, 2);
        portal.zabeleziPartijo(0, 4, 0);
        portal.zabeleziPartijo(2, 4, 2);
        portal.zabeleziPartijo(0, 3, 0);
        portal.zabeleziPartijo(3, 2, 1);
        portal.zabeleziPartijo(3, 1, 0);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(4, 3, 2);
        portal.zabeleziPartijo(1, 4, 0);
        portal.zabeleziPartijo(2, 4, 2);
        portal.zabeleziPartijo(1, 3, 2);
        portal.zabeleziPartijo(3, 4, 0);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(1, 4, 1);
        portal.zabeleziPartijo(4, 3, 1);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(3, 2, 0);
        portal.zabeleziPartijo(3, 2, 0);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(2, 4, 2);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(4, 0, 1);
        portal.zabeleziPartijo(0, 4, 2);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(0, 3, 2);

        for (int i = 0;  i < stIgralcev;  i++) {
            for (int j = i + 1;  j < stIgralcev;  j++) {
                System.out.printf("(%d, %d) -> %s%n", i, j, Arrays.toString(portal.medsebojneTocke(i, j)));
            }
        }
    }
}
