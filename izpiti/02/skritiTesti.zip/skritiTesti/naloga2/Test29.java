
import java.util.Arrays;

public class Test29 {

    public static void main(String[] args) {
        int stIgralcev = 10;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(5, 3, 0);
        portal.zabeleziPartijo(8, 4, 2);
        portal.zabeleziPartijo(8, 3, 1);
        portal.zabeleziPartijo(8, 3, 2);
        portal.zabeleziPartijo(2, 5, 1);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(1, 8, 0);
        portal.zabeleziPartijo(3, 9, 2);
        portal.zabeleziPartijo(7, 2, 0);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(6, 0, 2);
        portal.zabeleziPartijo(4, 1, 1);
        portal.zabeleziPartijo(9, 3, 0);
        portal.zabeleziPartijo(4, 2, 2);
        portal.zabeleziPartijo(8, 2, 2);
        portal.zabeleziPartijo(5, 4, 1);
        portal.zabeleziPartijo(2, 8, 1);
        portal.zabeleziPartijo(8, 0, 2);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(8, 6, 2);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(7, 1, 1);
        portal.zabeleziPartijo(4, 6, 1);
        portal.zabeleziPartijo(4, 6, 2);
        portal.zabeleziPartijo(4, 5, 0);
        portal.zabeleziPartijo(2, 4, 2);
        portal.zabeleziPartijo(9, 8, 1);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(9, 5, 1);
        portal.zabeleziPartijo(9, 6, 0);
        portal.zabeleziPartijo(9, 5, 1);
        portal.zabeleziPartijo(4, 6, 0);
        portal.zabeleziPartijo(6, 9, 0);
        portal.zabeleziPartijo(0, 7, 1);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(5, 4, 0);
        portal.zabeleziPartijo(5, 8, 0);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(4, 7, 2);
        portal.zabeleziPartijo(7, 8, 0);
        portal.zabeleziPartijo(8, 0, 2);
        portal.zabeleziPartijo(2, 3, 1);
        portal.zabeleziPartijo(9, 8, 1);
        portal.zabeleziPartijo(0, 9, 1);
        portal.zabeleziPartijo(6, 0, 1);
        portal.zabeleziPartijo(6, 0, 0);
        portal.zabeleziPartijo(7, 9, 1);
        portal.zabeleziPartijo(8, 9, 2);
        portal.zabeleziPartijo(4, 5, 1);
        portal.zabeleziPartijo(4, 8, 2);
        portal.zabeleziPartijo(5, 0, 2);
        portal.zabeleziPartijo(7, 0, 0);
        portal.zabeleziPartijo(8, 7, 2);
        portal.zabeleziPartijo(6, 1, 0);
        portal.zabeleziPartijo(5, 3, 2);
        portal.zabeleziPartijo(6, 8, 2);
        portal.zabeleziPartijo(4, 6, 0);
        portal.zabeleziPartijo(6, 9, 0);
        portal.zabeleziPartijo(0, 7, 1);
        portal.zabeleziPartijo(3, 5, 1);
        portal.zabeleziPartijo(1, 4, 2);
        portal.zabeleziPartijo(3, 5, 1);
        portal.zabeleziPartijo(2, 8, 2);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(4, 9, 1);
        portal.zabeleziPartijo(6, 3, 0);
        portal.zabeleziPartijo(8, 7, 1);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(7, 2, 1);
        portal.zabeleziPartijo(1, 3, 1);
        portal.zabeleziPartijo(8, 9, 1);
        portal.zabeleziPartijo(7, 5, 0);
        portal.zabeleziPartijo(2, 3, 1);
        portal.zabeleziPartijo(4, 3, 1);
        portal.zabeleziPartijo(9, 8, 0);
        portal.zabeleziPartijo(4, 1, 0);
        portal.zabeleziPartijo(9, 2, 0);
        portal.zabeleziPartijo(7, 2, 1);
        portal.zabeleziPartijo(4, 6, 2);
        portal.zabeleziPartijo(1, 4, 0);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(7, 3, 2);
        portal.zabeleziPartijo(5, 3, 0);
        portal.zabeleziPartijo(7, 9, 0);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(2, 6, 1);
        portal.zabeleziPartijo(8, 1, 0);
        portal.zabeleziPartijo(6, 9, 1);
        portal.zabeleziPartijo(4, 6, 0);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(3, 8, 0);
        portal.zabeleziPartijo(8, 7, 1);
        portal.zabeleziPartijo(4, 3, 2);
        portal.zabeleziPartijo(9, 5, 2);
        portal.zabeleziPartijo(4, 2, 1);
        portal.zabeleziPartijo(5, 1, 2);
        portal.zabeleziPartijo(2, 5, 1);
        portal.zabeleziPartijo(3, 4, 2);
        portal.zabeleziPartijo(2, 9, 2);
        portal.zabeleziPartijo(9, 5, 1);
        portal.zabeleziPartijo(4, 5, 1);
        portal.zabeleziPartijo(6, 3, 0);
        portal.zabeleziPartijo(6, 5, 0);
        portal.zabeleziPartijo(4, 1, 2);

        for (int i = 0;  i < stIgralcev;  i++) {
            for (int j = i + 1;  j < stIgralcev;  j++) {
                System.out.printf("(%d, %d) -> %s%n", i, j, Arrays.toString(portal.medsebojneTocke(i, j)));
            }
        }
    }
}
