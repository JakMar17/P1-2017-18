
import java.util.Arrays;

public class Test38 {

    public static void main(String[] args) {
        int stIgralcev = 10;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(0, 6, 1);
        portal.zabeleziPartijo(9, 6, 0);
        portal.zabeleziPartijo(7, 5, 1);
        portal.zabeleziPartijo(2, 7, 2);
        portal.zabeleziPartijo(7, 1, 0);
        portal.zabeleziPartijo(0, 9, 2);
        portal.zabeleziPartijo(5, 2, 2);
        portal.zabeleziPartijo(8, 2, 0);
        portal.zabeleziPartijo(5, 9, 1);
        portal.zabeleziPartijo(5, 6, 1);
        portal.zabeleziPartijo(0, 4, 2);
        portal.zabeleziPartijo(6, 4, 2);
        portal.zabeleziPartijo(1, 9, 0);
        portal.zabeleziPartijo(8, 1, 1);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(3, 7, 2);
        portal.zabeleziPartijo(9, 8, 2);
        portal.zabeleziPartijo(9, 3, 1);
        portal.zabeleziPartijo(9, 0, 2);
        portal.zabeleziPartijo(7, 3, 0);
        portal.zabeleziPartijo(7, 8, 2);
        portal.zabeleziPartijo(6, 3, 2);
        portal.zabeleziPartijo(7, 1, 1);
        portal.zabeleziPartijo(4, 0, 0);
        portal.zabeleziPartijo(4, 1, 0);
        portal.zabeleziPartijo(4, 7, 0);
        portal.zabeleziPartijo(8, 3, 2);
        portal.zabeleziPartijo(9, 3, 1);
        portal.zabeleziPartijo(3, 7, 1);
        portal.zabeleziPartijo(9, 1, 1);
        portal.zabeleziPartijo(6, 9, 0);
        portal.zabeleziPartijo(9, 7, 1);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(9, 3, 2);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(6, 8, 0);
        portal.zabeleziPartijo(5, 7, 1);
        portal.zabeleziPartijo(6, 0, 0);
        portal.zabeleziPartijo(2, 9, 2);
        portal.zabeleziPartijo(6, 1, 0);
        portal.zabeleziPartijo(2, 3, 0);
        portal.zabeleziPartijo(0, 6, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(6, 5, 0);
        portal.zabeleziPartijo(2, 4, 2);
        portal.zabeleziPartijo(9, 3, 2);
        portal.zabeleziPartijo(2, 8, 1);
        portal.zabeleziPartijo(5, 6, 0);
        portal.zabeleziPartijo(5, 3, 1);
        portal.zabeleziPartijo(6, 1, 0);
        portal.zabeleziPartijo(2, 8, 0);
        portal.zabeleziPartijo(8, 0, 0);
        portal.zabeleziPartijo(4, 3, 2);
        portal.zabeleziPartijo(7, 0, 2);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(5, 3, 2);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(2, 6, 1);
        portal.zabeleziPartijo(0, 4, 0);
        portal.zabeleziPartijo(6, 5, 0);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(7, 9, 2);
        portal.zabeleziPartijo(1, 8, 2);
        portal.zabeleziPartijo(6, 4, 2);
        portal.zabeleziPartijo(4, 2, 0);
        portal.zabeleziPartijo(0, 6, 1);
        portal.zabeleziPartijo(4, 9, 1);
        portal.zabeleziPartijo(5, 8, 2);
        portal.zabeleziPartijo(9, 3, 1);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(8, 7, 2);
        portal.zabeleziPartijo(2, 6, 0);
        portal.zabeleziPartijo(4, 7, 2);

        System.out.println(portal.pariZRemijem());
    }
}
