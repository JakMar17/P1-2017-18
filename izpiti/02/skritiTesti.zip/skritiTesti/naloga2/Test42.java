
import java.util.Arrays;

public class Test42 {

    public static void main(String[] args) {
        int stIgralcev = 13;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(6, 4, 0);
        portal.zabeleziPartijo(7, 10, 2);
        portal.zabeleziPartijo(4, 7, 2);
        portal.zabeleziPartijo(2, 11, 0);
        portal.zabeleziPartijo(8, 10, 2);
        portal.zabeleziPartijo(0, 6, 2);
        portal.zabeleziPartijo(10, 1, 2);
        portal.zabeleziPartijo(11, 1, 1);
        portal.zabeleziPartijo(12, 2, 0);
        portal.zabeleziPartijo(8, 7, 1);
        portal.zabeleziPartijo(0, 4, 0);
        portal.zabeleziPartijo(7, 11, 2);
        portal.zabeleziPartijo(7, 1, 2);
        portal.zabeleziPartijo(11, 6, 0);
        portal.zabeleziPartijo(6, 10, 1);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(3, 4, 0);
        portal.zabeleziPartijo(12, 1, 1);
        portal.zabeleziPartijo(6, 7, 1);
        portal.zabeleziPartijo(8, 6, 1);
        portal.zabeleziPartijo(2, 9, 0);
        portal.zabeleziPartijo(1, 3, 2);
        portal.zabeleziPartijo(9, 7, 2);
        portal.zabeleziPartijo(7, 1, 0);
        portal.zabeleziPartijo(12, 9, 0);
        portal.zabeleziPartijo(1, 10, 0);
        portal.zabeleziPartijo(1, 6, 1);
        portal.zabeleziPartijo(7, 6, 2);
        portal.zabeleziPartijo(5, 6, 1);
        portal.zabeleziPartijo(9, 4, 2);
        portal.zabeleziPartijo(10, 5, 2);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(2, 5, 2);
        portal.zabeleziPartijo(2, 6, 2);
        portal.zabeleziPartijo(8, 9, 2);
        portal.zabeleziPartijo(11, 2, 2);
        portal.zabeleziPartijo(6, 10, 2);
        portal.zabeleziPartijo(8, 9, 2);
        portal.zabeleziPartijo(7, 11, 1);
        portal.zabeleziPartijo(6, 9, 0);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(5, 6, 1);
        portal.zabeleziPartijo(8, 9, 1);
        portal.zabeleziPartijo(1, 3, 0);
        portal.zabeleziPartijo(8, 2, 1);
        portal.zabeleziPartijo(8, 6, 2);
        portal.zabeleziPartijo(1, 4, 0);
        portal.zabeleziPartijo(4, 11, 1);
        portal.zabeleziPartijo(2, 6, 1);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(10, 3, 1);
        portal.zabeleziPartijo(7, 1, 2);
        portal.zabeleziPartijo(3, 6, 0);
        portal.zabeleziPartijo(10, 7, 2);
        portal.zabeleziPartijo(4, 12, 0);

        System.out.println(portal.pariZRemijem());
    }
}
