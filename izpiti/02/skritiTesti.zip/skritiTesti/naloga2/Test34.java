
import java.util.Arrays;

public class Test34 {

    public static void main(String[] args) {
        int stIgralcev = 15;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(4, 6, 0);
        portal.zabeleziPartijo(8, 5, 0);
        portal.zabeleziPartijo(8, 0, 0);
        portal.zabeleziPartijo(7, 8, 2);
        portal.zabeleziPartijo(14, 1, 2);
        portal.zabeleziPartijo(3, 13, 1);
        portal.zabeleziPartijo(8, 7, 2);
        portal.zabeleziPartijo(5, 3, 0);
        portal.zabeleziPartijo(4, 13, 2);
        portal.zabeleziPartijo(8, 6, 1);
        portal.zabeleziPartijo(13, 4, 1);
        portal.zabeleziPartijo(13, 4, 2);
        portal.zabeleziPartijo(12, 4, 2);
        portal.zabeleziPartijo(13, 7, 1);
        portal.zabeleziPartijo(11, 12, 0);
        portal.zabeleziPartijo(11, 0, 0);
        portal.zabeleziPartijo(14, 9, 1);
        portal.zabeleziPartijo(11, 7, 0);
        portal.zabeleziPartijo(7, 2, 2);
        portal.zabeleziPartijo(6, 12, 1);
        portal.zabeleziPartijo(9, 5, 1);
        portal.zabeleziPartijo(5, 8, 1);
        portal.zabeleziPartijo(2, 9, 1);
        portal.zabeleziPartijo(4, 11, 1);
        portal.zabeleziPartijo(11, 3, 0);
        portal.zabeleziPartijo(12, 6, 2);
        portal.zabeleziPartijo(9, 13, 0);
        portal.zabeleziPartijo(6, 13, 0);
        portal.zabeleziPartijo(1, 8, 1);
        portal.zabeleziPartijo(13, 10, 1);
        portal.zabeleziPartijo(3, 6, 1);
        portal.zabeleziPartijo(5, 8, 0);
        portal.zabeleziPartijo(12, 9, 1);
        portal.zabeleziPartijo(14, 6, 1);
        portal.zabeleziPartijo(3, 10, 1);
        portal.zabeleziPartijo(11, 4, 1);
        portal.zabeleziPartijo(3, 10, 2);
        portal.zabeleziPartijo(5, 8, 0);
        portal.zabeleziPartijo(2, 6, 0);
        portal.zabeleziPartijo(0, 11, 2);
        portal.zabeleziPartijo(3, 13, 0);
        portal.zabeleziPartijo(7, 8, 0);
        portal.zabeleziPartijo(0, 3, 1);
        portal.zabeleziPartijo(10, 1, 1);
        portal.zabeleziPartijo(3, 14, 0);
        portal.zabeleziPartijo(10, 14, 0);
        portal.zabeleziPartijo(8, 7, 1);
        portal.zabeleziPartijo(5, 14, 2);
        portal.zabeleziPartijo(11, 7, 1);
        portal.zabeleziPartijo(0, 8, 0);
        portal.zabeleziPartijo(5, 14, 2);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(0, 5, 2);
        portal.zabeleziPartijo(14, 5, 2);
        portal.zabeleziPartijo(1, 14, 1);
        portal.zabeleziPartijo(14, 6, 0);
        portal.zabeleziPartijo(10, 12, 2);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(5, 8, 1);
        portal.zabeleziPartijo(7, 3, 2);
        portal.zabeleziPartijo(2, 14, 2);
        portal.zabeleziPartijo(8, 6, 0);
        portal.zabeleziPartijo(11, 12, 1);
        portal.zabeleziPartijo(11, 12, 0);
        portal.zabeleziPartijo(11, 6, 1);
        portal.zabeleziPartijo(4, 9, 2);
        portal.zabeleziPartijo(13, 14, 2);
        portal.zabeleziPartijo(9, 8, 1);
        portal.zabeleziPartijo(11, 5, 0);
        portal.zabeleziPartijo(9, 12, 0);
        portal.zabeleziPartijo(1, 14, 2);
        portal.zabeleziPartijo(7, 8, 0);
        portal.zabeleziPartijo(5, 3, 1);
        portal.zabeleziPartijo(11, 0, 2);
        portal.zabeleziPartijo(4, 9, 0);
        portal.zabeleziPartijo(6, 14, 1);
        portal.zabeleziPartijo(14, 4, 1);
        portal.zabeleziPartijo(4, 14, 2);
        portal.zabeleziPartijo(10, 12, 1);
        portal.zabeleziPartijo(7, 0, 1);
        portal.zabeleziPartijo(4, 14, 1);
        portal.zabeleziPartijo(0, 14, 1);
        portal.zabeleziPartijo(12, 9, 2);
        portal.zabeleziPartijo(5, 7, 0);
        portal.zabeleziPartijo(2, 7, 1);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(3, 4, 0);
        portal.zabeleziPartijo(11, 9, 1);
        portal.zabeleziPartijo(2, 3, 1);
        portal.zabeleziPartijo(5, 9, 0);
        portal.zabeleziPartijo(1, 5, 0);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(13, 2, 0);
        portal.zabeleziPartijo(2, 10, 1);
        portal.zabeleziPartijo(1, 7, 0);
        portal.zabeleziPartijo(1, 14, 2);
        portal.zabeleziPartijo(10, 8, 2);
        portal.zabeleziPartijo(9, 3, 2);
        portal.zabeleziPartijo(2, 12, 0);
        portal.zabeleziPartijo(12, 8, 1);

        for (int i = 0;  i < stIgralcev;  i++) {
            for (int j = i + 1;  j < stIgralcev;  j++) {
                System.out.printf("(%d, %d) -> %s%n", i, j, Arrays.toString(portal.medsebojneTocke(i, j)));
            }
        }
    }
}
