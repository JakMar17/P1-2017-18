
import java.util.Arrays;

public class Test03 {

    public static void main(String[] args) {
        int stIgralcev = 19;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(6, 16, 2);
        portal.zabeleziPartijo(0, 18, 2);
        portal.zabeleziPartijo(13, 11, 2);
        portal.zabeleziPartijo(15, 18, 2);
        portal.zabeleziPartijo(5, 11, 1);
        portal.zabeleziPartijo(5, 2, 2);
        portal.zabeleziPartijo(3, 16, 2);
        portal.zabeleziPartijo(10, 14, 2);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(0, 9, 0);
        portal.zabeleziPartijo(10, 18, 2);
        portal.zabeleziPartijo(17, 12, 0);
        portal.zabeleziPartijo(3, 18, 0);
        portal.zabeleziPartijo(11, 4, 0);
        portal.zabeleziPartijo(18, 5, 1);
        portal.zabeleziPartijo(6, 8, 1);
        portal.zabeleziPartijo(10, 18, 2);
        portal.zabeleziPartijo(5, 8, 2);
        portal.zabeleziPartijo(16, 4, 1);
        portal.zabeleziPartijo(1, 6, 0);
        portal.zabeleziPartijo(18, 2, 1);
        portal.zabeleziPartijo(10, 16, 1);
        portal.zabeleziPartijo(17, 7, 1);
        portal.zabeleziPartijo(1, 15, 0);
        portal.zabeleziPartijo(17, 7, 1);
        portal.zabeleziPartijo(6, 0, 0);
        portal.zabeleziPartijo(0, 13, 2);
        portal.zabeleziPartijo(11, 17, 2);
        portal.zabeleziPartijo(16, 12, 2);
        portal.zabeleziPartijo(15, 5, 2);
        portal.zabeleziPartijo(12, 0, 1);
        portal.zabeleziPartijo(11, 1, 2);
        portal.zabeleziPartijo(13, 3, 1);
        portal.zabeleziPartijo(18, 16, 2);
        portal.zabeleziPartijo(7, 9, 0);
        portal.zabeleziPartijo(12, 18, 2);
        portal.zabeleziPartijo(4, 13, 0);
        portal.zabeleziPartijo(6, 8, 0);
        portal.zabeleziPartijo(7, 6, 2);
        portal.zabeleziPartijo(12, 7, 1);
        portal.zabeleziPartijo(2, 17, 0);
        portal.zabeleziPartijo(16, 17, 0);
        portal.zabeleziPartijo(3, 11, 1);
        portal.zabeleziPartijo(5, 14, 2);
        portal.zabeleziPartijo(11, 4, 2);
        portal.zabeleziPartijo(14, 2, 2);
        portal.zabeleziPartijo(2, 14, 0);
        portal.zabeleziPartijo(2, 8, 1);
        portal.zabeleziPartijo(12, 6, 0);
        portal.zabeleziPartijo(10, 14, 1);
        portal.zabeleziPartijo(9, 3, 0);
        portal.zabeleziPartijo(4, 6, 2);
        portal.zabeleziPartijo(16, 11, 0);
        portal.zabeleziPartijo(1, 4, 1);
        portal.zabeleziPartijo(5, 8, 2);
        portal.zabeleziPartijo(18, 3, 0);
        portal.zabeleziPartijo(5, 1, 2);
        portal.zabeleziPartijo(1, 17, 0);
        portal.zabeleziPartijo(15, 3, 0);
        portal.zabeleziPartijo(10, 13, 0);
        portal.zabeleziPartijo(15, 8, 1);
        portal.zabeleziPartijo(1, 10, 1);
        portal.zabeleziPartijo(14, 8, 0);
        portal.zabeleziPartijo(4, 3, 2);

        System.out.println(portal.steviloRemijev());
    }
}
