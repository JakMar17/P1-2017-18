
import java.util.Arrays;

public class Test08 {

    public static void main(String[] args) {
        int stIgralcev = 17;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(11, 3, 0);
        portal.zabeleziPartijo(7, 8, 0);
        portal.zabeleziPartijo(6, 4, 1);
        portal.zabeleziPartijo(3, 11, 1);
        portal.zabeleziPartijo(4, 6, 0);
        portal.zabeleziPartijo(4, 13, 2);
        portal.zabeleziPartijo(7, 15, 1);
        portal.zabeleziPartijo(3, 16, 2);
        portal.zabeleziPartijo(0, 10, 1);
        portal.zabeleziPartijo(3, 12, 0);
        portal.zabeleziPartijo(11, 13, 0);
        portal.zabeleziPartijo(16, 13, 0);
        portal.zabeleziPartijo(7, 2, 2);
        portal.zabeleziPartijo(4, 15, 1);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(10, 2, 1);
        portal.zabeleziPartijo(15, 16, 0);
        portal.zabeleziPartijo(10, 14, 1);
        portal.zabeleziPartijo(14, 11, 1);
        portal.zabeleziPartijo(5, 3, 1);
        portal.zabeleziPartijo(3, 2, 2);
        portal.zabeleziPartijo(15, 6, 1);
        portal.zabeleziPartijo(8, 15, 0);
        portal.zabeleziPartijo(5, 0, 2);
        portal.zabeleziPartijo(5, 7, 0);
        portal.zabeleziPartijo(11, 10, 1);
        portal.zabeleziPartijo(9, 4, 1);
        portal.zabeleziPartijo(11, 2, 0);
        portal.zabeleziPartijo(8, 1, 0);
        portal.zabeleziPartijo(8, 12, 0);
        portal.zabeleziPartijo(8, 11, 0);
        portal.zabeleziPartijo(7, 13, 0);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(7, 14, 2);
        portal.zabeleziPartijo(0, 5, 0);
        portal.zabeleziPartijo(9, 14, 2);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(7, 11, 1);
        portal.zabeleziPartijo(6, 2, 2);
        portal.zabeleziPartijo(5, 14, 0);
        portal.zabeleziPartijo(4, 13, 0);
        portal.zabeleziPartijo(3, 7, 1);
        portal.zabeleziPartijo(8, 3, 2);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(13, 6, 0);
        portal.zabeleziPartijo(2, 5, 1);
        portal.zabeleziPartijo(9, 5, 2);
        portal.zabeleziPartijo(3, 0, 0);

        System.out.println(portal.steviloRemijev());
    }
}
