
import java.util.Arrays;

public class Test09 {

    public static void main(String[] args) {
        int stIgralcev = 4;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(3, 2, 2);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(2, 3, 0);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(3, 0, 2);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(2, 3, 2);
        portal.zabeleziPartijo(1, 3, 2);
        portal.zabeleziPartijo(3, 2, 1);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(3, 0, 0);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(0, 3, 0);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(3, 1, 1);
        portal.zabeleziPartijo(0, 3, 0);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(3, 2, 1);
        portal.zabeleziPartijo(0, 3, 1);
        portal.zabeleziPartijo(1, 3, 0);
        portal.zabeleziPartijo(2, 0, 1);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(3, 2, 0);
        portal.zabeleziPartijo(0, 3, 0);
        portal.zabeleziPartijo(2, 3, 1);
        portal.zabeleziPartijo(2, 0, 1);

        System.out.println(portal.steviloRemijev());
    }
}
