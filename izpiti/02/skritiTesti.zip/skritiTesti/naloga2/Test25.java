
import java.util.Arrays;

public class Test25 {

    public static void main(String[] args) {
        int stIgralcev = 20;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(2, 11, 1);
        portal.zabeleziPartijo(14, 13, 0);
        portal.zabeleziPartijo(4, 1, 2);
        portal.zabeleziPartijo(14, 6, 1);
        portal.zabeleziPartijo(12, 3, 2);
        portal.zabeleziPartijo(0, 9, 0);
        portal.zabeleziPartijo(14, 0, 0);
        portal.zabeleziPartijo(7, 17, 2);
        portal.zabeleziPartijo(16, 17, 0);
        portal.zabeleziPartijo(11, 0, 0);
        portal.zabeleziPartijo(16, 3, 1);
        portal.zabeleziPartijo(1, 3, 2);
        portal.zabeleziPartijo(10, 7, 2);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(3, 19, 2);
        portal.zabeleziPartijo(9, 13, 1);
        portal.zabeleziPartijo(2, 9, 0);
        portal.zabeleziPartijo(16, 10, 0);
        portal.zabeleziPartijo(15, 9, 2);
        portal.zabeleziPartijo(9, 6, 2);
        portal.zabeleziPartijo(9, 7, 0);
        portal.zabeleziPartijo(9, 15, 0);
        portal.zabeleziPartijo(4, 6, 1);
        portal.zabeleziPartijo(12, 1, 2);
        portal.zabeleziPartijo(2, 16, 0);
        portal.zabeleziPartijo(16, 2, 2);
        portal.zabeleziPartijo(0, 16, 1);
        portal.zabeleziPartijo(13, 3, 1);
        portal.zabeleziPartijo(17, 4, 0);
        portal.zabeleziPartijo(1, 0, 0);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(8, 6, 1);
        portal.zabeleziPartijo(4, 9, 2);
        portal.zabeleziPartijo(19, 1, 0);
        portal.zabeleziPartijo(18, 8, 0);
        portal.zabeleziPartijo(3, 19, 0);
        portal.zabeleziPartijo(17, 9, 0);
        portal.zabeleziPartijo(3, 14, 0);
        portal.zabeleziPartijo(16, 6, 1);
        portal.zabeleziPartijo(16, 19, 2);
        portal.zabeleziPartijo(15, 5, 2);
        portal.zabeleziPartijo(16, 12, 0);

        for (int i = 0;  i < stIgralcev;  i++) {
            System.out.printf("%d -> %d%n", i, portal.tocke(i));
        }
    }
}
