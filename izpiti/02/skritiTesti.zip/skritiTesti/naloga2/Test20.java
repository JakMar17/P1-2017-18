
import java.util.Arrays;

public class Test20 {

    public static void main(String[] args) {
        int stIgralcev = 16;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(3, 15, 2);
        portal.zabeleziPartijo(14, 3, 2);
        portal.zabeleziPartijo(1, 3, 1);
        portal.zabeleziPartijo(10, 7, 2);
        portal.zabeleziPartijo(15, 3, 2);
        portal.zabeleziPartijo(7, 1, 2);
        portal.zabeleziPartijo(15, 9, 0);
        portal.zabeleziPartijo(11, 2, 1);
        portal.zabeleziPartijo(12, 10, 1);
        portal.zabeleziPartijo(14, 6, 1);
        portal.zabeleziPartijo(2, 14, 0);
        portal.zabeleziPartijo(15, 4, 1);
        portal.zabeleziPartijo(3, 2, 2);
        portal.zabeleziPartijo(2, 14, 2);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(1, 10, 2);
        portal.zabeleziPartijo(5, 10, 2);
        portal.zabeleziPartijo(3, 10, 1);
        portal.zabeleziPartijo(11, 6, 1);
        portal.zabeleziPartijo(1, 4, 0);
        portal.zabeleziPartijo(8, 15, 1);
        portal.zabeleziPartijo(13, 1, 1);
        portal.zabeleziPartijo(10, 11, 1);
        portal.zabeleziPartijo(14, 15, 2);
        portal.zabeleziPartijo(11, 13, 0);
        portal.zabeleziPartijo(11, 15, 2);
        portal.zabeleziPartijo(6, 9, 2);
        portal.zabeleziPartijo(9, 12, 0);
        portal.zabeleziPartijo(5, 10, 0);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(6, 1, 0);
        portal.zabeleziPartijo(14, 4, 2);
        portal.zabeleziPartijo(0, 4, 0);
        portal.zabeleziPartijo(6, 1, 2);
        portal.zabeleziPartijo(14, 10, 2);
        portal.zabeleziPartijo(4, 15, 2);
        portal.zabeleziPartijo(15, 8, 1);
        portal.zabeleziPartijo(2, 6, 2);
        portal.zabeleziPartijo(5, 3, 2);
        portal.zabeleziPartijo(5, 11, 2);
        portal.zabeleziPartijo(8, 2, 0);
        portal.zabeleziPartijo(10, 5, 1);
        portal.zabeleziPartijo(15, 14, 2);
        portal.zabeleziPartijo(4, 7, 0);
        portal.zabeleziPartijo(0, 9, 1);
        portal.zabeleziPartijo(0, 13, 1);
        portal.zabeleziPartijo(1, 7, 2);
        portal.zabeleziPartijo(8, 6, 1);
        portal.zabeleziPartijo(3, 2, 1);
        portal.zabeleziPartijo(0, 15, 2);
        portal.zabeleziPartijo(9, 6, 0);
        portal.zabeleziPartijo(9, 7, 2);
        portal.zabeleziPartijo(2, 11, 0);
        portal.zabeleziPartijo(13, 3, 1);
        portal.zabeleziPartijo(4, 8, 2);
        portal.zabeleziPartijo(13, 15, 0);
        portal.zabeleziPartijo(8, 9, 0);

        for (int i = 0;  i < stIgralcev;  i++) {
            System.out.printf("%d -> %d%n", i, portal.tocke(i));
        }
    }
}
