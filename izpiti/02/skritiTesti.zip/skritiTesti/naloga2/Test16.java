
import java.util.Arrays;

public class Test16 {

    public static void main(String[] args) {
        int stIgralcev = 9;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(4, 7, 2);
        portal.zabeleziPartijo(5, 1, 2);
        portal.zabeleziPartijo(2, 8, 0);
        portal.zabeleziPartijo(0, 5, 0);
        portal.zabeleziPartijo(0, 3, 1);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(2, 6, 1);
        portal.zabeleziPartijo(8, 3, 0);
        portal.zabeleziPartijo(8, 3, 0);
        portal.zabeleziPartijo(6, 3, 1);
        portal.zabeleziPartijo(4, 0, 1);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(0, 6, 1);
        portal.zabeleziPartijo(0, 6, 0);
        portal.zabeleziPartijo(7, 2, 0);
        portal.zabeleziPartijo(8, 4, 1);
        portal.zabeleziPartijo(2, 7, 1);
        portal.zabeleziPartijo(8, 3, 0);
        portal.zabeleziPartijo(1, 8, 1);
        portal.zabeleziPartijo(6, 0, 1);
        portal.zabeleziPartijo(4, 0, 0);
        portal.zabeleziPartijo(4, 2, 0);
        portal.zabeleziPartijo(8, 5, 0);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(3, 4, 2);
        portal.zabeleziPartijo(8, 4, 0);
        portal.zabeleziPartijo(5, 6, 1);
        portal.zabeleziPartijo(5, 4, 0);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(8, 6, 2);
        portal.zabeleziPartijo(1, 7, 0);
        portal.zabeleziPartijo(5, 3, 2);
        portal.zabeleziPartijo(1, 8, 1);
        portal.zabeleziPartijo(2, 6, 2);
        portal.zabeleziPartijo(2, 3, 2);
        portal.zabeleziPartijo(2, 4, 0);
        portal.zabeleziPartijo(6, 8, 2);
        portal.zabeleziPartijo(8, 3, 1);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(6, 4, 0);
        portal.zabeleziPartijo(4, 6, 2);

        for (int i = 0;  i < stIgralcev;  i++) {
            System.out.printf("%d -> %d%n", i, portal.tocke(i));
        }
    }
}
