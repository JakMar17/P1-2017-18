
import java.util.Arrays;

public class Test12 {

    public static void main(String[] args) {
        int stIgralcev = 3;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(1, 2, 2);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(2, 0, 1);
        portal.zabeleziPartijo(2, 0, 1);
        portal.zabeleziPartijo(2, 0, 2);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(0, 1, 2);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(1, 0, 2);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(2, 1, 0);
        portal.zabeleziPartijo(2, 0, 1);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(0, 2, 1);
        portal.zabeleziPartijo(0, 2, 2);
        portal.zabeleziPartijo(1, 0, 1);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(0, 1, 0);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(2, 0, 0);
        portal.zabeleziPartijo(2, 1, 2);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(0, 2, 0);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(2, 1, 0);

        System.out.println(portal.steviloRemijev());
    }
}
