
import java.util.Arrays;

public class Test40 {

    public static void main(String[] args) {
        int stIgralcev = 6;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(1, 5, 2);
        portal.zabeleziPartijo(4, 3, 1);
        portal.zabeleziPartijo(1, 5, 0);
        portal.zabeleziPartijo(4, 0, 0);
        portal.zabeleziPartijo(0, 3, 1);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(0, 4, 2);
        portal.zabeleziPartijo(1, 4, 0);
        portal.zabeleziPartijo(5, 4, 2);
        portal.zabeleziPartijo(0, 4, 2);
        portal.zabeleziPartijo(1, 2, 1);
        portal.zabeleziPartijo(1, 2, 0);
        portal.zabeleziPartijo(5, 2, 0);
        portal.zabeleziPartijo(5, 4, 2);
        portal.zabeleziPartijo(2, 5, 0);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(4, 2, 2);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(3, 5, 1);
        portal.zabeleziPartijo(4, 3, 2);
        portal.zabeleziPartijo(5, 1, 2);
        portal.zabeleziPartijo(5, 3, 1);
        portal.zabeleziPartijo(0, 3, 2);
        portal.zabeleziPartijo(5, 3, 2);
        portal.zabeleziPartijo(2, 5, 0);
        portal.zabeleziPartijo(2, 3, 2);
        portal.zabeleziPartijo(3, 5, 2);
        portal.zabeleziPartijo(4, 1, 2);
        portal.zabeleziPartijo(1, 3, 2);

        System.out.println(portal.pariZRemijem());
    }
}
