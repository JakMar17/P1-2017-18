
import java.util.Arrays;

public class Test26 {

    public static void main(String[] args) {
        int stIgralcev = 17;
        Druga.Portal portal = new Druga.Portal(stIgralcev);

        portal.zabeleziPartijo(1, 3, 1);
        portal.zabeleziPartijo(1, 6, 1);
        portal.zabeleziPartijo(14, 7, 1);
        portal.zabeleziPartijo(15, 7, 0);
        portal.zabeleziPartijo(4, 10, 1);
        portal.zabeleziPartijo(8, 1, 0);
        portal.zabeleziPartijo(3, 9, 2);
        portal.zabeleziPartijo(11, 6, 2);
        portal.zabeleziPartijo(15, 13, 2);
        portal.zabeleziPartijo(14, 2, 1);
        portal.zabeleziPartijo(16, 13, 2);
        portal.zabeleziPartijo(14, 12, 0);
        portal.zabeleziPartijo(12, 3, 2);
        portal.zabeleziPartijo(10, 3, 0);
        portal.zabeleziPartijo(16, 12, 2);
        portal.zabeleziPartijo(7, 1, 0);
        portal.zabeleziPartijo(14, 1, 0);
        portal.zabeleziPartijo(15, 0, 2);
        portal.zabeleziPartijo(9, 4, 2);
        portal.zabeleziPartijo(0, 4, 1);
        portal.zabeleziPartijo(10, 5, 1);
        portal.zabeleziPartijo(5, 12, 0);
        portal.zabeleziPartijo(10, 12, 2);
        portal.zabeleziPartijo(8, 10, 1);
        portal.zabeleziPartijo(11, 7, 0);
        portal.zabeleziPartijo(14, 2, 0);
        portal.zabeleziPartijo(4, 2, 2);
        portal.zabeleziPartijo(4, 16, 0);
        portal.zabeleziPartijo(4, 5, 2);
        portal.zabeleziPartijo(3, 1, 2);
        portal.zabeleziPartijo(16, 12, 1);
        portal.zabeleziPartijo(14, 2, 1);
        portal.zabeleziPartijo(16, 15, 0);
        portal.zabeleziPartijo(4, 14, 0);
        portal.zabeleziPartijo(11, 6, 2);
        portal.zabeleziPartijo(14, 7, 0);
        portal.zabeleziPartijo(13, 3, 2);
        portal.zabeleziPartijo(9, 1, 0);
        portal.zabeleziPartijo(5, 14, 1);
        portal.zabeleziPartijo(4, 9, 2);
        portal.zabeleziPartijo(15, 4, 1);
        portal.zabeleziPartijo(11, 4, 0);
        portal.zabeleziPartijo(3, 10, 1);
        portal.zabeleziPartijo(5, 13, 2);
        portal.zabeleziPartijo(13, 4, 1);
        portal.zabeleziPartijo(14, 11, 2);
        portal.zabeleziPartijo(0, 1, 1);
        portal.zabeleziPartijo(8, 14, 1);
        portal.zabeleziPartijo(11, 10, 0);
        portal.zabeleziPartijo(12, 10, 2);
        portal.zabeleziPartijo(2, 13, 1);
        portal.zabeleziPartijo(15, 10, 0);
        portal.zabeleziPartijo(15, 7, 2);
        portal.zabeleziPartijo(2, 0, 1);
        portal.zabeleziPartijo(12, 7, 1);
        portal.zabeleziPartijo(8, 3, 1);
        portal.zabeleziPartijo(3, 2, 2);
        portal.zabeleziPartijo(0, 16, 1);
        portal.zabeleziPartijo(14, 12, 2);
        portal.zabeleziPartijo(7, 14, 2);
        portal.zabeleziPartijo(13, 15, 1);
        portal.zabeleziPartijo(2, 1, 1);
        portal.zabeleziPartijo(8, 13, 2);
        portal.zabeleziPartijo(12, 10, 1);

        for (int i = 0;  i < stIgralcev;  i++) {
            for (int j = i + 1;  j < stIgralcev;  j++) {
                System.out.printf("(%d, %d) -> %s%n", i, j, Arrays.toString(portal.medsebojneTocke(i, j)));
            }
        }
    }
}
