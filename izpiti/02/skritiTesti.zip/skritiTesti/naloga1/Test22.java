
import java.util.Arrays;

public class Test22 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{89, 45, 89, 45}));
        System.out.println(Prva.jePodvojena(new int[]{89, 97, 63, 42, 89, 97, 63, 42}));
        System.out.println(Prva.jePodvojena(new int[]{74, 89, 5, 16, 78, 55, 3, 44, 31, 45, 74, 89, 5, 16, 78, 55, 3, 44, 31, 45}));
        System.out.println(Prva.jePodvojena(new int[]{29, 29, 93, 40, 38, 43, 36, 49, 78, 48, 74, 22}));
        System.out.println(Prva.jePodvojena(new int[]{58, 4, 87, 58, 4, 49}));
        System.out.println(Prva.jePodvojena(new int[]{39, 32, 76, 55, 91, 47, 88, 59, 20, 78, 39, 32, 76, 55, 91, 47, 88, 59, 84, 48}));
        System.out.println(Prva.jePodvojena(new int[]{86, 64, 4, 86, 64, 4}));
        System.out.println(Prva.jePodvojena(new int[]{82, 26, 62, 94}));
        System.out.println(Prva.jePodvojena(new int[]{92, 72, 40, 6, 99, 27, 10, 15, 66, 28, 92, 72, 40, 6, 99, 27, 10, 15, 66, 28}));
        System.out.println(Prva.jePodvojena(new int[]{53, 77, 43, 31, 81, 53, 77, 43, 31, 81}));
    }
}
