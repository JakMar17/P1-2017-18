
import java.util.Arrays;

public class Test30 {

    public static void main(String[] args) {
        int[][] t = {
            {8305, 2732, 2400, 1030, 2304, 7672, 3441, 2400, 1536, 2923, 9408, 5664, 8493, 5952, 9443, 7488,  768, 7488, 7104},
        };
        System.out.println(Arrays.toString(Prva.steviloDeljivih(t, 96)));
    }
}
