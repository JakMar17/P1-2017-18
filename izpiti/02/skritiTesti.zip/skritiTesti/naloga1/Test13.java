
import java.util.Arrays;

public class Test13 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{2, 85, 26, 57, 17, 95, 15, 77, 2, 85, 26, 57, 17, 42, 63, 99}));
        System.out.println(Prva.jePodvojena(new int[]{89, 52, 42, 66, 34, 6, 57, 97, 26, 89, 52, 61, 58, 23, 58, 48, 26, 9}));
        System.out.println(Prva.jePodvojena(new int[]{96, 59, 16, 63, 69, 80, 44, 96, 59, 16, 63, 69, 80, 44}));
        System.out.println(Prva.jePodvojena(new int[]{78, 61, 38, 38, 78, 77, 88, 57}));
        System.out.println(Prva.jePodvojena(new int[]{41, 36, 63, 54, 70, 61, 41, 36, 63, 70, 6, 46}));
        System.out.println(Prva.jePodvojena(new int[]{74, 31, 56, 54, 46, 30, 47, 28, 74, 31, 56, 54, 46, 30, 47, 28}));
        System.out.println(Prva.jePodvojena(new int[]{47, 17, 51, 51, 30, 34, 47, 17, 51, 51, 83, 8}));
        System.out.println(Prva.jePodvojena(new int[]{51, 54, 68, 22, 95, 9, 13, 51, 54, 68, 22, 95, 9, 13}));
        System.out.println(Prva.jePodvojena(new int[]{70, 49, 20, 58, 35, 98, 80, 88, 32, 70, 49, 20, 58, 35, 98, 80, 88, 32}));
        System.out.println(Prva.jePodvojena(new int[]{11, 11}));
    }
}
