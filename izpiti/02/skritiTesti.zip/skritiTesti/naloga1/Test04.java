
import java.util.Arrays;

public class Test04 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{61, 15, 100, 40, 22, 74, 38, 21, 83, 56, 83, 33, 1, 85}));
        System.out.println(Prva.jePodvojena(new int[]{97, 84, 89, 4, 62, 66, 45, 37, 97, 84, 89, 4, 62, 66, 45, 37}));
        System.out.println(Prva.jePodvojena(new int[]{99, 16, 35, 37, 84, 48, 24, 20, 99, 16, 35, 37, 84, 48, 24, 20}));
        System.out.println(Prva.jePodvojena(new int[]{76, 51, 83, 22, 23, 78, 75, 16, 51, 2, 45, 86, 35, 63, 77, 41}));
        System.out.println(Prva.jePodvojena(new int[]{88, 48, 1, 87, 45, 63, 45, 84, 11, 81, 75, 46, 12, 3, 12, 50}));
        System.out.println(Prva.jePodvojena(new int[]{16, 92, 69, 84, 51, 13, 97, 74, 16, 92, 69, 84, 51, 13, 97, 74}));
        System.out.println(Prva.jePodvojena(new int[]{77, 86, 70, 77, 86, 70}));
        System.out.println(Prva.jePodvojena(new int[]{3, 72, 77, 67, 55, 50, 13, 87, 58, 95, 3, 72, 77, 67, 55, 50, 13, 87, 58, 95}));
        System.out.println(Prva.jePodvojena(new int[]{90, 21, 62, 93, 81, 68, 90, 21, 62, 93, 81, 68}));
        System.out.println(Prva.jePodvojena(new int[]{39, 53, 30, 39, 89, 72, 6, 20, 68, 92}));
    }
}
