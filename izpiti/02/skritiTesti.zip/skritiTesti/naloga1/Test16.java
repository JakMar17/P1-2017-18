
import java.util.Arrays;

public class Test16 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{91, 65, 91, 65}));
        System.out.println(Prva.jePodvojena(new int[]{51, 72, 90, 79, 92, 22, 51, 72, 90, 3, 46, 19}));
        System.out.println(Prva.jePodvojena(new int[]{62, 79, 89, 23, 59, 29, 35, 16, 62, 79, 89, 34, 15, 76, 31, 36}));
        System.out.println(Prva.jePodvojena(new int[]{75, 65, 75, 46}));
        System.out.println(Prva.jePodvojena(new int[]{55, 3, 74, 90, 98, 22, 32, 63, 55, 3, 74, 90, 98, 22, 32, 63}));
        System.out.println(Prva.jePodvojena(new int[]{19, 42, 1, 20, 18, 19, 42, 1, 44, 94}));
        System.out.println(Prva.jePodvojena(new int[]{17, 95, 25, 17, 95, 25}));
        System.out.println(Prva.jePodvojena(new int[]{100, 100}));
        System.out.println(Prva.jePodvojena(new int[]{82, 93, 38, 65, 75, 88, 14, 3, 82, 93, 38, 65, 75, 88, 14, 3}));
        System.out.println(Prva.jePodvojena(new int[]{53, 68, 78, 53, 15, 32, 98, 16, 54, 63, 53, 68, 78, 53, 15, 32, 98, 16, 54, 63}));
    }
}
