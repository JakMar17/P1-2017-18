
import java.util.Arrays;

public class Test10 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{54, 35, 38, 55, 1, 72, 53, 10, 3, 17}));
        System.out.println(Prva.jePodvojena(new int[]{68, 57, 100, 17, 68, 57, 28, 90}));
        System.out.println(Prva.jePodvojena(new int[]{50, 7, 41, 99, 28, 58, 53, 60, 20, 94, 50, 7, 41, 99, 28, 58, 53, 60, 20, 94}));
        System.out.println(Prva.jePodvojena(new int[]{58, 96, 23, 3, 3, 38, 6, 32, 26, 87, 58, 96, 23, 3, 3, 38, 6, 32, 26, 87}));
        System.out.println(Prva.jePodvojena(new int[]{54, 20, 14, 27, 9, 81, 11, 54, 20, 14, 27, 9, 81, 11}));
        System.out.println(Prva.jePodvojena(new int[]{9, 9}));
        System.out.println(Prva.jePodvojena(new int[]{32, 32, 73, 45, 54, 57}));
        System.out.println(Prva.jePodvojena(new int[]{1, 37, 91, 97, 71, 1, 37, 91, 97, 45}));
        System.out.println(Prva.jePodvojena(new int[]{21, 84, 82, 27, 89, 54, 5, 20, 23, 76, 21, 84, 82, 27, 89, 54, 5, 20, 23, 76}));
        System.out.println(Prva.jePodvojena(new int[]{87, 87}));
    }
}
