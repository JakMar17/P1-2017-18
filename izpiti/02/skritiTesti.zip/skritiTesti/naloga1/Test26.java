
import java.util.Arrays;

public class Test26 {

    public static void main(String[] args) {
        int[][] t = {
            {2507, 1944, 5103, 1701, 2268, 7695, 2916, 4374, 5383, 6642,  972, 4050, 3553, 3163, 5508, 6723, 5872, 4131, 3251, 4536, 3969, 3888, 4212, 8100, 1112, 4941, 5913,  891, 3969,  777, 6687, 1819, 6931, 1003, 5346, 6804, 5659, 6842, 3564, 7695, 3807, 2590,  567, 2754, 6254, 4698, 1525},
        };
        System.out.println(Arrays.toString(Prva.steviloDeljivih(t, 81)));
    }
}
