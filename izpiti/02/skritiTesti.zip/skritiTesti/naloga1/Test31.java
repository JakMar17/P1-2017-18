
import java.util.Arrays;

public class Test31 {

    public static void main(String[] args) {
        int[][] t = {
            {1692},
            {1800},
            {2040},
            {1904},
            {1980},
            {1205},
            {1170},
            {2100},
            {1027},
            {1879},
            { 687},
            {  51},
            { 510},
            {  61},
            {1423},
            { 367},
            { 810},
            { 390},
            {1260},
            { 978},
            { 878},
            { 884},
            {1320},
            { 120},
            {2948},
        };
        System.out.println(Arrays.toString(Prva.steviloDeljivih(t, 30)));
    }
}
