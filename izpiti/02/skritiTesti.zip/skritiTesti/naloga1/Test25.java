
import java.util.Arrays;

public class Test25 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{32, 2, 56, 73, 16, 88, 83, 31, 66, 62, 32, 2, 66, 37, 74, 88, 14, 26, 69, 10}));
        System.out.println(Prva.jePodvojena(new int[]{72, 41, 75, 26, 60, 71}));
        System.out.println(Prva.jePodvojena(new int[]{99, 28, 87, 77, 12, 87, 95, 34, 100, 99, 28, 87, 77, 12, 33, 61, 21, 82}));
        System.out.println(Prva.jePodvojena(new int[]{68, 37, 69, 94, 11, 41, 68, 37, 69, 94, 11, 41}));
        System.out.println(Prva.jePodvojena(new int[]{44, 67, 11, 68, 59, 44, 60, 89, 74, 39}));
        System.out.println(Prva.jePodvojena(new int[]{68, 39, 35, 68, 39, 35}));
        System.out.println(Prva.jePodvojena(new int[]{20, 15, 62, 61, 65, 31, 66, 33, 20, 15, 62, 61, 65, 31, 66, 33}));
        System.out.println(Prva.jePodvojena(new int[]{82, 78, 95, 81, 19, 84, 82, 100, 57, 40, 59, 79}));
        System.out.println(Prva.jePodvojena(new int[]{16, 97, 96, 100, 35, 2, 87, 53, 4, 16, 97, 96, 100, 35, 2, 87, 53, 4}));
        System.out.println(Prva.jePodvojena(new int[]{27, 11, 40, 71, 6, 27, 11, 40, 71, 6}));
    }
}
