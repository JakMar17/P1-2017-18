
import java.util.Arrays;

public class Test07 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{6, 28, 89, 6, 43, 61}));
        System.out.println(Prva.jePodvojena(new int[]{86, 15, 75, 50, 83, 98, 38, 38, 53, 86, 15, 75, 50, 83, 98, 38, 38, 4}));
        System.out.println(Prva.jePodvojena(new int[]{16, 75, 61, 39, 81, 75, 6, 29, 36, 87, 16, 75, 61, 39, 62, 41, 21, 57, 15, 67}));
        System.out.println(Prva.jePodvojena(new int[]{99, 62, 3, 28, 99, 62, 3, 96}));
        System.out.println(Prva.jePodvojena(new int[]{34, 34}));
        System.out.println(Prva.jePodvojena(new int[]{91, 52, 17, 47, 47, 17, 12, 50, 89, 91, 52, 17, 47, 47, 17, 12, 50, 89}));
        System.out.println(Prva.jePodvojena(new int[]{78, 44, 90, 24, 42, 92, 87, 95, 32, 8, 78, 44, 90, 24, 42, 92, 87, 95, 32, 8}));
        System.out.println(Prva.jePodvojena(new int[]{58, 42, 67, 40, 24, 30, 98, 91, 3, 58, 42, 67, 40, 99, 31, 1, 26, 83}));
        System.out.println(Prva.jePodvojena(new int[]{37, 29}));
        System.out.println(Prva.jePodvojena(new int[]{24, 85, 14, 16, 37, 71, 78, 56, 24, 85, 14, 16, 37, 71, 78, 56}));
    }
}
