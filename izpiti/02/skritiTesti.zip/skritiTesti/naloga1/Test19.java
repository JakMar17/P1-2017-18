
import java.util.Arrays;

public class Test19 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{9, 32, 42, 4, 93, 78, 75, 16, 28, 9, 9, 32, 37, 94, 93, 31, 49, 64, 31, 30}));
        System.out.println(Prva.jePodvojena(new int[]{25, 25}));
        System.out.println(Prva.jePodvojena(new int[]{2, 3, 2, 3}));
        System.out.println(Prva.jePodvojena(new int[]{40, 47, 100, 70, 60, 40, 3, 63, 14, 67}));
        System.out.println(Prva.jePodvojena(new int[]{60, 55, 62, 70, 77, 81, 27, 52, 62, 60, 55, 62, 70, 77, 81, 27, 52, 62}));
        System.out.println(Prva.jePodvojena(new int[]{75, 75}));
        System.out.println(Prva.jePodvojena(new int[]{53, 60, 53, 60}));
        System.out.println(Prva.jePodvojena(new int[]{34, 37, 61, 23, 100, 91, 55, 55, 22, 34, 37, 61, 23, 100, 91, 55, 55, 22}));
        System.out.println(Prva.jePodvojena(new int[]{25, 25}));
        System.out.println(Prva.jePodvojena(new int[]{42, 56, 36, 24, 85, 42, 56, 36, 24, 85}));
    }
}
