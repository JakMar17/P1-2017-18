
import java.util.Arrays;

public class Test01 {

    public static void main(String[] args) {
        System.out.println(Prva.jePodvojena(new int[]{86, 43, 90, 13, 90, 40}));
        System.out.println(Prva.jePodvojena(new int[]{56, 52, 30, 78, 11, 96, 63, 61, 46, 64, 29, 24, 1, 5}));
        System.out.println(Prva.jePodvojena(new int[]{50, 12, 36, 20, 48, 88, 57, 31, 52, 29, 99, 45}));
        System.out.println(Prva.jePodvojena(new int[]{3, 68, 55, 69, 52, 91, 59, 45, 19, 76, 100, 33, 98, 11, 96, 32}));
        System.out.println(Prva.jePodvojena(new int[]{56, 66, 40, 57, 98, 1, 62, 96, 42, 99, 89, 51, 79, 84, 94, 58, 80, 69, 86, 9}));
        System.out.println(Prva.jePodvojena(new int[]{44, 75, 82, 79, 49, 15, 45, 7, 47, 20, 16, 91, 39, 58, 94, 2, 21, 37, 23, 51}));
        System.out.println(Prva.jePodvojena(new int[]{67, 55, 47, 12, 75, 23, 87, 95, 66, 94, 13, 64, 17, 52}));
        System.out.println(Prva.jePodvojena(new int[]{76, 72, 9, 68, 76, 72, 9, 68}));
        System.out.println(Prva.jePodvojena(new int[]{55, 24, 66, 73, 69, 38, 69, 14, 67, 49, 45, 15, 52, 1, 87, 58}));
        System.out.println(Prva.jePodvojena(new int[]{89, 41}));
    }
}
