
import java.util.Arrays;

public class Test32 {

    public static void main(String[] args) {
        int[][] t = {
            {  98},
            { 249},
            { 208},
            {  76},
            { 491},
            { 181},
            { 126},
            { 293},
        };
        System.out.println(Arrays.toString(Prva.steviloDeljivih(t, 8)));
    }
}
