
import java.util.Arrays;

public class Test29 {

    public static void main(String[] args) {
        int[][] t = {
            {1056,  280, 2967, 1946, 3176,  105, 1054, 2755},
        };
        System.out.println(Arrays.toString(Prva.steviloDeljivih(t, 40)));
    }
}
