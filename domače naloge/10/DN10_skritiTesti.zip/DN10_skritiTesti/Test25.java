
public class Test25 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Mnogokotnik(new int[][]{{39, 23, -4917}, {-2, 51, -4444}, {-44, 21, -880}, {-8, -3, 140}, {-1, -2, 50}, {7, -11, -325}, {11, -2, -954}});
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
