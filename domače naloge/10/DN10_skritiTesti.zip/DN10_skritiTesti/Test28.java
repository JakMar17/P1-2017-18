
public class Test28 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Presek(new Oddaja.Elipsa(51, 54, 36, 42), new Oddaja.Mnogokotnik(new int[][]{{42, 37, -5993}, {0, 1, -95}, {-8, 11, -733}, {-53, -6, 744}, {-11, -13, 366}, {-4, -39, 373}, {9, -8, -552}, {1, 0, -96}}));
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
