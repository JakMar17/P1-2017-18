
public class Test48 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Presek(new Oddaja.Mnogokotnik(new int[][]{{24, 23, -3772}, {4, 27, -2760}, {-6, 17, -1380}, {-37, 24, -1235}, {-35, -11, 618}, {-5, -7, 186}, {5, -41, -42}, {4, -3, -272}, {32, 3, -3148}}), new Oddaja.Elipsa(49, 54, 34, 23));
        risar.narisiRob(lik, 5);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
