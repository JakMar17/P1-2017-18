
public class Test23 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Mnogokotnik(new int[][]{{13, 72, -6426}, {-4, 1, -14}, {-29, -39, 1286}, {47, -53, -1968}, {25, 6, -2688}});
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
