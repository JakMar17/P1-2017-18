
public class Test47 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Razlika(new Oddaja.Pravokotnik(29, 2, 69, 96), new Oddaja.Mnogokotnik(new int[][]{{13, 11, -1973}, {-1, 7, -523}, {-40, 7, -172}, {-22, -13, 512}, {-6, -23, 412}, {39, -35, -2309}, {16, 3, -1659}}));
        risar.narisiRob(lik, 3);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
