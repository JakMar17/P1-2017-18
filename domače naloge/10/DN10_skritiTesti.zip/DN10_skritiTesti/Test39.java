
public class Test39 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Presek(new Oddaja.Elipsa(45, 52, 42, 27), new Oddaja.Elipsa(50, 50, 31, 46));
        risar.narisiRob(lik, 1);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
