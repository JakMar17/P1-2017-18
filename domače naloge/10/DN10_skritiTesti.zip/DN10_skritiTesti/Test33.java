
public class Test33 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Razlika(new Oddaja.Razlika(new Oddaja.Mnogokotnik(new int[][]{{17, 38, -4447}, {-17, 36, -2657}, {-37, 10, -383}, {-30, -17, 744}, {-1, -3, 54}, {38, -45, -1893}, {40, 11, -4269}}), new Oddaja.Elipsa(51, 58, 45, 31)), new Oddaja.Mnogokotnik(new int[][]{{3, 22, -1974}, {-40, 19, -853}, {-45, -38, 1831}, {11, -42, -345}, {13, -1, -1040}}));
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
