
public class Test27 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Presek(new Oddaja.Pravokotnik(1, 8, 91, 54), new Oddaja.Mnogokotnik(new int[][]{{7, 38, -3876}, {-1, 1, -57}, {-48, -19, 1150}, {-3, -5, 110}, {21, -67, -56}, {15, 4, -1492}}));
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
