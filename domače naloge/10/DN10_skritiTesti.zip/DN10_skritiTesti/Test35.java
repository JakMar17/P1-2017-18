
public class Test35 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Razlika(new Oddaja.Presek(new Oddaja.Elipsa(49, 67, 47, 31), new Oddaja.Mnogokotnik(new int[][]{{2, 1, -244}, {1, 4, -423}, {-17, 28, -2025}, {-12, 5, -263}, {-47, -22, 1257}, {-7, -22, 337}, {1, -9, -36}, {14, -11, -849}, {1, 0, -96}})), new Oddaja.Presek(new Oddaja.Pravokotnik(6, 6, 86, 78), new Oddaja.Mnogokotnik(new int[][]{{37, 30, -5232}, {-9, 50, -4056}, {-11, 7, -412}, {-20, 1, -22}, {-41, -42, 1805}, {1, -8, -35}, {11, -12, -689}, {6, -1, -520}})));
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
