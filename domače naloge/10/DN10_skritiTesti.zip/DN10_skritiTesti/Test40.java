
public class Test40 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Razlika(new Oddaja.Pravokotnik(3, 21, 91, 65), new Oddaja.Mnogokotnik(new int[][]{{14, 75, -6524}, {-45, 14, -456}, {-17, -33, 1321}, {65, -23, -4305}}));
        risar.narisiRob(lik, 1);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
