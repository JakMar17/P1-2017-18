
public class Test24 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Mnogokotnik(new int[][]{{11, 13, -1926}, {-1, 10, -876}, {-58, 21, -498}, {-31, -36, 1245}, {1, -3, -36}, {28, -3, -2304}});
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
