
public class Test30 {

    public static void main(String[] args) {
        Oddaja.Risar risar = new Oddaja.Risar();
        Oddaja.Lik lik = new Oddaja.Presek(new Oddaja.Presek(new Oddaja.Mnogokotnik(new int[][]{{-81, 7, 1550}, {12, -37, 130}, {57, 67, -7636}}), new Oddaja.Mnogokotnik(new int[][]{{1, 38, -3564}, {-46, -9, 2217}, {0, -1, 1}, {13, -2, -700}})), new Oddaja.Mnogokotnik(new int[][]{{1, 5, -523}, {-58, 41, -1442}, {-3, -5, 196}, {1, -2, -58}, {82, 1, -6076}}));
        risar.narisiLik(lik);
        narisi(risar.slika());
    }

    private static void narisi(boolean[][] slika) {
        for (int i = 0;  i < slika.length;  i++) {
            for (int j = 0;  j < slika[i].length;  j++) {
                System.out.print(slika[i][j] ? "* " : "- ");
            }
            System.out.println();
        }
    }
}
