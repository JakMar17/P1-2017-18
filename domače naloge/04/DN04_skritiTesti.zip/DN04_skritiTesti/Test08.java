public class Test08 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(81, 92);
        System.out.println(s.kapacitetaKupa(81));
        System.out.println(s.kapacitetaKupa(29));
        System.out.println(s.kapacitetaKupa(66));
        System.out.println(s.kapacitetaKupa(7));
        System.out.println(s.kapacitetaKupa(62));
        System.out.println(s.kapacitetaKupa(55));
    }
}
