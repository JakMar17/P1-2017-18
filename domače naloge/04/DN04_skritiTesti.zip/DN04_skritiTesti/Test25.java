public class Test25 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(98, 85);
        s.dodaj(32);
        s.dodaj(65);
        s.dodaj(54);
        s.dodaj(17);
        s.dodaj(47);
        s.dodaj(12);
        s.dodaj(33);
        s.dodaj(48);
        s.dodaj(36);
        s.dodaj(88);
        System.out.println(s.zasedenostKupa(1));
        System.out.println(s.zasedenostKupa(2));
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
        System.out.println(s.zasedenostKupa(5));
    }
}
