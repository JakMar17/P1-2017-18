public class Test14 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(83, 3);
        s.dodaj(12);
        s.dodaj(15);
        s.dodaj(30);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
