public class Test27 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(38, 86);
        s.dodaj(113);
        s.dodaj(636);
        s.dodaj(296);
        s.dodaj(49);
        s.dodaj(977);
        s.dodaj(974);
        System.out.println(s.zasedenostKupa(7));
        System.out.println(s.zasedenostKupa(8));
        System.out.println(s.zasedenostKupa(9));
        System.out.println(s.zasedenostKupa(10));
        System.out.println(s.zasedenostKupa(11));
    }
}
