public class Test16 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(17, 0);
        s.dodaj(12);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
