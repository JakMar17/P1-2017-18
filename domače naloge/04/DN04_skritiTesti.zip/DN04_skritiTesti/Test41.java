public class Test41 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(42, 0);
        s.dodaj(42239);
        Skladovnica t = s.prestavi(1, 81);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
