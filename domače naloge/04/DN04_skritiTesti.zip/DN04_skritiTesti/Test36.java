public class Test36 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(65, 0);
        s.dodaj(8061);
        System.out.println(s.poisciKup(6714));
        System.out.println(s.poisciKup(2870));
        System.out.println(s.poisciKup(884));
        System.out.println(s.poisciKup(6984));
        System.out.println(s.poisciKup(1610));
        System.out.println(s.poisciKup(875));
        System.out.println(s.poisciKup(4388));
        System.out.println(s.poisciKup(2189));
        System.out.println(s.poisciKup(5943));
        System.out.println(s.poisciKup(6942));
    }
}
