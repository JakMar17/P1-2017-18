public class Test30 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(96, 58);
        s.dodaj(38);
        s.dodaj(27);
        s.dodaj(99);
        s.dodaj(21);
        s.dodaj(74);
        s.dodaj(80);
        s.dodaj(49);
        s.dodaj(77);
        s.dodaj(20);
        s.dodaj(64);
        s.dodaj(81);
        s.dodaj(88);
        s.dodaj(20);
        s.dodaj(80);
        s.dodaj(52);
        s.dodaj(64);
        s.dodaj(91);
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
        System.out.println(s.zasedenostKupa(5));
        System.out.println(s.zasedenostKupa(6));
        System.out.println(s.zasedenostKupa(7));
    }
}
