public class Test49 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(62, 46);
        s.dodaj(1317);
        Skladovnica t = s.prestavi(74, 93);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
