public class Test18 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(16, 90);
        s.dodaj(11);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
