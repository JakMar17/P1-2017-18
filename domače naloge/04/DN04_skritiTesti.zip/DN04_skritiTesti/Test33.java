public class Test33 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(40, 48);
        s.dodaj(7320);
        s.dodaj(4584);
        s.dodaj(3892);
        s.dodaj(4351);
        s.dodaj(3293);
        s.dodaj(2724);
        s.dodaj(3430);
        s.dodaj(9481);
        s.dodaj(7199);
        System.out.println(s.zasedenostKupa(42));
        System.out.println(s.zasedenostKupa(43));
        System.out.println(s.zasedenostKupa(44));
        System.out.println(s.zasedenostKupa(45));
        System.out.println(s.zasedenostKupa(46));
        System.out.println(s.odvzemi(9567));
        System.out.println(s.odvzemi(3991));
        System.out.println(s.odvzemi(8654));
        System.out.println(s.odvzemi(3809));
        System.out.println(s.odvzemi(1637));
        System.out.println(s.odvzemi(5001));
        System.out.println(s.odvzemi(3518));
        System.out.println(s.odvzemi(8827));
        System.out.println(s.odvzemi(9606));
        System.out.println(s.skupnoSteviloSkatel());
        System.out.println(s.zasedenostKupa(5));
        System.out.println(s.zasedenostKupa(6));
        System.out.println(s.zasedenostKupa(7));
        System.out.println(s.zasedenostKupa(8));
        System.out.println(s.zasedenostKupa(9));
    }
}
