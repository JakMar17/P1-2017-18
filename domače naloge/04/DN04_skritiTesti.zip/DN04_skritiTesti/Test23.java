public class Test23 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(36, 72);
        s.dodaj(15);
        s.dodaj(1);
        s.dodaj(11);
        s.dodaj(2);
        s.dodaj(17);
        s.dodaj(18);
        s.dodaj(21);
        s.dodaj(19);
        s.dodaj(19);
        s.dodaj(34);
        s.dodaj(8);
        s.dodaj(11);
        s.dodaj(35);
        s.dodaj(9);
        s.dodaj(7);
        s.dodaj(14);
        System.out.println(s.zasedenostKupa(1));
        System.out.println(s.zasedenostKupa(2));
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
        System.out.println(s.zasedenostKupa(5));
    }
}
