public class Test07 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(70, 99);
        System.out.println(s.kapacitetaKupa(52));
        System.out.println(s.kapacitetaKupa(83));
        System.out.println(s.kapacitetaKupa(11));
        System.out.println(s.kapacitetaKupa(39));
    }
}
