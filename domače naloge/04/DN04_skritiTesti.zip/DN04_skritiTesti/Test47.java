public class Test47 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(6, 50);
        s.dodaj(552);
        Skladovnica t = s.prestavi(59, 9);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
