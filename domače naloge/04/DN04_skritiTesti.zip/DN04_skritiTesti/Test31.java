public class Test31 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(21, 0);
        s.dodaj(933);
        s.dodaj(6653);
        s.dodaj(7322);
        s.dodaj(9994);
        s.dodaj(8824);
        s.dodaj(3752);
        s.dodaj(8334);
        s.dodaj(8367);
        System.out.println(s.zasedenostKupa(2578));
        System.out.println(s.zasedenostKupa(2579));
        System.out.println(s.zasedenostKupa(2580));
        System.out.println(s.zasedenostKupa(2581));
        System.out.println(s.zasedenostKupa(2582));
        System.out.println(s.odvzemi(7191));
        System.out.println(s.odvzemi(7246));
        System.out.println(s.odvzemi(6247));
        System.out.println(s.skupnoSteviloSkatel());
        System.out.println(s.zasedenostKupa(1593));
        System.out.println(s.zasedenostKupa(1594));
        System.out.println(s.zasedenostKupa(1595));
        System.out.println(s.zasedenostKupa(1596));
        System.out.println(s.zasedenostKupa(1597));
    }
}
