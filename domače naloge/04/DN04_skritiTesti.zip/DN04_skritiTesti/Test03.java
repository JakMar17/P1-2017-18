public class Test03 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(31, 20);
        System.out.println(s.kapacitetaKupa(65));
        System.out.println(s.kapacitetaKupa(44));
        System.out.println(s.kapacitetaKupa(78));
        System.out.println(s.kapacitetaKupa(82));
        System.out.println(s.kapacitetaKupa(19));
        System.out.println(s.kapacitetaKupa(96));
        System.out.println(s.kapacitetaKupa(57));
        System.out.println(s.kapacitetaKupa(58));
        System.out.println(s.kapacitetaKupa(86));
    }
}
