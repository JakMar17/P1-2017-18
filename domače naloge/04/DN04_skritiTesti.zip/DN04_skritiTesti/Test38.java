public class Test38 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(19, 66);
        s.dodaj(864);
        System.out.println(s.poisciKup(343));
        System.out.println(s.poisciKup(743));
        System.out.println(s.poisciKup(864));
        System.out.println(s.poisciKup(5));
        System.out.println(s.poisciKup(40));
        System.out.println(s.poisciKup(864));
        System.out.println(s.poisciKup(141));
        System.out.println(s.poisciKup(775));
        System.out.println(s.poisciKup(591));
        System.out.println(s.poisciKup(650));
        System.out.println(s.poisciKup(298));
        System.out.println(s.poisciKup(751));
        System.out.println(s.poisciKup(137));
    }
}
