public class Test12 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(56, 12);
        s.dodaj(5);
        s.dodaj(1);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
