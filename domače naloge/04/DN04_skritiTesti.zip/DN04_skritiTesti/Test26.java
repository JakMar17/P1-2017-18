public class Test26 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(30, 0);
        s.dodaj(3);
        s.dodaj(6);
        s.dodaj(2);
        s.dodaj(7);
        s.dodaj(10);
        s.dodaj(7);
        s.dodaj(8);
        s.dodaj(1);
        s.dodaj(3);
        s.dodaj(10);
        s.dodaj(5);
        s.dodaj(8);
        s.dodaj(8);
        s.dodaj(2);
        s.dodaj(9);
        s.dodaj(2);
        System.out.println(s.zasedenostKupa(2));
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
        System.out.println(s.zasedenostKupa(5));
        System.out.println(s.zasedenostKupa(6));
    }
}
