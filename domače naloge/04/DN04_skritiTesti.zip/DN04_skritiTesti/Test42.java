public class Test42 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(24, 57);
        s.dodaj(69622);
        Skladovnica t = s.prestavi(89, 98);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
