public class Test17 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(72, 32);
        s.dodaj(47);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
