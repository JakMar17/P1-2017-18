public class Test24 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(34, 13);
        s.dodaj(34);
        s.dodaj(12);
        System.out.println(s.zasedenostKupa(1));
        System.out.println(s.zasedenostKupa(2));
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
    }
}
