public class Test13 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(57, 3);
        s.dodaj(13);
        s.dodaj(35);
        s.dodaj(8);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
