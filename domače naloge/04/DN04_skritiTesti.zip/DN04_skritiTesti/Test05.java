public class Test05 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(11, 46);
        System.out.println(s.kapacitetaKupa(8));
        System.out.println(s.kapacitetaKupa(44));
        System.out.println(s.kapacitetaKupa(52));
        System.out.println(s.kapacitetaKupa(7));
        System.out.println(s.kapacitetaKupa(55));
        System.out.println(s.kapacitetaKupa(82));
        System.out.println(s.kapacitetaKupa(99));
    }
}
