public class Test06 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(18, 0);
        System.out.println(s.kapacitetaKupa(54));
        System.out.println(s.kapacitetaKupa(11));
    }
}
