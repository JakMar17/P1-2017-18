public class Test04 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(60, 45);
        System.out.println(s.kapacitetaKupa(25));
        System.out.println(s.kapacitetaKupa(87));
        System.out.println(s.kapacitetaKupa(20));
    }
}
