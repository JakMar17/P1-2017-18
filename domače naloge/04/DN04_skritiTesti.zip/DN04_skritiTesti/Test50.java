public class Test50 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(5, 80);
        s.dodaj(961);
        Skladovnica t = s.prestavi(24, 29);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
