public class Test29 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(72, 63);
        s.dodaj(40);
        s.dodaj(796);
        s.dodaj(522);
        s.dodaj(688);
        s.dodaj(19);
        s.dodaj(39);
        s.dodaj(599);
        s.dodaj(208);
        s.dodaj(237);
        s.dodaj(40);
        System.out.println(s.zasedenostKupa(8));
        System.out.println(s.zasedenostKupa(9));
        System.out.println(s.zasedenostKupa(10));
        System.out.println(s.zasedenostKupa(11));
        System.out.println(s.zasedenostKupa(12));
    }
}
