public class Test22 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(60, 94);
        s.dodaj(53);
        s.dodaj(4);
        s.dodaj(51);
        s.dodaj(60);
        s.dodaj(53);
        s.dodaj(32);
        s.dodaj(1);
        s.dodaj(48);
        s.dodaj(56);
        s.dodaj(23);
        s.dodaj(60);
        s.dodaj(32);
        s.dodaj(17);
        s.dodaj(35);
        s.dodaj(35);
        System.out.println(s.zasedenostKupa(2));
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
        System.out.println(s.zasedenostKupa(5));
        System.out.println(s.zasedenostKupa(6));
    }
}
