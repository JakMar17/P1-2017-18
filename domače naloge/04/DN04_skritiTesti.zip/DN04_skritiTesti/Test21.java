public class Test21 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(30, 0);
        s.dodaj(5);
        s.dodaj(8);
        s.dodaj(5);
        s.dodaj(22);
        System.out.println(s.zasedenostKupa(1));
        System.out.println(s.zasedenostKupa(2));
        System.out.println(s.zasedenostKupa(3));
        System.out.println(s.zasedenostKupa(4));
    }
}
