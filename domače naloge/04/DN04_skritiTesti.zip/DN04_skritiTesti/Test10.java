public class Test10 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(29, 52);
        System.out.println(s.kapacitetaKupa(11));
        System.out.println(s.kapacitetaKupa(39));
        System.out.println(s.kapacitetaKupa(38));
        System.out.println(s.kapacitetaKupa(27));
        System.out.println(s.kapacitetaKupa(78));
        System.out.println(s.kapacitetaKupa(90));
        System.out.println(s.kapacitetaKupa(94));
        System.out.println(s.kapacitetaKupa(69));
        System.out.println(s.kapacitetaKupa(7));
        System.out.println(s.kapacitetaKupa(54));
    }
}
