public class Test28 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(12, 63);
        s.dodaj(2179);
        s.dodaj(2110);
        s.dodaj(2690);
        s.dodaj(5261);
        s.dodaj(114);
        s.dodaj(8681);
        s.dodaj(4773);
        s.dodaj(3713);
        s.dodaj(9618);
        s.dodaj(6111);
        s.dodaj(4458);
        s.dodaj(102);
        s.dodaj(2252);
        s.dodaj(9528);
        s.dodaj(5736);
        s.dodaj(3713);
        s.dodaj(4259);
        s.dodaj(3780);
        s.dodaj(4131);
        s.dodaj(5735);
        System.out.println(s.zasedenostKupa(52));
        System.out.println(s.zasedenostKupa(53));
        System.out.println(s.zasedenostKupa(54));
        System.out.println(s.zasedenostKupa(55));
        System.out.println(s.zasedenostKupa(56));
    }
}
