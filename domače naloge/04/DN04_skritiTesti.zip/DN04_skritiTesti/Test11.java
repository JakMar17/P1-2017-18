public class Test11 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(93, 0);
        s.dodaj(56);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
