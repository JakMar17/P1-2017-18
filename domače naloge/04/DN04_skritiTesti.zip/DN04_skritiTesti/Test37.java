public class Test37 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(55, 41);
        s.dodaj(401972);
        System.out.println(s.poisciKup(7773));
        System.out.println(s.poisciKup(189363));
    }
}
