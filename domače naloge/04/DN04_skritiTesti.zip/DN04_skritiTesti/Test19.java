public class Test19 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(17, 75);
        s.dodaj(8);
        s.dodaj(8);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
