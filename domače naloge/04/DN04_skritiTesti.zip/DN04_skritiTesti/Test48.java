public class Test48 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(87, 82);
        s.dodaj(36);
        Skladovnica t = s.prestavi(20, 69);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
