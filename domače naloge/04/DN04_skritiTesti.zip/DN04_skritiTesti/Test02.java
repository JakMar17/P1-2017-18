public class Test02 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(40, 72);
        System.out.println(s.kapacitetaKupa(98));
    }
}
