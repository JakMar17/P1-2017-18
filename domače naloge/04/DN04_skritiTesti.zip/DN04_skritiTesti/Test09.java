public class Test09 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(55, 45);
        System.out.println(s.kapacitetaKupa(78));
        System.out.println(s.kapacitetaKupa(4));
        System.out.println(s.kapacitetaKupa(31));
        System.out.println(s.kapacitetaKupa(67));
        System.out.println(s.kapacitetaKupa(55));
        System.out.println(s.kapacitetaKupa(79));
    }
}
