public class Test43 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(15, 98);
        s.dodaj(1875);
        Skladovnica t = s.prestavi(49, 43);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
