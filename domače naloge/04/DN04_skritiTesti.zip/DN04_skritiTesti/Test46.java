public class Test46 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(3, 0);
        s.dodaj(429);
        Skladovnica t = s.prestavi(96, 5);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
