public class Test15 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(57, 45);
        s.dodaj(29);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
