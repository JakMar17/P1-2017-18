public class Test39 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(88, 19);
        s.dodaj(698415);
        System.out.println(s.poisciKup(351744));
        System.out.println(s.poisciKup(521657));
        System.out.println(s.poisciKup(586415));
        System.out.println(s.poisciKup(698415));
        System.out.println(s.poisciKup(93993));
        System.out.println(s.poisciKup(475090));
    }
}
