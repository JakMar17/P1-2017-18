public class Test01 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(4, 0);
        System.out.println(s.kapacitetaKupa(57));
        System.out.println(s.kapacitetaKupa(30));
        System.out.println(s.kapacitetaKupa(21));
        System.out.println(s.kapacitetaKupa(1));
        System.out.println(s.kapacitetaKupa(41));
        System.out.println(s.kapacitetaKupa(24));
        System.out.println(s.kapacitetaKupa(19));
        System.out.println(s.kapacitetaKupa(65));
        System.out.println(s.kapacitetaKupa(20));
    }
}
