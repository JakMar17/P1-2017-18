public class Test20 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(87, 51);
        s.dodaj(44);
        System.out.println(s.skupnoSteviloSkatel());
    }
}
