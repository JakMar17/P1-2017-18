public class Test40 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(58, 10);
        s.dodaj(13);
        System.out.println(s.poisciKup(1));
        System.out.println(s.poisciKup(5));
        System.out.println(s.poisciKup(1));
        System.out.println(s.poisciKup(3));
        System.out.println(s.poisciKup(8));
        System.out.println(s.poisciKup(5));
        System.out.println(s.poisciKup(5));
        System.out.println(s.poisciKup(14));
        System.out.println(s.poisciKup(7));
        System.out.println(s.poisciKup(12));
        System.out.println(s.poisciKup(8));
        System.out.println(s.poisciKup(5));
    }
}
