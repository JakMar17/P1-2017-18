public class Test44 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(17, 15);
        s.dodaj(194);
        Skladovnica t = s.prestavi(58, 14);
        int stSkatel = t.skupnoSteviloSkatel();
        int zadnjiKup = t.poisciKup(stSkatel);
        int zasedenost = t.zasedenostKupa(zadnjiKup);
        System.out.printf("%d|%d|%d%n", stSkatel, zadnjiKup, zasedenost);
    }
}
