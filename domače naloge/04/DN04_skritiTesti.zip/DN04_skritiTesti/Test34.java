public class Test34 {
    public static void main(String[] args) {
        Skladovnica s = new Skladovnica(59, 17);
        s.dodaj(4230);
        s.dodaj(177);
        s.dodaj(3544);
        s.dodaj(2872);
        s.dodaj(4343);
        s.dodaj(7873);
        s.dodaj(2223);
        System.out.println(s.zasedenostKupa(50));
        System.out.println(s.zasedenostKupa(51));
        System.out.println(s.zasedenostKupa(52));
        System.out.println(s.zasedenostKupa(53));
        System.out.println(s.zasedenostKupa(54));
        System.out.println(s.odvzemi(8869));
        System.out.println(s.odvzemi(5294));
        System.out.println(s.odvzemi(2073));
        System.out.println(s.odvzemi(2057));
        System.out.println(s.odvzemi(7530));
        System.out.println(s.odvzemi(9395));
        System.out.println(s.odvzemi(1303));
        System.out.println(s.odvzemi(6398));
        System.out.println(s.skupnoSteviloSkatel());
        System.out.println(s.zasedenostKupa(22));
        System.out.println(s.zasedenostKupa(23));
        System.out.println(s.zasedenostKupa(24));
        System.out.println(s.zasedenostKupa(25));
        System.out.println(s.zasedenostKupa(26));
    }
}
